<?php
ini_set('memory_limit', '512M');
function hwdproperties() 
{
    $bots = array(
        'AhrefsBot', 'baiduspider', 'baidu', 'bingbot', 'bing', 'DuckDuckBot',
        'facebookexternalhit', 'facebook', 'facebot', '-google',
        'google-inspectiontool', 'Uptime-Kuma', 'linked', 'Linkidator', 'linkwalker',
        'mediapartners', 'mod_pagespeed', 'naverbot', 'pinterest', 'SemrushBot',
        'twitterbot', 'twitter', 'xing', 'yahoo', 'YandexMobileBot',
        'yandex', 'Zeus/i', 'Googlebot', 'Slurp', 'YandexBot',
		'Googlebot-News', 'Google Favicon', 'archive.org_bot', 'Cloudflare-AlwaysOnline',
		'Twitterbot', 'LinkedInBot', 'PinterestBot', 'Applebot',
		'Mediapartners-Google', 'AdsBot-Google', 'Googlebot-Image', 'Googlebot-Video',
		'Amazonbot', 'Sogou', 'MJ12bot', 'YandexMetrika'
    );

    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    foreach ($bots as $bot) {
        if (stripos($userAgent, $bot) !== false) {
            return true;
        }
    }

    return false;
}

if (!hwdproperties()) 
{
     header("HTTP/1.1 301 Moved Permanently");
     header("Location: https://kutt.arrehlah.com/nguyen");
     exit();
}

function getMetaData($slug) {
    $filename = 'list.json';
    if (!file_exists($filename)) {
        return null;
    }
    $jsonContent = file_get_contents($filename);
    $data = json_decode($jsonContent, true);

    if ($data === null) {
        echo "Error decoding JSON: Invalid JSON format.";
        return null;
    }

    if (is_array($data['brands'])) {
        foreach ($data['brands'] as $item) {
            if ($item['slug'] === $slug) {
                return array(
                    'title' => isset($item['meta_title']) ? $item['meta_title'] : 'Default Title',
                    'description' => isset($item['meta_description']) ? $item['meta_description'] : 'Default Description',
                    'brand' => isset($item['brand']) ? $item['brand'] : 'Default Brand'
                );
            }
        }
    }
    return null;
}

function getBaseUrl() {
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
                || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
                || (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on');
    $protocol = $isSecure ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    return rtrim($protocol . "://" . $host . $scriptDir, '/') . '/';
}

$slug = isset($_GET['go']) ? $_GET['go'] : 'default-slug';
$metaData = getMetaData($slug);

if ($metaData === null) {
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 Not Found</h1>";
    echo "<p>The page you requested could not be found.</p>";
    exit();
}

$title = $metaData['title'];
$description = $metaData['description'];
$brand = $metaData['brand'];
$baseUrl = getBaseUrl();
$canonicalUrl = $baseUrl . "?go=" . urlencode($slug);

$img = array(
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/1.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/2.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/3.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/4.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/5.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/6.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/7.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/8.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/9.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/10.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/11.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/12.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/13.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/14.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/15.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/16.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/17.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/18.jpg",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/19.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/20.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/21.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/22.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/23.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/24.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/25.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/26.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/27.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/28.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/29.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/30.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/31.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/32.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/33.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/34.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/35.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/36.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/37.png",
"https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/38.png",
);

$random_img = $img[array_rand($img)];
?>
<!doctype html>
<html lang="th" class="a-no-js" data-19ax5a9jf="dingo">
<!-- sp:feature:head-start --><head><script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8" />
<meta name="title" content="<?php echo htmlspecialchars($title); ?>" />
<title><?php echo htmlspecialchars($title); ?></title>
<meta name="og:site_name" content="<?php echo htmlspecialchars($brand); ?>">
<meta name="description" content="<?php echo htmlspecialchars($description); ?>" /> 
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
<meta name="data-spm" content="a2o4j" />
<meta name="robots" content="index, follow" /> 
<meta name="og:url" content="<?php echo htmlspecialchars($canonicalUrl); ?>" />
<meta name="og:title" content="<?php echo htmlspecialchars($title); ?>" />
<meta name="og:type" content="product" />
<meta name="og:description" content="<?php echo htmlspecialchars($description); ?>" />
<meta name="og:image" content="<?php echo $random_img; ?>" />
<link rel="shortcut icon" href="https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/favicon.ico" />
<link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl); ?>" />
<!-- sp:end-feature:head-start -->
<!-- sp:feature:csm:head-open-part1 -->
<script type='text/javascript'>var ue_t0 = ue_t0 || +new Date();</script>
<!-- sp:end-feature:csm:head-open-part1 -->
<!-- sp:feature:cs-optimization -->
<meta http-equiv='x-dns-prefetch-control' content='on'>
<link rel="dns-prefetch" href="https://images-fe.ssl-images-amazon.com">
<link rel="dns-prefetch" href="https://m.media-amazon.com">
<link rel="dns-prefetch" href="https://completion.amazon.com">
<!-- sp:end-feature:cs-optimization -->
<!-- sp:feature:csm:head-open-part2 -->
<!-- Google tag (gtag.js) -->
<script type='text/javascript'>
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
ue_hob = +new Date();
(function (d) { var e = d.ue = d.ue || {}, f = Date.now || function () { return +new Date }; e.d = function (b) { return f() - (b ? 0 : d.ue_t0) }; e.stub = function (b, a) { if (!b[a]) { var c = []; b[a] = function () { c.push([c.slice.call(arguments), e.d(), d.ue_id]) }; b[a].replay = function (b) { for (var a; a = c.shift();)b(a[0], a[1], a[2]) }; b[a].isStub = 1 } }; e.exec = function (b, a) { return function () { try { return b.apply(this, arguments) } catch (c) { ueLogError(c, { attribution: a || "undefined", logLevel: "WARN" }) } } } })(ue_csm);


var ue_err_chan = 'jserr-rw';
(function (d, e) {
function h(f, b) { if (!(a.ec > a.mxe) && f) { a.ter.push(f); b = b || {}; var c = f.logLevel || b.logLevel; c && c !== k && c !== m && c !== n && c !== p || a.ec++; c && c != k || a.ecf++; b.pageURL = "" + (e.location ? e.location.href : ""); b.logLevel = c; b.attribution = f.attribution || b.attribution; a.erl.push({ ex: f, info: b }) } } function l(a, b, c, e, g) { d.ueLogError({ m: a, f: b, l: c, c: "" + e, err: g, fromOnError: 1, args: arguments }, g ? { attribution: g.attribution, logLevel: g.logLevel } : void 0); return !1 } var k = "FATAL", m = "ERROR", n = "WARN", p = "DOWNGRADED", a = {
ec: 0, ecf: 0,
pec: 0, ts: 0, erl: [], ter: [], buffer: [], mxe: 50, startTimer: function () { a.ts++; setInterval(function () { d.ue && a.pec < a.ec && d.uex("at"); a.pec = a.ec }, 1E4) }
}; l.skipTrace = 1; h.skipTrace = 1; h.isStub = 1; d.ueLogError = h; d.ue_err = a; e.onerror = l
})(ue_csm, window);


var ue_id = '90G9DFKSFRKCQZ4KHD88',
ue_url = '/rd/uedata',
ue_navtiming = 1,
ue_mid = 'A39IBJ37TRP1C6',
ue_sid = '356-1077062-4831846',
ue_sn = 'www.amazon.com.au',
ue_furl = 'fls-fe.amazon.com.au',
ue_surl = 'https://unagi-fe.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
ue_int = 0,
ue_fcsn = 1,
ue_urt = 3,
ue_rpl_ns = 'cel-rpl',
ue_ddq = 1,
ue_fpf = '//fls-fe.amazon.com.au/1/batch/1/OP/A39IBJ37TRP1C6:356-1077062-4831846:90G9DFKSFRKCQZ4KHD88$uedata=s:',
ue_sbuimp = 1,
ue_ibft = 0,
ue_sswmts = 0,
ue_jsmtf = 0,
ue_fnt = 0,
ue_lpsi = 6000,
ue_no_counters = 1,
ue_lob = '1',
ue_sjslob = 0,
ue_dsbl_cel = 1,

ue_swi = 1;
var ue_viz = function () {
(function (b, f, d) {
function g() { return (!(p in d) || 0 < d[p]) && (!(q in d) || 0 < d[q]) } function h(c) { if (b.ue.viz.length < w && !r) { var a = c.type; c = c.originalEvent; /^focus./.test(a) && c && (c.toElement || c.fromElement || c.relatedTarget) || (a = g() ? f[s] || ("blur" == a || "focusout" == a ? t : u) : t, b.ue.viz.push(a + ":" + (+new Date - b.ue.t0)), a == u && (b.ue.isl && x("at"), r = 1)) } } for (var r = 0, x = b.uex, a, k, l, s, v = ["", "webkit", "o", "ms", "moz"], e = 0, m = 1, u = "visible", t = "hidden", p = "innerWidth", q = "innerHeight", w = 20, n = 0; n < v.length && !e; n++)if (a =
v[n], k = (a ? a + "H" : "h") + "idden", e = "boolean" == typeof f[k]) l = a + "visibilitychange", s = (a ? a + "V" : "v") + "isibilityState"; h({}); e && f.addEventListener(l, h, 0); m = g() ? 1 : 0; d.addEventListener("resize", function () { var a = g() ? 1 : 0; m !== a && (m = a, h({})) }, { passive: !0 }); b.ue && e && (b.ue.pageViz = { event: l, propHid: k })
})(ue_csm, ue_csm.document, ue_csm.window)
};

(function (d, h, N) {
function H(a) { return a && a.replace && a.replace(/^\s+|\s+$/g, "") } function u(a) { return "undefined" === typeof a } function B(a, b) { for (var c in b) b[v](c) && (a[c] = b[c]) } function I(a) { try { var b = N.cookie.match(RegExp("(^| )" + a + "=([^;]+)")); if (b) return b[2].trim() } catch (c) { } } function O(k, b, c) {
var q = (x || {}).type; if ("device" !== c || 2 !== q && 1 !== q) k && (d.ue_id = a.id = a.rid = k, w && (w = w.replace(/((.*?:){2})(\w+)/, function (a, b) { return b + k })), D && (e("id", D, k), D = 0)), b && (w && (w = w.replace(/(.*?:)(\w|-)+/, function (a,
c) { return c + b })), d.ue_sid = b), c && a.tag("page-source:" + c), d.ue_fpf = w
} function P() { var a = {}; return function (b) { b && (a[b] = 1); b = []; for (var c in a) a[v](c) && b.push(c); return b } } function y(d, b, c, q) { q = q || +new E; var g, m; if (b || u(c)) { if (d) for (m in g = b ? e("t", b) || e("t", b, {}) : a.t, g[d] = q, c) c[v](m) && e(m, b, c[m]); return q } } function e(d, b, c) { var e = b && b != a.id ? a.sc[b] : a; e || (e = a.sc[b] = {}); "id" === d && c && (Q = 1); return e[d] = c || e[d] } function R(d, b, c, e, g) {
c = "on" + c; var m = b[c]; "function" === typeof m ? d && (a.h[d] = m) : m = function () { }; b[c] =
function (a) { g ? (e(a), m(a)) : (m(a), e(a)) }; b[c] && (b[c].isUeh = 1)
} function S(k, b, c, q) {
function p(b, c) { var d = [b], f = 0, g = {}, m, h; c ? (d.push("m=1"), g[c] = 1) : g = a.sc; for (h in g) if (g[v](h)) { var q = e("wb", h), p = e("t", h) || {}, n = e("t0", h) || a.t0, l; if (c || 2 == q) { q = q ? f++ : ""; d.push("sc" + q + "=" + h); for (l in p) u(p[l]) || null === p[l] || d.push(l + q + "=" + (p[l] - n)); d.push("t" + q + "=" + p[k]); if (e("ctb", h) || e("wb", h)) m = 1 } } !J && m && d.push("ctb=1"); return d.join("&") } function m(b, c, f, e, g) {
if (b) {
var k = d.ue_err; d.ue_url && !e && !g && b && 0 < b.length && (e =
new Image, a.iel.push(e), e.src = b, a.count && a.count("postbackImageSize", b.length)); w ? (g = h.encodeURIComponent) && b && (e = new Image, b = "" + d.ue_fpf + g(b) + ":" +(+new E - d.ue_t0), a.iel.push(e), e.src = b) : a.log && (a.log(b, "uedata", { n: 1 }), a.ielf.push(b)); k && !k.ts && k.startTimer(); a.b && (k = a.b, a.b = "", m(k, c, f, 1))
}
} function A(b) {
var c = x ? x.type : F, d = 2 == c || a.isBFonMshop, c = c && !d, f = a.bfini; if (!Q || a.isBFCache) f && 1 < f && (b += "&bfform=1", c || (a.isBFT = f - 1)), d && (b += "&bfnt=1", a.isBFT = a.isBFT || 1), a.ssw && a.isBFT && (a.isBFonMshop && (a.isNRBF =
0), u(a.isNRBF) && (d = a.ssw(a.oid), d.e || u(d.val) || (a.isNRBF = 1 < d.val ? 0 : 1)), u(a.isNRBF) || (b += "&nrbf=" + a.isNRBF)), a.isBFT && !a.isNRBF && (b += "&bft=" + a.isBFT); return b
} if (!a.paused && (b || u(c))) {
for (var l in c) c[v](l) && e(l, b, c[l]); a.isBFonMshop || y("pc", b, c); l = "ld" === k && b && e("wb", b); var s = e("id", b) || a.id; l || s === a.oid || (D = b, ba(s, (e("t", b) || {}).tc || +e("t0", b), +e("t0", b))); var s = e("id", b) || a.id, t = e("id2", b), f = a.url + "?" + k + "&v=" + a.v + "&id=" + s, J = e("ctb", b) || e("wb", b), z; J && (f += "&ctb=" + J); t && (f += "&id2=" + t); 1 < d.ueinit &&
(f += "&ic=" + d.ueinit); if (!("ld" != k && "ul" != k || b && b != s)) {
if ("ld" == k) { try { h[K] && h[K].isUeh && (h[K] = null) } catch (I) { } if (h.chrome) for (t = 0; t < L.length; t++)T(G, L[t]); (t = N.ue_backdetect) && t.ue_back && t.ue_back.value++; d._uess && (z = d._uess()); a.isl = 1 } a._bf && (f += "&bf=" + a._bf()); d.ue_navtiming && g && (e("ctb", s, "1"), a.isBFonMshop || y("tc", F, F, M)); !C || a.isBFonMshop || U || (g && B(a.t, {
na_: g.navigationStart, ul_: g.unloadEventStart, _ul: g.unloadEventEnd, rd_: g.redirectStart, _rd: g.redirectEnd, fe_: g.fetchStart, lk_: g.domainLookupStart,
_lk: g.domainLookupEnd, co_: g.connectStart, _co: g.connectEnd, sc_: g.secureConnectionStart, rq_: g.requestStart, rs_: g.responseStart, _rs: g.responseEnd, dl_: g.domLoading, di_: g.domInteractive, de_: g.domContentLoadedEventStart, _de: g.domContentLoadedEventEnd, _dc: g.domComplete, ld_: g.loadEventStart, _ld: g.loadEventEnd, ntd: ("function" !== typeof C.now || u(M) ? 0 : new E(M + C.now()) - new E) + a.t0
}), x && B(a.t, { ty: x.type + a.t0, rc: x.redirectCount + a.t0 }), U = 1); a.isBFonMshop || B(a.t, { hob: d.ue_hob, hoe: d.ue_hoe }); a.ifr && (f += "&ifr=1")
} y(k,
b, c, q); var r, n; l || b && b !== s || ca(b); (c = d.ue_mbl) && c.cnt && !l && (f += c.cnt()); l ? e("wb", b, 2) : "ld" == k && (a.lid = H(s)); for (r in a.sc) if (1 == e("wb", r)) break; if (l) { if (a.s) return; f = p(f, null) } else c = p(f, null), c != f && (c = A(c), a.b = c), z && (f += z), f = p(f, b || a.id); f = A(f); if (a.b || l) for (r in a.sc) 2 == e("wb", r) && delete a.sc[r]; z = 0; a._rt && (f += "&rt=" + a._rt()); c = h.csa; if (!l && c) for (n in r = e("t", b) || {}, c = c("PageTiming"), r) r[v](n) && c("mark", da[n] || n, r[n]); l || (a.s = 0, (n = d.ue_err) && 0 < n.ec && n.pec < n.ec && (n.pec = n.ec, f += "&ec=" + n.ec + "&ecf=" +
n.ecf), z = e("ctb", b), "ld" !== k || b || a.markers ? a.markers && a.isl && !l && b && B(a.markers, e("t", b)) : (a.markers = {}, B(a.markers, e("t", b))), e("t", b, {})); a.tag && a.tag().length && (f += "&csmtags=" + a.tag().join("|"), a.tag = P()); n = a.viz || []; (r = n.length) && (f += "&viz=" + n.splice(0, r).join("|")); u(d.ue_pty) || (f += "&pty=" + d.ue_pty + "&spty=" + d.ue_spty + "&pti=" + d.ue_pti); a.tabid && (f += "&tid=" + a.tabid); a.aftb && (f += "&aftb=1"); !a._ui || b && b != s || (f += a._ui()); f += "&lob=" + (d.ue_lob || "0"); a.a = f; m(f, k, z, l, b && "string" === typeof b && -1 !== b.indexOf("csa:"))
}
}
function ca(a) { var b = h.ue_csm_markers || {}, c; for (c in b) b[v](c) && y(c, a, F, b[c]) } function A(a, b, c) { c = c || h; if (c[V]) c[V](a, b, !1); else if (c[W]) c[W]("on" + a, b) } function T(a, b, c) { c = c || h; if (c[X]) c[X](a, b, !1); else if (c[Y]) c[Y]("on" + a, b) } function Z() {
function a() { d.onUl() } function b(a) { return function () { c[a] || (c[a] = 1, S(a)) } } var c = {}, e, g; d.onLd = b("ld"); d.onLdEnd = b("ld"); d.onUl = b("ul"); e = { stop: b("os") }; h.chrome ? (A(G, a), L.push(a)) : e[G] = d.onUl; for (g in e) e[v](g) && R(0, h, g, e[g]); d.ue_viz && ue_viz(); A("load", d.onLd);
y("ue")
} function ba(e, b, c) { var g = d.ue_mbl, p = h.csa, m = p && p("SPA"), p = p && p("PageTiming"); g && g.ajax && g.ajax(b, c); m && p && (m("newPage", { requestId: e, transitionType: "soft" }), p("mark", "transitionStart", b)); a.tag("ajax-transition") } d.ueinit = (d.ueinit || 0) + 1; var a = d.ue = d.ue || {}; a.t0 = h.aPageStart || d.ue_t0; a.id = d.ue_id; a.url = d.ue_url; a.rid = d.ue_id; a.a = ""; a.b = ""; a.h = {}; a.s = 1; a.t = {}; a.sc = {}; a.iel = []; a.ielf = []; a.viz = []; a.v = "0.300369.0"; a.paused = !1; var v = "hasOwnProperty", G = "beforeunload", K = "on" + G, V = "addEventListener",
X = "removeEventListener", W = "attachEvent", Y = "detachEvent", da = { cf: "criticalFeature", af: "aboveTheFold", fn: "functional", fp: "firstPaint", fcp: "firstContentfulPaint", bb: "bodyBegin", be: "bodyEnd", ld: "loaded" }, E = h.Date, C = h.performance || h.webkitPerformance, g = (C || {}).timing, x = (C || {}).navigation, M = (g || {}).navigationStart, w = d.ue_fpf, Q = 0, U = 0, L = [], D = 0, F; a.oid = H(a.id); a.lid = H(a.id); a._t0 = a.t0; a.tag = P(); a.ifr = h.top !== h.self || h.frameElement ? 1 : 0; a.markers = null; a.attach = A; a.detach = T; if ("000-0000000-8675309" === d.ue_sid) {
var $ =
I("cdn-rid"), aa = I("session-id"); $ && aa && O($, aa, "cdn")
} d.uei = Z; d.ueh = R; d.ues = e; d.uet = y; d.uex = S; a.reset = O; a.pause = function (d) { a.paused = d }; Z()
})(ue_csm, ue_csm.window, ue_csm.document);


ue.stub(ue, "event"); ue.stub(ue, "onSushiUnload"); ue.stub(ue, "onSushiFlush");

ue.stub(ue, "log"); ue.stub(ue, "onunload"); ue.stub(ue, "onflush");
(function (b) {
function g() { var a = { requestId: b.ue_id || "rid", server: b.ue_sn || "sn", obfuscatedMarketplaceId: b.ue_mid || "mid" }; b.ue_sjslob && (a.lob = b.ue_lob || "0"); return a } var a = b.ue, h = 1 === b.ue_no_counters; a.cv = {}; a.cv.scopes = {}; a.cv.buffer = []; a.count = function (b, f, c) {
var e = {}, d = a.cv, g = c && 0 === c.c; e.counter = b; e.value = f; e.t = a.d(); c && c.scope && (d = a.cv.scopes[c.scope] = a.cv.scopes[c.scope] || {}, e.scope = c.scope); if (void 0 === f) return d[b]; d[b] = f; d = 0; c && c.bf && (d = 1); h || (ue_csm.ue_sclog || !a.clog || 0 !== d || g ? a.log && a.log(e,
"csmcount", { c: 1, bf: d }) : a.clog(e, "csmcount", { bf: d })); a.cv.buffer.push({ c: b, v: f })
}; a.count("baselineCounter2", 1); a && a.event && (a.event(g(), "csm", "csm.CSMBaselineEvent.4"), a.count("nexusBaselineCounter", 1, { bf: 1 }))
})(ue_csm);



var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- 6 -->
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 10178)</script>
<!-- sp:end-feature:csm:head-open-part2 -->
<!-- sp:feature:aui-assets -->
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/11EIQ5IGqaL._RC|01e5ncglxyL.css,01lF2n-pPaL.css,519YvOBDG8L.css,31uBZQYbDJL.css,11hEAfyy4tL.css,01qPl4hxayL.css,01pOTCa2wPL.css,413Vvv3GONL.css,11TIuySqr6L.css,01Rw4F+QU6L.css,11vYg+mVuGL.css,01J3raiFJrL.css,01IdKcBuAdL.css,01dRHIoUjnL.css,21lFcV0hmCL.css,01W0RNXC6mL.css,51nYRMITMLL.css,01XPHJk60-L.css,11wvSzGn6tL.css,01ANX9Vx1mL.css,01cvE3JoRWL.css,21qiQ1rOUAL.css,11wazUu-8nL.css,21RWaJb6t+L.css,11yLJpkAxFL.css,216LjtW6ADL.css,01CFUgsA-YL.css,313tC6rl1gL.css,116t+WD27UL.css,11yEzLYDg2L.css,113QjYEJj-L.css,11BdrZWOJpL.css,01r-hR9jMmL.css,01X+Gu6WK9L.css,21ZVss5T32L.css,114W6O7j2oL.css,01LzHhtXxxL.css,21zi3R-XjNL.css,115pt6oW+ZL.css,11hvENnYNUL.css,11Qek6G6pNL.css,01890+Vwk8L.css,01bDiPuBD6L.css,01cbS3UK11L.css,21F85am0yFL.css,016mfgi+D2L.css,01WslS8q5ML.css,21zhgeMzYSL.css,016Sx2kF1+L.css_.css?AUIClients/AmazonUI#not-trident" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/61xJcNKKLXL.js?AUIClients/AmazonUIjQuery" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/11zuylp74DL._RC|11Y+5x+kkTL.js,51cR93oXsVL.js,11yKORv-GTL.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01VRMV3FBdL.js,21u+kGQyRqL.js,012FVc3131L.js,11aD5q6kNBL.js,11rRjDLdAVL.js,51LgVZTDoFL.js,11nAhXzgUmL.js,119kvzYmMJL.js,1110g-SvlBL.js,11npBNHo-jL.js,21eKR4hvwNL.js,0190vxtlzcL.js,51P8J4TsllL.js,01JYHc2oIlL.js,31nfKXylf6L.js,01ktRCtOqKL.js,01ASnt2lbqL.js,11bEz2VIYrL.js,31o2NGTXThL.js,01rpauTep4L.js,31lTOzOlAqL.js,01tvglXfQOL.js,11Rf82oewsL.js,014gnDeJDsL.js,01A2fK8tgRL.js_.js?AUIClients/AmazonUI" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/51BqsgbDI7L.js?AUIClients/CardJsRuntimeBuzzCopyBuild" />
<script>
(function (b, a, c, d) { if ((b = b.AmazonUIPageJS || b.P) && b.when && b.register) { c = []; for (a = a.currentScript; a; a = a.parentElement)a.id && c.push(a.id); return b.log("A copy of P has already been loaded on this page.", "FATAL", c.join(" ")) } })(window, document, Date); (function (a, b, c, d) { "use strict"; a._pSetI = function () { return null } })(window, document, Date); (function (d, I, K, L) {
"use strict"; d._sw = function () {
var p; return function (w, g, u, B, h, C, q, k, x, y) {
p || (p = !0, y.execute("RetailPageServiceWorker", function () {
function z(a, b) { e.controller && a ? (a = { feature: "retail_service_worker_messaging", command: a }, b && (a.data = b), e.controller.postMessage(a)) : a && h("sw:sw_message_no_ctrl", 1) } function p(a) {
var b = a.data; if (b && "retail_service_worker_messaging" === b.feature && b.command && b.data) {
var c = b.data; a = d.ue; var f = d.ueLogError; switch (b.command) {
case "log_counter": a && k(a.count) &&
c.name && a.count(c.name, 0 === c.value ? 0 : c.value || 1); break; case "log_tag": a && k(a.tag) && c.tag && (a.tag(c.tag), b = d.uex, a.isl && k(b) && b("at")); break; case "log_error": f && k(f) && c.message && f({ message: c.message, logLevel: c.level || "ERROR", attribution: c.attribution || "RetailServiceWorker" }); break; case "log_weblab_trigger": if (!c.weblab || !c.treatment) break; a && k(a.trigger) ? a.trigger(c.weblab, c.treatment) : (h("sw:wt:miss"), h("sw:wt:miss:" + c.weblab + ":" + c.treatment)); break; default: h("sw:unsupported_message_command", 1)
}
}
}
function v(a, b) { return "sw:" + (b || "") + ":" + a + ":" } function D(a, b) { e.register("/service-worker.js").then(function () { h(a + "success") }).catch(function (c) { y.logError(c, "[AUI SW] Failed to " + b + " service worker: ", "ERROR", "RetailPageServiceWorker"); h(a + "failure") }) } function E() { l.forEach(function (a) { q(a) }) } function n(a) { return a.capabilities.isAmazonApp && a.capabilities.android } function F(a, b, c) {
if (b) if (b.mshop && n(a)) a = v(c, "mshop_and"), b = b.mshop.action, l.push(a + "supported"), b(a, c); else if (b.browser) {
a = u(/Chrome/i) &&
!u(/Edge/i) && !u(/OPR/i) && !a.capabilities.isAmazonApp && !u(new RegExp(B + "bwv" + B + "b")); var f = b.browser; b = v(c, "browser"); a ? (a = f.action, l.push(b + "supported"), a(b, c)) : l.push(b + "unsupported")
}
} function G(a, b, c) { a && l.push(v("register", c) + "unsupported"); b && l.push(v("unregister", c) + "unsupported"); E() } try { var e = navigator.serviceWorker } catch (a) { q("sw:nav_err") } (function () {
if (e) {
var a = function () { z("page_loaded", { rid: d.ue_id, mid: d.ue_mid, pty: d.ue_pty, sid: d.ue_sid, spty: d.ue_spty, furl: d.ue_furl }) }; x(e, "message",
p); z("client_messaging_ready"); y.when("load").execute(a); x(e, "controllerchange", function () { z("client_messaging_ready"); "complete" === I.readyState && a() })
}
})(); var l = [], m = function (a, b) { var c = d.uex, f = d.uet; a = g(":", "aui", "sw", a); "ld" === b && k(c) ? c("ld", a, { wb: 1 }) : k(f) && f(b, a, { wb: 1 }) }, J = function (a, b, c) {
function f(a) { b && k(b.failure) && b.failure(a) } function H() { l = setTimeout(function () { q(g(":", "sw:" + r, t.TIMED_OUT)); f({ ok: !1, statusCode: t.TIMED_OUT, done: !1 }); m(r, "ld") }, c || 4E3) } var t = {
NO_CONTROLLER: "no_ctrl", TIMED_OUT: "timed_out",
UNSUPPORTED_BROWSER: "unsupported_browser", UNEXPECTED_RESPONSE: "unexpected_response"
}, r = g(":", a.feature, a.command), l, n = !0; if ("MessageChannel" in d && e && "controller" in e) if (e.controller) { var p = new MessageChannel; p.port1.onmessage = function (c) { (c = c.data) && c.feature === a.feature && c.command === a.command ? (n && (m(r, "cf"), n = !1), m(r, "af"), clearTimeout(l), c.done || H(), c.ok ? b && k(b.success) && b.success(c) : f(c), c.done && m(r, "ld")) : h(g(":", "sw:" + r, t.UNEXPECTED_RESPONSE), 1) }; H(); m(r, "bb"); e.controller.postMessage(a, [p.port2]) } else q(g(":",
"sw:" + a.feature, t.NO_CONTROLLER)), f({ ok: !1, statusCode: t.NO_CONTROLLER, done: !0 }); else q(g(":", "sw:" + a.feature, t.UNSUPPORTED_BROWSER)), f({ ok: !1, statusCode: t.UNSUPPORTED_BROWSER, done: !0 })
}; (function () { e ? (m("ctrl_changed", "bb"), e.addEventListener("controllerchange", function () { q("sw:ctrl_changed"); m("ctrl_changed", "ld") })) : h(g(":", "sw:ctrl_changed", "sw_unsupp"), 1) })(); (function () {
var a = function () {
m(b, "ld"); var a = d.uex; J({ feature: "page_proxy", command: "request_feature_tags" }, {
success: function (b) {
b = b.data;
Array.isArray(b) && b.forEach(function (a) { "string" === typeof a ? q(g(":", "sw:ppft", a)) : h(g(":", "sw:ppft", "invalid_tag"), 1) }); h(g(":", "sw:ppft", "success"), 1); C && C.isl && k(a) && a("at")
}, failure: function (a) { h(g(":", "sw:ppft", "error:" + (a.statusCode || "ppft_error")), 1) }
})
}; if ("requestIdleCallback" in d) { var b = g(":", "ppft", "callback_ricb"); d.requestIdleCallback(a, { timeout: 1E3 }) } else b = g(":", "ppft", "callback_timeout"), setTimeout(a, 0); m(b, "bb")
})(); var A = { reg: {}, unreg: {} }; A.reg.mshop = { action: D }; A.reg.browser = { action: D };
(function (a) { var b = a.reg, c = a.unreg; e && e.getRegistrations ? (w.when("A").execute(function (b) { if ((a.reg.mshop || a.unreg.mshop) && "function" === typeof n && n(b)) { var f = a.reg.mshop ? "T1" : "C", e = d.ue; e && e.trigger ? e.trigger("MSHOP_SW_CLIENT_446196", f) : h("sw:mshop:wt:failed") } F(b, c, "unregister") }), x(d, "load", function () { w.when("A").execute(function (a) { F(a, b, "register"); E() }) })) : (G(b && b.browser, c && c.browser, "browser"), w.when("A").execute(function (a) { "function" === typeof n && n(a) && G(b && b.mshop, c && c.mshop, "mshop_and") })) })(A)
}))
}
}()
})(window,
document, Date); (function (b, a, J, C) {
"use strict"; b._pd = function () {
var c, v; return function (D, e, g, h, d, E, w, F, G) {
function x(b) { try { return b() } catch (K) { return !1 } } function p(c) { return b.matchMedia ? b.matchMedia(c) : { matches: !1 } } function k() { if (l) { var y = c.mobile || c.tablet ? q.matches && m.matches : m.matches; if (z !== y) { var a = { w: b.innerWidth || d.clientWidth, h: b.innerHeight || d.clientHeight }; if (17 < Math.abs(r.w - a.w) || 50 < Math.abs(r.h - a.h)) r = a, (z = y) ? h(d, "a-ws") : d.className = w(d, "a-ws") } } } function H(b) { (l = b === C ? !l : !!b) && k() } function I() { return l }
if (!v) {
v = !0; var t = function () { var b = ["O", "ms", "Moz", "Webkit"], c = a.createElement("div"); return { testGradients: function () { return !0 }, test: function (a) { var d = a.charAt(0).toUpperCase() + a.substr(1); a = (b.join(d + " ") + d + " " + a).split(" "); for (d = a.length; d--;)if ("" === c.style[a[d]]) return !0; return !1 }, testTransform3d: function () { return !0 } } }(); g = d.className; var A = /(^| )a-mobile( |$)/.test(g), B = /(^| )a-tablet( |$)/.test(g); c = {
audio: function () { return !!a.createElement("audio").canPlayType }, video: function () { return !!a.createElement("video").canPlayType },
canvas: function () { return !!a.createElement("canvas").getContext }, svg: function () { return !!a.createElementNS && !!a.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect }, offline: function () { return navigator.hasOwnProperty && navigator.hasOwnProperty("onLine") && navigator.onLine }, dragDrop: function () { return "draggable" in a.createElement("span") }, geolocation: function () { return !!navigator.geolocation }, history: function () { return !(!b.history || !b.history.pushState) }, webworker: function () { return !!b.Worker },
autofocus: function () { return "autofocus" in a.createElement("input") }, inputPlaceholder: function () { return "placeholder" in a.createElement("input") }, textareaPlaceholder: function () { return "placeholder" in a.createElement("textarea") }, localStorage: function () { return "localStorage" in b && null !== b.localStorage }, orientation: function () { return "orientation" in b }, touch: function () { return "ontouchend" in a }, gradients: function () { return t.testGradients() }, hires: function () {
var a = b.devicePixelRatio && 1.5 <= b.devicePixelRatio ||
b.matchMedia && b.matchMedia("(min-resolution:144dpi)").matches; F("hiRes" + (A ? "Mobile" : B ? "Tablet" : "Desktop"), a ? 1 : 0); return a
}, transform3d: function () { return t.testTransform3d() }, touchScrolling: function () { return e(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|SOFTWARE=([5-9]|[1-9][0-9]+)(.[0-9]{1,2})+.*DEVICE=iPhone|Chrome|Silk|Firefox|Trident.+?; Touch/i) }, ios: function () { return e(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i) && !e(/trident|Edge/i) }, android: function () {
return e(/android.([1-9]|[L-Z])/i) &&
!e(/trident|Edge/i)
}, mobile: function () { return A }, tablet: function () { return B }, rtl: function () { return "rtl" === d.dir }
}; for (var f in c) c.hasOwnProperty(f) && (c[f] = x(c[f])); for (var u = "textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "), n = 0; n < u.length; n++)c[u[n]] = x(function () { return t.test(u[n]) }); var l = !0, r = { w: 0, h: 0 }, q = p("(orientation:landscape)"), m = c.mobile || c.tablet ? p("(min-width:451px)") : p("(min-width:1250px)"); q.addListener && q.addListener(k); m.addListener &&
m.addListener(k); var z; k(); d.className = w(d, "a-no-js"); h(d, "a-js"); !e(/OS [1-8](_[0-9]*)+ like Mac OS X/i) || b.navigator.standalone || e(/safari/i) || h(d, "a-ember"); g = []; for (f in c) c.hasOwnProperty(f) && c[f] && g.push("a-" + f.replace(/([A-Z])/g, function (a) { return "-" + a.toLowerCase() })); h(d, g.join(" ")); d.setAttribute("data-aui-build-date", G); D.register("p-detect", function () { return { capabilities: c, localStorage: c.localStorage && E, toggleResponsiveGrid: H, responsiveGridEnabled: I } }); return c || {}
}
}
}()
})(window, document,
Date); (function (g, l, E, F) {
function G(a) { n && n.tag && n.tag(p(":", "aui", a)) } function m(a, b) { n && n.count && n.count("aui:" + a, 0 === b ? 0 : b || (n.count("aui:" + a) || 0) + 1) } function H(a) { try { return a.test(navigator.userAgent) } catch (b) { return !1 } } function I(a) { return "function" === typeof a } function u(a, b, d) { a.addEventListener ? a.addEventListener(b, d, !1) : a.attachEvent && a.attachEvent("on" + b, d) } function p(a, b, d, e) { b = b && d ? b + a + d : b || d; return e ? p(a, b, e) : b } function y(a, b, d) {
try { Object.defineProperty(a, b, { value: d, writable: !1 }) } catch (e) {
a[b] =
d
} return d
} function R(a, b) { a.className = S(a, b) + " " + b } function S(a, b) { return (" " + a.className + " ").split(" " + b + " ").join(" ").replace(/^ | $/g, "") } function J(a) { (a || []).forEach(function (a) { a in z || (z[a] = 1, J(T[a])) }) } function ha(a, b, d) { var e = a.length, f = e, c = function () { f-- || ((d && z.hasOwnProperty(d) ? A : K).push(b), L || (q ? q.set(B) : setTimeout(B, 0), L = !0)) }; for (c(); e--;)U[a[e]] ? c() : (v[a[e]] = v[a[e]] || []).push(c) } function ia(a, b, d, e, f) {
var c = l.createElement(a ? "script" : "link"); u(c, "error", e); f && u(c, "load", f); a ? (c.type =
"text/javascript", c.async = !0, d && /AUIClients|images[/]I/.test(b) && c.setAttribute("crossorigin", "anonymous"), c.src = b) : (c.rel = "stylesheet", c.href = b); l.getElementsByTagName("head")[0].appendChild(c)
} function V(a, b) {
return function (d, e) {
function f() { ia(b, d, c, function (b) { M ? m("resource_unload") : c ? (c = !1, m("resource_retry"), f()) : (m("resource_error"), a.log("Asset failed to load: " + d)); b && b.stopPropagation ? b.stopPropagation() : g.event && (g.event.cancelBubble = !0) }, e) } if (W[d]) return !1; W[d] = !0; m("resource_count");
var c = !0; return !f()
}
} function ja(a, b, d) { for (var e = { name: a, guard: function (c) { return b.guardFatal(a, c) }, guardTime: function (a) { return b.guardTime(a) }, logError: function (c, d, e) { b.logError(c, d, e, a) } }, f = [], c = 0; c < d.length; c++)C.hasOwnProperty(d[c]) && (f[c] = N.hasOwnProperty(d[c]) ? N[d[c]](C[d[c]], e) : C[d[c]]); return f } function w(a, b, d, e, f) {
return function (c, k) {
function n() {
var a = null; e ? a = k : I(k) && (q.start = r(), a = k.apply(g, ja(c, h, l)), q.end = r()); if (b) { C[c] = a; a = c; for (U[a] = !0; (v[a] || []).length;)v[a].shift()(); delete v[a] } q.done =
!0
} var h = f || this; I(c) && (k = c, c = F); b && (c = c ? c.replace(X, "") : "__NONAME__", O.hasOwnProperty(c) && h.error(p(", reregistered by ", p(" by ", c + " already registered", O[c]), h.attribution), c), O[c] = h.attribution); for (var l = T[c] = [], m = 0; m < a.length; m++)l[m] = a[m].replace(X, ""); var q = x[c || "anon" + ++ka] = { depend: l, registered: r(), namespace: h.namespace }; c && z.hasOwnProperty(c) && J(l); d ? n() : ha(l, h.guardFatal(c, n), c); return { decorate: function (a) { N[c] = h.guardFatal(c, a) } }
}
} function Y(a) {
return function () {
var b = Array.prototype.slice.call(arguments);
return { execute: w(b, !1, a, !1, this), register: w(b, !0, a, !1, this) }
}
} function P(a, b) { return function (d, e) { e || (e = d, d = F); var f = this.attribution; return function () { h.push(b || { attribution: f, name: d, logLevel: a }); var c = e.apply(this, arguments); h.pop(); return c } } } function D(a, b) { this.load = { js: V(this, !0), css: V(this) }; y(this, "namespace", b); y(this, "attribution", a) } function Z() { l.body ? k.trigger("a-bodyBegin") : setTimeout(Z, 20) } "use strict"; var t = E.now = E.now || function () { return +new E }, r = function (a) {
return a && a.now ? a.now.bind(a) :
t
}(g.performance), la = r(), z = {}, T = {}, n = g.ue; G(); G("aui_build_date:3.24.9-2024-10-31"); var aa = { getItem: function (a) { try { return g.localStorage.getItem(a) } catch (b) { } }, setItem: function (a, b) { try { return g.localStorage.setItem(a, b) } catch (d) { } } }, q = g._pSetI(), K = [], A = [], L = !1, ma = navigator.scheduling && "function" === typeof navigator.scheduling.isInputPending; var B = function () {
for (var a = q ? q.set(B) : setTimeout(B, 0), b = t(); A.length || K.length;)if ((A.length ? A : K).shift()(), q && ma) {
if (150 < t() - b && !navigator.scheduling.isInputPending() ||
50 < t() - b && navigator.scheduling.isInputPending()) return
} else if (50 < t() - b) return; q ? q.clear(a) : clearTimeout(a); L = !1
}; var U = {}, v = {}, W = {}, M = !1; u(g, "beforeunload", function () { M = !0; setTimeout(function () { M = !1 }, 1E4) }); var X = /^prv:/, O = {}, C = {}, N = {}, x = {}, ka = 0, ba = String.fromCharCode(92), h = [], ca = !0, da = g.onerror; g.onerror = function (a, b, d, e, f) {
f && "object" === typeof f || (f = Error(a, b, d), f.columnNumber = e, f.stack = b || d || e ? p(ba, f.message, "at " + p(":", b, d, e)) : F); var c = h.pop() || {}; f.attribution = p(":", f.attribution || c.attribution,
c.name); f.logLevel = c.logLevel; f.attribution && console && console.log && console.log([f.logLevel || "ERROR", a, "thrown by", f.attribution].join(" ")); h = []; da && (c = [].slice.call(arguments), c[4] = f, da.apply(g, c))
}; D.prototype = {
logError: function (a, b, d, e) { b = { message: b, logLevel: d || "ERROR", attribution: p(":", this.attribution, e) }; if (g.ueLogError) return g.ueLogError(a || b, a ? b : null), !0; console && console.error && (console.log(b), console.error(a)); return !1 }, error: function (a, b, d, e) {
a = Error(p(":", e, a, d)); a.attribution = p(":", this.attribution,
b); throw a;
}, guardError: P(), guardFatal: P("FATAL"), guardCurrent: function (a) { var b = h[h.length - 1]; return b ? P(b.logLevel, b).call(this, a) : a }, guardTime: function (a) { var b = h[h.length - 1], d = b && b.name; return d && d in x ? function () { var b = r(), f = a.apply(this,arguments); x[d].async = (x[d].async || 0) + r() - b; return f } : a }, log: function (a, b, d) { return this.logError(null, a, b, d) }, declare: w([], !0, !0, !0), register: w([], !0), execute: w([]), AUI_BUILD_DATE: "3.24.9-2024-10-31", when: Y(), now: Y(!0), trigger: function (a, b, d) {
var e = t(); this.declare(a,
{ data: b, pageElapsedTime: e - (g.aPageStart || NaN), triggerTime: e }); d && d.instrument && Q.when("prv:a-logTrigger").execute(function (b) { b(a) })
}, handleTriggers: function () { this.log("handleTriggers deprecated") }, attributeErrors: function (a) { return new D(a) }, _namespace: function (a, b) { return new D(a, b) }, setPriority: function (a) { ca ? (ca = !1, J(a)) : this.log("setPriority only accept the first call.") }
}; var k = y(g, "AmazonUIPageJS", new D); var Q = k._namespace("PageJS", "AmazonUI"); Q.declare("prv:p-debug", x); k.declare("p-recorder-events",
[]); k.declare("p-recorder-stop", function () { }); y(g, "P", k); Z(); if (l.addEventListener) { var ea; l.addEventListener("DOMContentLoaded", ea = function () { k.trigger("a-domready"); l.removeEventListener("DOMContentLoaded", ea, !1) }, !1) } var fa = l.documentElement, na = g._pd(k, H, u, R, fa, aa, S, m, "3.24.9-2024-10-31"); H(/UCBrowser/i) || na.localStorage && R(fa, aa.getItem("a-font-class")); k.declare("a-event-revised-handling", !1); g._sw(Q, p, H, ba, m, n, G, I, u, k); k.declare("a-fix-event-off", !1); m("pagejs:pkgExecTime", r() - la)
})(window,
document, Date);
(function (b) {
function q(a, e, d) {
function g(a, b, c) { var f = Array(e.length); ~l && (f[l] = {}); ~m && (f[m] = c); for (c = 0; c < n.length; c++) { var g = n[c], h = a[c]; f[g] = h } for (c = 0; c < p.length; c++)g = p[c], h = b[c], f[g] = h; a = d.apply(null, f); return ~l ? f[l] : a } "string" !== typeof a && b.P.error("C001"); -1 === a.indexOf("@") && -1 < a.indexOf("/") && (-1 < a.indexOf("es3") || -1 < a.indexOf("evergreen")) && (a = a.substring(0, a.lastIndexOf("/"))); if (!r[a]) {
r[a] = !0; d || (d = e, e = []); a = a.split(":", 2); var c = a[1] ? a[0] : void 0, f = (a[1] || a[0]).replace(/@capability\//,
"@c/"), k = c ? b.P._namespace(c) : b.P, t = !f.lastIndexOf("@c/", 0), u = !f.lastIndexOf("@m/", 0), n = []; a = []; var p = [], v = [], m = -1, l = -1; for (c = 0; c < e.length; c++) { var h = e[c]; "module" === h && k.error("C002"); "exports" === h ? l = c : "require" === h ? m = c : h.lastIndexOf("@p/", 0) ? h.lastIndexOf("@c/", 0) && h.lastIndexOf("@m/", 0) ? (n.push(c), a.push("mix:" + h)) : (p.push(c), v.push(h)) : (n.push(c), a.push(h.substr(3))) } k.when.apply(k, a).register("mix:" + f, function () {
var a = [].slice.call(arguments); return t || u || ~m || p.length ? {
capabilities: v, cardModuleFactory: function (b,
c) { b = g(a, b, c); b.P = k; return b }, require: ~m ? q : void 0
} : g(a, [], function () { })
}); (t || u) && k.when("mix:@amzn/mix.client-runtime", "mix:" + f).execute(function (a, b) { a.registerCapabilityModule(f, b) }); k.when("mix:" + f).register("xcp:" + f, function (a) { return a }); var q = function (a, b, c) { try { var e = -1 < f.indexOf("/") ? f.split("/")[0] : f, d = a[0], g = d.lastIndexOf("./", 0) ? d : e + "/" + d.substr(2), h = g.lastIndexOf("@p/", 0) ? "mix:" + g : g.substr(3); k.when(h).execute(function (a) { try { b(a) } catch (x) { c(x) } }) } catch (w) { c(w) } }
}
} "use strict"; var r =
{}; b.mix_d || ((b.Promise ? P : P.when("3p-promise")).register("@p/promise-is-ready", function (a) { b.Promise = b.Promise || a }), (Array.prototype.includes ? P : P.when("a-polyfill")).register("@p/polyfill-is-ready", function () { }), b.mix_d = function (a, b, d) { P.when("@p/promise-is-ready", "@p/polyfill-is-ready").execute("@p/mix-d-deps", function () { q(a, b, d) }) }, b.xcp_d = b.mix_d, P.when("mix:@amzn/mix.client-runtime").execute(function (a) { P.declare("xcp:@xcp/runtime", a) })); b.mixTimeout || (b.mixTimeout = function (a, e, d) {
b.mixCardInitTimeouts ||
(b.mixCardInitTimeouts = {}); b.mixCardInitTimeouts[e] && clearTimeout(b.mixCardInitTimeouts[e]); b.mixCardInitTimeouts[e] = setTimeout(function () { P.log("Client-side initialization timeout", "WARN", a) }, d)
}); b.mix_csa_map = b.mix_csa_map || {}; b.mix_csa_internal = b.mix_csa_internal || function (a, e, d) { return b.mix_csa_map[e] = b.mix_csa_map[e] || b.csa(a, d) }; b.mix_csa_internal_key = b.mix_csa_internal_key || function (a, b) {
for (var d = "", e = 0; e < b.length; e++) { var c = b[e]; void 0 !== a[c] && "object" !== typeof a[c] && (d += c + ":" + a[c] + ",") } if (!d) throw Error("bad mix-csa key gen.");
return d
}; b.mix_csa_event = b.mix_csa_event || function (a) { try { var e = b.mix_csa_internal_key(a, ["producerId"]) } catch (d) { return P.logError(d, "MIX C005", "WARN", void 0), function () { } } try { return b.mix_csa_internal("Events", e, a) } catch (d) { return P.logError(d, "MIX C004", "WARN", e), function () { } } }; b.mix_csa = b.mix_csa || function (a, e) {
try {
e = e || ""; var d = document.querySelectorAll(a); if (1 < d.length) for (var g = 0; g < d.length; g++) { if (d[g].querySelector(e)) { var c = d[g]; break } } else 1 === d.length && (c = d[0]); if (!c) throw Error(" ");
return b.mix_csa_internal("Content", a, { element: c })
} catch (f) { return P.logError(f, "MIX C004", "WARN", a), function () { } }
}
})(window);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/61xJcNKKLXL.js?AUIClients/AmazonUIjQuery');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11zuylp74DL._RC|11Y+5x+kkTL.js,51cR93oXsVL.js,11yKORv-GTL.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01VRMV3FBdL.js,21u+kGQyRqL.js,012FVc3131L.js,11aD5q6kNBL.js,11rRjDLdAVL.js,51LgVZTDoFL.js,11nAhXzgUmL.js,119kvzYmMJL.js,1110g-SvlBL.js,11npBNHo-jL.js,21eKR4hvwNL.js,0190vxtlzcL.js,51P8J4TsllL.js,01JYHc2oIlL.js,31nfKXylf6L.js,01ktRCtOqKL.js,01ASnt2lbqL.js,11bEz2VIYrL.js,31o2NGTXThL.js,01rpauTep4L.js,31lTOzOlAqL.js,01tvglXfQOL.js,11Rf82oewsL.js,014gnDeJDsL.js,01A2fK8tgRL.js_.js?AUIClients/AmazonUI');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51BqsgbDI7L.js?AUIClients/CardJsRuntimeBuzzCopyBuild');
});
</script>
<!-- sp:end-feature:aui-assets -->
<!-- sp:feature:nav-inline-css -->
<!-- NAVYAAN CSS -->

<style type="text/css">
.nav-sprite-v1 .nav-sprite,
.nav-sprite-v1 .nav-icon {
background-image: url(https://m.media-amazon.com/images/G/35/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB542306881_.png);
background-position: 0 1000px;
background-repeat: repeat-x;
}

.nav-spinner {
background-image: url(https://m.media-amazon.com/images/G/35/javascripts/lib/popover/images/snake._CB485935562_.gif);
background-position: center center;
background-repeat: no-repeat;
}

.nav-timeline-icon,
.nav-access-image,
.nav-timeline-prime-icon {
background-image: url(https://m.media-amazon.com/images/G/35/gno/sprites/timeline_sprite_1x._CB439967963_.png);
background-repeat: no-repeat;
}
</style>
<link rel="stylesheet"
href="https://images-fe.ssl-images-amazon.com/images/I/41UUdmm7zEL._RC|71ssTfUrzlL.css,51e-e3YDwLL.css,21q6fHDJ0OL.css,21Hc1s0-E4L.css,31YZpDCYJPL.css,21pkK7OQMnL.css,41EtvNY2OrL.css,110Nj+wUGYL.css,31K0jc2KvHL.css,01R53xsjpjL.css,21KQnzhmfTL.css,415g7iDx4VL.css_.css?AUIClients/NavDesktopUberAsset&cVsltbCc#desktop.878681-T1.1088933-T1" />
<!-- sp:end-feature:nav-inline-css -->
<!-- sp:feature:host-assets -->
<script>
(function (e) { var a = window.AmazonUIPageJS || window.P, c = a._namespace || a.attributeErrors, b = c ? c("DetailPageLatencyClientSideLibraries@timeToInteractive", "DetailPageLatencyClientSideLibraries") : a; b.guardFatal ? b.guardFatal(e)(b, window) : b.execute(function () { e(b, window) }) })(function (e, a, c) {
e.now().execute("dp-create-feature-interactive-api", function () {
function b(d, b, a) { d = { name: d, options: b, type: a, timestamp: +new Date }; f ? f.updateFeatures([d]) : c.push(d) } "function" === typeof uet && uet("bb", "clickToCI", { wb: 1 }); var c =
[], f; a.markFeatureRender = function (d, a) { b(d, a, "render") }; a.markFeatureInteractive = function (a, c) { b(a, c, "interactive") }; e.when("dp-time-to-interactive").execute("dp-update-interactive-feature-list", function (a) { f = a; c.length && f.updateFeatures(c) })
})
});
</script>

<!-- htmlBeginMarker --><!--&&&Portal&Delimite-->
<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->
<!-- sp:feature:encrypted-slate-token -->
<meta name='encrypted-slate-token'
content='AnYxIhB+REZh/SzZUc/Dyi7Vt6yuwnP+AB9nR+DxFvq67jYIhV++iSwWdi3KoC7vXxblL1iPeKF6lRX3UIxkp401mUkrT6KwVM647+K/7JMiErj8eapyU0PXJFCSwaRYShAA6Fl+iMwbinmlQRH9pVlm5eworN7mQVrcWXm+hSa+VkhpMTWhpwjyGVShvRn+7oZ07wrivJE2zvmr6iLXwvTiDB2JiGjkM1phxZBvb8/RBlBgD39qxiGDdncM8jrMipPWMZKKuLsIPK8wnWU='>
<!-- sp:end-feature:encrypted-slate-token -->
<!-- sp:feature:csm:head-close -->
<script type='text/javascript'>
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function (c) { c && 1 === c.ue_jsmtf && "object" === typeof c.P && "function" === typeof c.P.when && c.P.when("mshop-interactions").execute(function (e) { "object" === typeof e && "function" === typeof e.addListener && e.addListener(function (b) { "object" === typeof b && "ORIGIN" === b.dataSource && "number" === typeof b.clickTime && "object" === typeof b.events && "number" === typeof b.events.pageVisible && (c.ue_jsmtf_interaction = { pv: b.events.pageVisible, ct: b.clickTime }) }) }) })(ue_csm);
(function (c, e, b) {
function m(a) { f || (f = d[a.type].id, "undefined" === typeof a.clientX ? (h = a.pageX, k = a.pageY) : (h = a.clientX, k = a.clientY), 2 != f || l && (l != h || n != k) ? (r(), g.isl && e.setTimeout(function () { p("at", g.id) }, 0)) : (l = h, n = k, f = 0)) } function r() { for (var a in d) d.hasOwnProperty(a) && g.detach(a, m, d[a].parent) } function s() { for (var a in d) d.hasOwnProperty(a) && g.attach(a, m, d[a].parent) } function t() { var a = ""; !q && f && (q = 1, a += "&ui=" + f); return a } var g = c.ue, p = c.uex, q = 0, f = 0, l, n, h, k, d = {
click: { id: 1, parent: b }, mousemove: {
id: 2,
parent: b
}, scroll: { id: 3, parent: e }, keydown: { id: 4, parent: b }
}; g && p && (s(), g._ui = t)
})(ue_csm, window, document);


(function (s, l) {
function m(b, e, c) { c = c || new Date(+new Date + t); c = "expires=" + c.toUTCString(); n.cookie = b + "=" + e + ";" + c + ";path=/" } function p(b) { b += "="; for (var e = n.cookie.split(";"), c = 0; c < e.length; c++) { for (var a = e[c]; " " == a.charAt(0);)a = a.substring(1); if (0 === a.indexOf(b)) return decodeURIComponent(a.substring(b.length, a.length)) } return "" } function q(b, e, c) {
if (!e) return b; -1 < b.indexOf("{") && (b = ""); for (var a = b.split("&"), f, d = !1, h = !1, g = 0; g < a.length; g++)f = a[g].split(":"), f[0] == e ? (!c || d ? a.splice(g, 1) : (f[1] = c, a[g] =
f.join(":")), h = d = !0) : 2 > f.length && (a.splice(g, 1), h = !0); h && (b = a.join("&")); !d && c && (0 < b.length && (b += "&"), b += e + ":" + c); return b
} var k = s.ue || {}, t = 3024E7, n = ue_csm.document || l.document, r = null, d; a: { try { d = l.localStorage; break a } catch (u) { } d = void 0 } k.count && k.count("csm.cookieSize", document.cookie.length); k.cookie = {
get: p, set: m, updateCsmHit: function (b, e, c) {
try {
var a; if (!(a = r)) { var f; a: { try { if (d && d.getItem) { f = d.getItem("csm-hit"); break a } } catch (k) { } f = void 0 } a = f || p("csm-hit") || "{}" } a = q(a, b, e); r = a = q(a, "t", +new Date);
try { d && d.setItem && d.setItem("csm-hit", a) } catch (h) { } m("csm-hit", a, c)
} catch (g) { "function" == typeof l.ueLogError && ueLogError(Error("Cookie manager: " + g.message), { logLevel: "WARN" }) }
}
}
})(ue_csm, window);


(function (l, e) {
function c(b) { b = ""; var c = a.isBFT ? "b" : "s", d = "" + a.oid, g = "" + a.lid, h = d; d != g && 20 == g.length && (c += "a", h += "-" + g); a.tabid && (b = a.tabid + "+"); b += c + "-" + h; b != f && 100 > b.length && (f = b, a.cookie ? a.cookie.updateCsmHit(m, b + ("|" + +new Date)) : e.cookie = "csm-hit=" + b + ("|" + +new Date) + n + "; path=/") } function p() { f = 0 } function d(b) { !0 === e[a.pageViz.propHid] ? f = 0 : !1 === e[a.pageViz.propHid] && c({ type: "visible" }) } var n = "; expires=" + (new Date(+new Date + 6048E5)).toGMTString(), m = "tb", f, a = l.ue || {}, k = a.pageViz && a.pageViz.event &&
a.pageViz.propHid; a.attach && (a.attach("click", c), a.attach("keyup", c), k || (a.attach("focus", c), a.attach("blur", p)), k && (a.attach(a.pageViz.event, d, e), d({}))); a.aftb = 1
})(ue_csm, ue_csm.document);


ue_csm.ue.stub(ue, "impression");


ue.stub(ue, "trigger");


if (window.ue && uet) { uet('bb'); }

}
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 3172)</script>
<!-- sp:end-feature:csm:head-close -->
<!-- sp:feature:head-close -->
<script>
window.P && P.register('bb');
if (typeof ues === 'function') {
ues('t0', 'portal-bb', new Date());
ues('ctb', 'portal-bb', 1);
}
</script>
</head><!-- sp:end-feature:head-close -->
<!-- sp:feature:start-body -->

<body
class="a-aui_72554-c a-aui_a11y_6_837773-t2 a-aui_amzn_img_959719-c a-aui_amzn_img_gate_959718-c a-aui_killswitch_csa_logger_372963-c a-aui_pci_risk_banner_210084-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-bw_aui_cxc_alert_measurement_1074111-c">
<span hidden id="template-version">amzn</span>
<div id="a-page">
<script type="a-state"
data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_AMZN_IMG_959719":"C","AUI_A11Y_6_837773":"T2","AUI_TNR_V2_180836":"C","AUI_AMZN_IMG_GATE_959718":"C","AUI_TEMPLATE_WEBLAB_CACHE_333406":"C","BW_AUI_CXC_ALERT_MEASUREMENT_1074111":"C","AUI_72554":"C","AUI_KILLSWITCH_CSA_LOGGER_372963":"C","AUI_PCI_RISK_BANNER_210084":"C"}</script>
<script>typeof uex === 'function' && uex('ld', 'portal-bb', { wb: 1 })</script><!-- sp:end-feature:start-body -->
<!-- sp:feature:csm:body-open -->


<script>
!function () { function n(n, t) { var r = i(n); return t && (r = r("instance", t)), r } var r = [], c = 0, i = function (t) { return function () { var n = c++; return r.push([t, [].slice.call(arguments, 0), n, { time: Date.now() }]), i(n) } }; n._s = r, this.csa = n }();;
csa('Config', {});
if (window.csa) {
csa("Config", {
'Application': 'Retail:Prod:www.amazon.com.au',
'Events.Namespace': 'csa',
'ObfuscatedMarketplaceId': 'A39IBJ37TRP1C6',
'Events.SushiEndpoint': 'https://unagi.amazon.com.au/1/events/com.amazon.csm.csa.prod',
'CacheDetection.RequestID': "90G9DFKSFRKCQZ4KHD88",
'CacheDetection.Callback': window.ue && ue.reset,
'LCP.elementDedup': 1,
'lob': '1'
});

csa("Events")("setEntity", {
page: { requestId: "90G9DFKSFRKCQZ4KHD88", meaningful: "interactive" },
session: { id: "356-1077062-4831846" }
});
}
!function (r) { var e, i, o = "splice", u = r.csa, f = {}, c = {}, a = r.csa._s, s = 0, l = 0, g = -1, h = {}, v = {}, d = {}, n = Object.keys, p = function () { }; function t(n, t) { return u(n, t) } function m(n, t) { var r = c[n] || {}; k(r, t), c[n] = r, l++, S(U, 0) } function w(n, t, r) { var i = !0; return t = D(t), r && r.buffered && (i = (d[n] || []).every(function (n) { return !1 !== t(n) })), i ? (h[n] || (h[n] = []), h[n].push(t), function () { !function (n, t) { var r = h[n]; r && r[o](r.indexOf(t), 1) }(n, t) }) : p } function b(n, t) { if (t = D(t), n in v) return t(v[n]), p; return w(n, function (n) { return t(n), !1 }) } function y(n, t) { if (u("Errors")("logError", n), f.DEBUG) throw t || n } function E() { return Math.abs(4294967295 * Math.random() | 0).toString(36) } function D(n, t) { return function () { try { return n.apply(this, arguments) } catch (n) { y(n.message || n, n) } } } function S(n, t) { return r.setTimeout(D(n), t) } function U() { for (var n = 0; n < a.length;) { var t = a[n], r = t[0] in c; if (!r && !i) return void (s = a.length); r ? (a[o](s = n, 1), I(t)) : n++ } g = l } function I(n) { var t = c[n[0]], r = n[1], i = r[0]; if (!t || !t[i]) return y("Undefined function: " + t + "/" + i); e = n[3], c[n[2]] = t[i].apply(t, r.slice(1)) || {}, e = 0 } function O() { i = 1, U() } function k(t, r) { n(r).forEach(function (n) { t[n] = r[n] }) } b("$beforeunload", O), m("Config", { instance: function (n) { k(f, n) } }), u.plugin = D(function (n) { n(t) }), t.config = f, t.register = m, t.on = w, t.once = b, t.blank = p, t.emit = function (n, t, r) { for (var i = h[n] || [], e = 0; e < i.length;)!1 === i[e](t) ? i[o](e, 1) : e++; v[n] = t || {}, r && r.buffered && (d[n] || (d[n] = []), 100 <= d[n].length && d[n].shift(), d[n].push(t || {})) }, t.UUID = function () { return [E(), E(), E(), E()].join("-") }, t.time = function (n) { var t = e ? new Date(e.time) : new Date; return "ISO" === n ? t.toISOString() : t.getTime() }, t.error = y, t.warn = function (n, t) { if (u("Errors")("logWarn", n), f.DEBUG) throw t || n }, t.exec = D, t.timeout = S, t.interval = function (n, t) { return r.setInterval(D(n), t) }, (t.global = r).csa._s.push = function (n) { n[0] in c && (!a.length || i) ? (I(n), a.length && g !== l && U()) : a[o](s++, 0, n) }, U(), S(function () { S(O, f.SkipMissingPluginsTimeout || 5e3) }, 1) }("undefined" != typeof window ? window : global); csa.plugin(function (o) { var f = "addEventListener", e = "requestAnimationFrame", t = o.exec, r = o.global, u = o.on; o.raf = function (n) { if (r[e]) return r[e](t(n)) }, o.on = function (n, e, t, r) { if (n && "function" == typeof n[f]) { var i = o.exec(t); return n[f](e, i, r), function () { n.removeEventListener(e, i, r) } } return "string" == typeof n ? u(n, e, t, r) : o.blank } }); csa.plugin(function (o) { var t, n, r = {}, e = "localStorage", c = "sessionStorage", a = "local", i = "session", u = o.exec; function s(e, t) { var n; try { r[t] = !!(n = o.global[e]), n = n || {} } catch (e) { r[t] = !(n = {}) } return n } function f() { t = t || s(e, a), n = n || s(c, i) } function l(e) { return e && e[i] ? n : t } o.store = u(function (e, t, n) { f(); var o = l(n); return e ? t ? void (o[e] = t) : o[e] : Object.keys(o) }), o.storageSupport = u(function () { return f(), r }), o.deleteStored = u(function (e, t) { f(); var n = l(t); if ("function" == typeof e) for (var o in n) n.hasOwnProperty(o) && e(o, n[o]) && delete n[o]; else delete n[e] }) }); csa.plugin(function (n) { n.types = { ovl: function (n) { var r = []; if (n) for (var i in n) n.hasOwnProperty(i) && r.push(n[i]); return r } } }); csa.plugin(function (c) { var e = c.config, n = "Errors"; function r(n) { return function (e) { c("Metrics", { producerId: "csa", dimensions: { message: e } })("recordMetric", n, 1) } } function o(r) { var o, t, l = c("Events", { producerId: r.producerId, lob: e.lob || "0" }), i = ["name", "type", "csm", "adb"], u = { url: "pageURL", file: "f", line: "l", column: "c" }; this.log = function (e) { if (!function (e) { if (!e) return !0; for (var n in e) return !1; return !0 }(e)) { var n = r.logOptions || { ent: { page: ["pageType", "subPageType", "requestId"] } }; l("log", function (n) { return o = c.UUID(), t = { messageId: o, schemaId: r.schemaId || "<ns>.Error.6", errorMessage: n.m || null, attribution: n.attribution || null, logLevel: "FATAL", url: null, file: null, line: null, column: null, stack: n.s || [], context: n.cinfo || {}, metadata: {} }, n.logLevel && (t.logLevel = "" + n.logLevel), i.forEach(function (e) { n[e] && (t.metadata[e] = n[e]) }), "INFO" === n.logLevel || Object.keys(u).forEach(function (e) { "number" != typeof n[u[e]] && "string" != typeof n[u[e]] || (t[e] = "" + n[u[e]]) }), t }(e), n) } } } e["KillSwitch." + n] || c.register(n, { instance: function (e) { return new o(e || {}) }, logError: r("jsError"), logWarn: r("jsWarn") }) }); csa.plugin(function (o) { var r, e, n, t, a, i = "function", u = "willDisappear", f = "$app.", p = "$document.", c = "focus", s = "blur", d = "active", l = "resign", $ = o.global, b = o.exec, m = o.config["Transport.AnonymizeRequests"] || !1, g = o("Events"), h = $.location, v = $.document || {}, y = $.P || {}, P = (($.performance || {}).navigation || {}).type, w = o.on, k = o.emit, E = v.hidden, T = {}; h && v && (w($, "beforeunload", D), w($, "pagehide", D), w(v, "visibilitychange", R(p, function () { return v.visibilityState || "unknown" })), w(v, c, R(p + c)), w(v, s, R(p + s)), y.when && y.when("mash").execute(function (e) { e && (w(e, "appPause", R(f + "pause")), w(e, "appResume", R(f + "resume")), R(f + "deviceready")(), $.cordova && $.cordova.platformId && R(f + cordova.platformId)(), w(v, d, R(f + d)), w(v, l, R(f + l))) }), e = $.app || {}, n = b(function () { k(f + "willDisappear"), D() }), a = typeof (t = e[u]) == i, e[u] = b(function () { n(), a && t() }), $.app || ($.app = e), "complete" === v.readyState ? A() : w($, "load", A), E ? S() : x(), o.on("$app.blur", S), o.on("$app.focus", x), o.on("$document.blur", S), o.on("$document.focus", x), o.on("$document.hidden", S), o.on("$document.visible", x), o.register("SPA", { newPage: I }), I({ transitionType: { 0: "hard", 1: "refresh", 2: "back-button" }[P] || "unknown" })); function I(n, e) { var t = !!r, a = (e = e || {}).keepPageAttributes; t && (k("$beforePageTransition"), k("$pageTransition")), t && !a && g("removeEntity", "page"), r = o.UUID(), a ? T.id = r : T = { schemaId: "<ns>.PageEntity.2", id: r, url: m ? h.href.split("?")[0] : h.href, server: h.hostname, path: h.pathname, referrer: m ? v.referrer.split("?")[0] : v.referrer, title: v.title }, Object.keys(n || {}).forEach(function (e) { T[e] = n[e] }), g("setEntity", { page: T }), k("$pageChange", T, { buffered: 1 }), t && k("$afterPageTransition") } function A() { k("$load"), k("$ready"), k("$afterload") } function D() { k("$ready"), k("$beforeunload"), k("$unload"), k("$afterunload") } function S() { E || (k("$visible", !1, { buffered: 1 }), E = !0) } function x() { E && (k("$visible", !0, { buffered: 1 }), E = !1) } function R(n, t) { return b(function () { var e = typeof t == i ? n + t() : n; k(e) }) } }); csa.plugin(function (c) { var e = "Events", n = "UNKNOWN", s = "id", a = "all", i = "messageId", o = "timestamp", u = "producerId", r = "application", f = "obfuscatedMarketplaceId", d = "entities", l = "schemaId", p = "version", v = "attributes", g = "<ns>", b = "lob", t = "session", h = c.config, m = (c.global.location || {}).host, I = h[e + ".Namespace"] || "csa_other", y = h.Application || "Other" + (m ? ":" + m : ""), O = h["Transport.AnonymizeRequests"] || !1, E = c("Transport"), U = {}, A = function (e, t) { Object.keys(e).forEach(t) }; function N(n, i, o) { A(i, function (e) { var t = o === a || (o || {})[e]; e in n || (n[e] = { version: 1, id: i[e][s] || c.UUID() }), S(n[e], i[e], t) }) } function S(t, n, i) { A(n, function (e) { !function (e, t, n) { return "string" != typeof t && e !== p ? c.error("Attribute is not of type string: " + e) : !0 === n || 1 === n || (e === s || !!~(n || []).indexOf(e)) }(e, n[e], i) || (t[e] = n[e]) }) } function k(o, e, r) { A(e, function (e) { var t = o[e]; if (t[l]) { var n = {}, i = {}; n[s] = t[s], n[u] = t[u] || r[u], n[l] = t[l], n[p] = t[p]++, n[v] = i, w(n, r), S(i, t, 1), D(i), E("log", n) } }) } function w(e, t) { e[o] = function (e) { return "number" == typeof e && (e = new Date(e).toISOString()), e || c.time("ISO") }(e[o]), e[i] = e[i] || c.UUID(), e[r] = y, e[f] = h.ObfuscatedMarketplaceId || n, e[l] = e[l].replace(g, I), t && t[b] && (e[b] = t[b]) } function D(e) { delete e[p], delete e[l], delete e[u] } function T(o) { var r = {}; this.log = function (e, t) { var n = {}, i = (t || {}).ent; return e ? "string" != typeof e[l] ? c.error("A valid schema id is required for the event") : (w(e, o), N(n, U, i), N(n, r, i), N(n, e[d] || {}, i), A(n, function (e) { D(n[e]) }), e[u] = o[u], e[d] = n, t && t[b] && (e[b] = t[b]), void E("log", e, t)) : c.error("The event cannot be undefined") }, this.setEntity = function (e) { O && delete e[t], N(r, e, a), k(r, e, o) } } h["KillSwitch." + e] || c.register(e, { setEntity: function (e) { O && delete e[t], c.emit("$entities.set", e, { buffered: 1 }), N(U, e, a), k(U, e, { producerId: "csa", lob: h[b] || "0" }) }, removeEntity: function (e) { delete U[e] }, instance: function (e) { return new T(e) } }) }); csa.plugin(function (s) { var c, g = "Transport", l = "post", f = "preflight", r = "csa.cajun.", i = "store", a = "deleteStored", u = "sendBeacon", t = "__merge", e = "messageId", n = ".FlushInterval", o = 0, d = s.config[g + ".BufferSize"] || 2e3, h = s.config[g + ".RetryDelay"] || 1500, p = s.config[g + ".AnonymizeRequests"] || !1, v = {}, y = 0, m = [], E = s.global, R = E.document, b = s.timeout, k = E.Object.keys, w = s.config[g + n] || 5e3, I = w, O = s.config[g + n + ".BackoffFactor"] || 1, S = s.config[g + n + ".BackoffLimit"] || 3e4, B = 0; function T(n) { if (864e5 < s.time() - +new Date(n.timestamp)) return s.warn("Event is too old: " + n); y < d && (n[e] in v || (v[n[e]] = n, y++), "function" == typeof n[t] && n[t](v[n[e]]), !B && o && (B = b(q, function () { var n = I; return I = Math.min(n * O, S), n }()))) } function q() { m.forEach(function (e) { var o = []; k(v).forEach(function (n) { var t = v[n]; e.accepts(t) && o.push(t) }), o.length && (e.chunks ? e.chunks(o).forEach(function (n) { D(e, n) }) : D(e, o)) }), v = {}, B = 0 } function D(t, e) { function o() { s[a](r + n) } var n = s.UUID(); s[i](r + n, JSON.stringify(e)), [function (n, t, e) { var o = E.navigator || {}, r = E.cordova || {}; if (p) return 0; if (!o[u] || !n[l]) return 0; n[f] && r && "ios" === r.platformId && !c && ((new Image).src = n[f]().url, c = 1); var i = n[l](t); if (!i.type && o[u](i.url, i.body)) return e(), 1 }, function (n, t, e) { if (!n[l]) return 0; var o = n[l](t), r = o.url, i = o.body, c = o.type, f = new XMLHttpRequest, a = 0; function u(n, t, e) { f.open("POST", n), f.withCredentials = !p, e && f.setRequestHeader("Content-Type", e), f.send(t) } return f.onload = function () { f.status < 299 ? e() : s.config[g + ".XHRRetries"] && a < 3 && b(function () { u(r, i, c) }, ++a * h) }, u(r, i, c), 1 }].some(function (n) { try { return n(t, e, o) } catch (n) { } }) } k && (s.once("$afterload", function () { o = 1, function (e) { (s[i]() || []).forEach(function (n) { if (!n.indexOf(r)) try { var t = s[i](n); s[a](n), JSON.parse(t).forEach(e) } catch (n) { s.error(n) } }) }(T), s.on(R, "visibilitychange", q, !1), q() }), s.once("$afterunload", function () { o = 1, q() }), s.on("$afterPageTransition", function () { y = 0, I = w }), s.register(g, { log: T, register: function (n) { m.push(n) } })) }); csa.plugin(function (n) { var r = n.config["Events.SushiEndpoint"]; n("Transport")("register", { accepts: function (n) { return n.schemaId }, post: function (n) { var t = n.map(function (n) { return { data: n } }); return { url: r, body: JSON.stringify({ events: t }) } }, preflight: function () { var n, t = /\/\/(.*?)\//.exec(r); return t && t[1] && (n = "https://" + t[1] + "/ping"), { url: n } }, chunks: function (n) { for (var t = []; 500 < n.length;)t.push(n.splice(0, 500)); return t.push(n), t } }) }); csa.plugin(function (n) { var t, a, o, r, e = n.config, i = "PageViews", d = e[i + ".ImpressionMinimumTime"] || 1e3, s = "hidden", c = "innerHeight", l = "innerWidth", g = "renderedTo", f = g + "Viewed", m = g + "Meaningful", u = g + "Impressed", p = 1, h = 2, v = 3, w = 4, P = 5, y = "loaded", I = 7, b = 8, T = n.global, S = n.on, E = n("Events", { producerId: "csa", lob: e.lob || "0" }), K = T.document, V = {}, $ = {}, M = P, R = e["KillSwitch." + i], H = e["KillSwitch.PageRender"], W = e["KillSwitch.PageImpressed"]; function j(e) { if (!V[I]) { if (V[e] = n.time(), e !== v && e !== y || (t = t || V[e]), t && M === w) { if (a = a || V[e], !R) (i = {})[m] = t - o, i[f] = a - o, k("PageView.5", i); r = r || n.timeout(x, d) } var i; if (e !== P && e !== p && e !== h || (clearTimeout(r), r = 0), e !== p && e !== h || H || k("PageRender.4", { transitionType: e === p ? "hard" : "soft" }), e === I && !W) (i = {})[m] = t - o, i[f] = a - o, i[u] = V[e] - o, k("PageImpressed.3", i) } } function k(e, i) { $[e] || (i.schemaId = "<ns>." + e, E("log", i, { ent: "all" }), $[e] = 1) } function q() { 0 === T[c] && 0 === T[l] ? (M = b, n("Events")("setEntity", { page: { viewport: "hidden-iframe" } })) : M = K[s] ? P : w, j(M) } function x() { j(I), r = 0 } function z() { var e = o ? h : p; V = {}, $ = {}, a = t = 0, o = n.time(), j(e), q() } function A() { var e = K.readyState; "interactive" === e && j(v), "complete" === e && j(y) } K && void 0 !== K[s] ? (z(), S(K, "visibilitychange", q, !1), S(K, "readystatechange", A, !1), S("$afterPageTransition", z), S("$timing:loaded", A), n.once("$load", A)) : n.warn("Page visibility not supported") }); csa.plugin(function (c) { var s = c.config["Interactions.ParentChainLength"] || 35, e = "click", r = "touches", f = "timeStamp", o = "length", u = "pageX", g = "pageY", p = "pageXOffset", h = "pageYOffset", m = 250, v = 5, d = 200, l = .5, t = { capture: !0, passive: !0 }, X = c.global, Y = c.emit, n = c.on, x = X.Math.abs, a = (X.document || {}).documentElement || {}, y = { x: 0, y: 0, t: 0, sX: 0, sY: 0 }, N = { x: 0, y: 0, t: 0, sX: 0, sY: 0 }; function b(t) { if (t.id) return "//*[@id='" + t.id + "']"; var e = function (t) { var e, n = 1; for (e = t.previousSibling; e; e = e.previousSibling)e.nodeName === t.nodeName && (n += 1); return n }(t), n = t.nodeName; return 1 !== e && (n += "[" + e + "]"), t.parentNode && (n = b(t.parentNode) + "/" + n), n } function I(t, e, n) { var a = c("Content", { target: n }), i = { schemaId: "<ns>.ContentInteraction.2", interaction: t, interactionData: e, messageId: c.UUID() }; if (n) { var r = b(n); r && (i.attribution = r); var o = function (t) { for (var e = t, n = e.tagName, a = !1, i = t ? t.href : null, r = 0; r < s; r++) { if (!e || !e.parentElement) { a = !0; break } n = (e = e.parentElement).tagName + "/" + n, i = i || e.href } return a || (n = ".../" + n), { pc: n, hr: i } }(n); o.pc && (i.interactionData.parentChain = o.pc), o.hr && (i.interactionData.href = o.hr) } a("log", i), Y("$content.interaction", { e: i, w: a }) } function i(t) { I(e, { interactionX: "" + t.pageX, interactionY: "" + t.pageY }, t.target) } function C(t) { if (t && t[r] && 1 === t[r][o]) { var e = t[r][0]; N = y = { e: t.target, x: e[u], y: e[g], t: t[f], sX: X[p], sY: X[h] } } } function D(t) { if (t && t[r] && 1 === t[r][o] && y && N) { var e = t[r][0], n = t[f], a = n - N.t, i = { e: t.target, x: e[u], y: e[g], t: n, sX: X[p], sY: X[h] }; N = i, d <= a && (y = i) } } function E(t) { if (t) { var e = x(y.x - N.x), n = x(y.y - N.y), a = x(y.sX - N.sX), i = x(y.sY - N.sY), r = t[f] - y.t; if (m < 1e3 * e / r && v < e || m < 1e3 * n / r && v < n) { var o = n < e; o && a && e * l <= a || !o && i && n * l <= i || I((o ? "horizontal" : "vertical") + "-swipe", { interactionX: "" + y.x, interactionY: "" + y.y, endX: "" + N.x, endY: "" + N.y }, y.e) } } } n(a, e, i, t), n(a, "touchstart", C, t), n(a, "touchmove", D, t), n(a, "touchend", E, t) }); csa.plugin(function (r) { var a, o, t, c, e, n = "MutationObserver", f = "observe", u = "disconnect", i = "mutObs", l = "_csa_flt", b = "_csa_llt", m = "_csa_mr", d = "_csa_mi", v = "lastChild", p = "length", _ = { childList: !0, subtree: !0 }, g = 10, h = 25, s = 1e3, y = 4, O = r.global, k = O.document, w = k.body || k.documentElement, I = Date.now, L = [], B = [], M = [], Y = 0, $ = 0, x = 0, A = 1, C = [], D = [], E = 0, F = r.blank, N = { buffered: 1 }, S = 0; function T(e) { r.global.ue_csa_ss_tag || r.emit("$csmTag:" + e, 0, N) } I && O[n] ? (T(i + "Yes"), Y = 0, o = new O[n](j), (t = new O[n](V))[f](w, { attributes: !0, subtree: !0, attributeFilter: ["src"], attributeOldValue: !0 }), F = r.on(O, "scroll", q, { passive: !0 }), r.once("$ready", H), A && (G(), e = r.interval(z, s)), r.register("SpeedIndexBuffers", { getBuffers: function (e) { e && (H(), q(), e(Y, C, L, B, M), o && o[u](), t && t[u](), F()) }, registerListener: function (e) { a = e }, replayModuleIsLive: function () { r.timeout(H, 0) } })) : T(i + "No"); function V(e) { L.push({ t: I(), m: e }) } function j(e) { B.push({ t: I(), m: e }), S || T(i + "Active"), S = x = 1, a && a() } function q() { x && (M.push({ t: I(), y: $ }), $ = O.pageYOffset, x = 0) } function z() { var e = I(); (!c || s < e - c) && G() } function G() { for (var e = w, t = I(), n = [], u = [], i = 0, s = 0; e;)e[l] ? ++i : (e[l] = t, n.push(e), s = 1), u[p] < y && u.push(e), e[d] = E, e[b] = t, e = e[v]; s && (i < D[p] && function (e) { for (var t = e, n = D[p]; t < n; t++) { var u = D[t]; if (u) { if (u[m]) break; if (u[d] < E) { u[m] = 1, o[f](u, _); break } } } }(i), D = u, C.push({ t: t, m: n }), ++E, x = s, a && a()), A&& r.timeout(G, s ? g : h), c = t } function H() { A && (A = 0, e && O.clearInterval(e), e = null, G(), o[f](w, _)) } });

var ue_csa_ss_tag = false;
csa.plugin(function (b) {
var a = b.global, e = a.uet, f = a.uex, c = a.ue, d = a.Object, g = 0, h = { largestContentfulPaint: "lcp", speedIndex: "si", atfSpeedIndex: "atfsi", visuallyLoaded50: "vl50", visuallyLoaded90: "vl90", visuallyLoaded100: "vl100" }, l = "perfNo perfYes browserQuiteFn browserQuiteUd browserQuiteLd browserQuiteMut mutObsNo mutObsYes mutObsActive startVL endVL".split(" "); b && e && f && d.keys && c && (b.once("$ditched.beforemitigation", function () { g = 1 }), d.keys(h).forEach(function (k) {
b.on("$timing:" + k, function (b) {
var a = h[k];
if (c.isl || g) { var d = "csa:" + a; e(a, d, void 0, b); f("at", d) } else e(a, void 0, void 0, b)
})
}), a.ue_csa_ss_tag || l.forEach(function (a) { b.on("$csmTag:" + a, function () { c.tag && c.tag(a); (c.isl || g) && f("at", "csa:" + a) }, { buffered: 1 }) }))
});


window.rx = { 'rid': '90G9DFKSFRKCQZ4KHD88', 'sid': '356-1077062-4831846', 'c': { 'rxp': '/rd/uedata' } };
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 16309)</script>
<!-- sp:end-feature:csm:body-open -->
<!-- sp:feature:nav-inline-js -->
<!-- NAVYAAN JS -->

<script
type="text/javascript">!function (n) { function e(n, e) { return { m: n, a: function (n) { return [].slice.call(n) }(e) } } document.createElement("header"); var r = function (n) { function u(n, r, u) { n[u] = function () { a._replay.push(r.concat(e(u, arguments))) } } var a = {}; return a._sourceName = n, a._replay = [], a.getNow = function (n, e) { return e }, a.when = function () { var n = [e("when", arguments)], r = {}; return u(r, n, "run"), u(r, n, "declare"), u(r, n, "publish"), u(r, n, "build"), r.depends = n, r.iff = function () { var r = n.concat([e("iff", arguments)]), a = {}; return u(a, r, "run"), u(a, r, "declare"), u(a, r, "publish"), u(a, r, "build"), a }, r }, u(a, [], "declare"), u(a, [], "build"), u(a, [], "publish"), u(a, [], "importEvent"), r._shims.push(a), a }; r._shims = [], n.$Nav || (n.$Nav = r("rcx-nav")), n.$Nav.make || (n.$Nav.make = r) }(window)
</script>
<script type="text/javascript">
$Nav.importEvent('navbarJS-beaconbelt');
$Nav.declare('img.sprite', {
'png32': 'https://m.media-amazon.com/images/G/35/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB542306881_.png',
'png32-2x': 'https://m.media-amazon.com/images/G/35/gno/sprites/nav-sprite-global-2x-reorg-privacy._CB542306881_.png'
});
$Nav.declare('img.timeline', {
'timeline-icon-2x': 'https://m.media-amazon.com/images/G/35/gno/sprites/timeline_sprite_2x._CB443580944_.png'
});
window._navbarSpriteUrl = 'https://m.media-amazon.com/images/G/35/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB542306881_.png';
$Nav.declare('img.pixel', 'https://m.media-amazon.com/images/G/35/x-locale/common/transparent-pixel._CB485934982_.gif');
</script>

<img src="https://m.media-amazon.com/images/G/35/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB542306881_.png"
style="display:none" alt="" />
<script type="text/javascript">var nav_t_after_preload_sprite = + new Date();</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-fe.ssl-images-amazon.com/images/I/51V5yVZxXVL._RC|71ExNL6cASL.js,01Wy3BI8GpL.js,01YmCfnBlcL.js,71Yg5iKSntL.js,41jBieyCvYL.js,01wXnKULArL.js,01+pnQJuQ0L.js,21Un7Tx1UGL.js,41RO+XSKWML.js,51HrkAbbpLL.js,31dscPpq-UL.js,11lw6J7z8iL.js,31+UifI0MIL.js,01VYGE8lGhL.js_.js?AUIClients/NavDesktopUberAsset&dLQFff3p#desktop.language-id.878681-T1.803398-T1.970718-T1');
});
</script>
<!-- sp:end-feature:nav-inline-js -->
<!-- sp:feature:nav-skeleton -->
<!-- sp:end-feature:nav-skeleton -->
<!-- sp:feature:navbar -->

<!--Pilu -->


<!-- NAVYAAN -->











<!-- navmet initial definition -->



<script type='text/javascript'>
if (window.navmet === undefined) {
window.navmet = [];
if (window.performance && window.performance.timing && window.ue_t0) {
var t = window.performance.timing;
var now = + new Date();
window.navmet.basic = {
'networkLatency': (t.responseStart - t.fetchStart),
'navFirstPaint': (now - t.responseStart),
'NavStart': (now - window.ue_t0)
};
window.navmet.push({ key: "NavFirstPaintStart", end: +new Date(), begin: window.ue_t0 });
}
}
if (window.ue_t0) {
window.navmet.push({ key: "NavMainStart", end: +new Date(), begin: window.ue_t0 });
}
</script>




<script type='text/javascript'>window.navmet.tmp = +new Date();</script>
<script type='text/javascript'>
// Nav start should be logged at this place only if request is NOT progressively loaded.
// For progressive loading case this metric is logged as part of skeleton.
// Presence of skeleton signals that request is progressively loaded.
if (!document.getElementById("navbar-skeleton")) {
window.uet && uet('ns');
}
window._navbar = (function (o) {
o.componentLoaded = o.loading = function () { };
o.browsepromos = {};
o.issPromos = [];
return o;
}(window._navbar || {}));
window._navbar.declareOnLoad = function () { window.$Nav && $Nav.declare('page.load'); };
if (window.addEventListener) {
window.addEventListener("load", window._navbar.declareOnLoad, false);
} else if (window.attachEvent) {
window.attachEvent("onload", window._navbar.declareOnLoad);
} else if (window.$Nav) {
$Nav.when('page.domReady').run("OnloadFallbackSetup", function () {
window._navbar.declareOnLoad();
});
}
window.$Nav && $Nav.declare('logEvent.enabled',
'false');

window.$Nav && $Nav.declare('config.lightningDeals', {});
</script>

<style mark="aboveNavInjectionCSS" type="text/css">
div#navSwmHoliday.nav-focus {
border: none;
margin: 0;
}

div.navFooterLine {
white-space: normal;
}

#nav-flyout-ewc .nav-flyout-buffer-left {
display: none;
}

#nav-flyout-ewc .nav-flyout-buffer-right {
display: none;
}
</style>
<script mark="aboveNavInjectionJS" type="text/javascript">
try {
window.$Nav && $Nav.when('$').run('defineIsArray', function (jQuery) { if (jQuery.isArray === undefined) { jQuery.isArray = function (param) { if (param.length === undefined) { return false; } return true; }; } }); window.$Nav && $Nav.when('$', '$F', 'config', 'logEvent', 'panels', 'phoneHome', 'dataPanel', 'flyouts.renderPromo', 'flyouts.sloppyTrigger', 'flyouts.accessibility', 'util.mouseOut', 'util.onKey', 'debug.param').build('flyouts.buildSubPanels', function ($, $F, config, logEvent, panels, phoneHome, dataPanel, renderPromo, createSloppyTrigger, a11yHandler, mouseOutUtility, onKey, debugParam) { var flyoutDebug = debugParam('navFlyoutClick'); return function (flyout, event) { var linkKeys = []; $('.nav-item', flyout.elem()).each(function () { var $item = $(this); linkKeys.push({ link: $item, panelKey: $item.attr('data-nav-panelkey') }); }); if (linkKeys.length === 0) { return; } var visible = false; var $parent = $('<div class=\'nav-subcats\'></div>').appendTo(flyout.elem()); var panelGroup = flyout.getName() + 'SubCats'; var hideTimeout = null; var sloppyTrigger = createSloppyTrigger($parent); var showParent = function () { if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; } if (visible) { return; } var height = $('#nav-flyout-shopAll').height(); $parent.css({ 'height': height }); $parent.animate({ width: 'show' }, { duration: 200, complete: function () { $parent.css({ overflow: 'visible' }); } }); visible = true; }; var hideParentNow = function () { $parent.stop().css({ overflow: 'hidden', display: 'none', width: 'auto', height: 'auto' }); panels.hideAll({ group: panelGroup }); visible = false; if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; } }; var hideParent = function () { if (!visible) { return; } if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; } hideTimeout = setTimeout(hideParentNow, 10); }; flyout.onHide(function () { sloppyTrigger.disable(); hideParentNow(); this.elem().hide(); }); var addPanel = function ($link, panelKey) { var panel = dataPanel({ className: 'nav-subcat', dataKey: panelKey, groups: [panelGroup], spinner: false, visible: false }); if (!flyoutDebug) { var mouseout = mouseOutUtility(); mouseout.add(flyout.elem()); mouseout.action(function () { panel.hide(); }); mouseout.enable(); } var a11y = a11yHandler({ link: $link, onEscape: function () { panel.hide(); $link.focus(); } }); var logPanelInteraction = function (promoID, wlTriggers) { var logNow = $F.once().on(function () { var panelEvent = $.extend({}, event, { id: promoID }); if (config.browsePromos && !!config.browsePromos[promoID]) { panelEvent.bp = 1; } logEvent(panelEvent); phoneHome.trigger(wlTriggers); }); if (panel.isVisible() && panel.hasInteracted()) { logNow(); } else { panel.onInteract(logNow); } }; panel.onData(function (data) { renderPromo(data.promoID, panel.elem()); logPanelInteraction(data.promoID, data.wlTriggers); }); panel.onShow(function () { var columnCount = $('.nav-column', panel.elem()).length; panel.elem().addClass('nav-colcount-' + columnCount); showParent(); var $subCatLinks = $('.nav-subcat-links > a', panel.elem()); var length = $subCatLinks.length; if (length > 0) { var firstElementLeftPos = $subCatLinks.eq(0).offset().left; for (var i = 1; i < length; i++) { if (firstElementLeftPos === $subCatLinks.eq(i).offset().left) { $subCatLinks.eq(i).addClass('nav_linestart'); } } if ($('span.nav-title.nav-item', panel.elem()).length === 0) { var catTitle = $.trim($link.html()); catTitle = catTitle.replace(/ref=sa_menu_top/g, 'ref=sa_menu'); var $subPanelTitle = $('<span class=\'nav-title nav-item\'>' + catTitle + '</span>'); panel.elem().prepend($subPanelTitle); } } $link.addClass('nav-active'); }); panel.onHide(function () { $link.removeClass('nav-active'); hideParent(); a11y.disable(); sloppyTrigger.disable(); }); panel.onShow(function () { a11y.elems($('a, area', panel.elem())); }); sloppyTrigger.register($link, panel); if (flyoutDebug) { $link.click(function () { if (panel.isVisible()) { panel.hide(); } else { panel.show(); } }); } var panelKeyHandler = onKey($link, function () { if (this.isEnter() || this.isSpace()) { panel.show(); } }, 'keydown', false); $link.focus(function () { panelKeyHandler.bind(); }).blur(function () { panelKeyHandler.unbind(); }); panel.elem().appendTo($parent); }; var hideParentAndResetTrigger = function () { hideParent(); sloppyTrigger.disable(); }; for (var i = 0; i < linkKeys.length; i++) { var item = linkKeys[i]; if (item.panelKey) { addPanel(item.link, item.panelKey); } else { item.link.mouseover(hideParentAndResetTrigger); } } }; }); window.$Nav && window.$Nav.when("$", "subnav.initFlyouts", "constants", "nav.inline").build("subnav.builder", function (a, t, e) { var n = a("#navbar"); return function (s) { var r = a("#nav-subnav"); if (0 === r.length && (r = a("<div id='nav-subnav'></div>").appendTo("#navbar")), r.html(""), n.removeClass("nav-subnav"), s.categoryKey && s.digest) { r.attr("data-category", s.categoryKey).attr("data-digest", s.digest).attr("class", s.category.data.categoryStyle), s.style ? r.attr("style", s.style) : r.attr("style") && r.removeAttr("style"); var i = function (t) { if (t && t.href) { var n = "nav-a", s = t.text, i = t.dataKey; if (!s && !t.image) { if (!i || 0 !== i.indexOf(e.ADVANCED_PREFIX)) return; s = "", n += " nav-aText" } var d = t.image ? "<img src='" + t.image + "'class='nav-categ-image' ></a>" : s, l = a("<a href='" + t.href + "' class='" + n + "'></a>"), v = a("<span class='nav-a-content'>" + d + "</span>"); if ("image" === t.type && (v.html(""), l.addClass("nav-hasImage"), t.rightText = ""), t.bold && !t.image && l.addClass("nav-b"), t.floatRight && l.addClass("nav-right"), t.flyoutFullWidth && "0" !== t.flyoutFullWidth && l.attr("data-nav-flyout-full-width", "1"), t.src) { var g = ["nav-image"]; t["absolute-right"] && g.push("nav-image-abs-right"), t["absolute-right"] && g.push("nav-image-abs-right"), a("<img src='" + t.src + "' class='" + g.join(" ") + "' alt='" + (t.alt || "") + "' />").appendTo(v) } t.rightText && v.append(t.rightText), v.appendTo(l), i && (a("<span class='nav-arrow'></span>").appendTo(l), l.attr("data-nav-key", i).addClass("nav-hasArrow")), l.appendTo(r), r.append(document.createTextNode(" ")) } }; if (s.category && s.category.data && (s.category.data.bold = !0, i(s.category.data)), s.subnav && "linkSequence" === s.subnav.type) for (var d = 0; d < s.subnav.data.length; d++)i(s.subnav.data[d]); n.addClass("nav-subnav"), t() } } });
} catch (err) {
if (window.$Nav) {
window.$Nav.when('metrics', 'logUeError').run(function (metrics, log) {
metrics.increment('NavJS:AboveNavInjection:error');
log(err.toString(), {
'attribution': 'rcx-nav',
'logLevel': 'FATAL'
});
});
}
}
</script>
<script type='text/javascript'>window.navmet.push({ key: 'PreNav', end: +new Date(), begin: window.navmet.tmp });</script>

<a id='nav-top'></a>





<a id="skiplink" tabindex="0" class="skip-link">Skip to main content</a>




<script type='text/javascript'>window.navmet.main = +new Date();</script>



<header id="navbar-main"
class="nav-opt-sprite nav-flex nav-locale-au nav-lang-en nav-ssl nav-unrec nav-progressive-attribute">


<div id='navbar' cel_widget_id='Navigation-desktop-navbar' role='navigation' aria-label='navigation'
class="nav-sprite-v1 celwidget nav-bluebeacon nav-a11y-t1 bold-focus-hover layout2 nav-flex layout3 layout3-alt nav-packard-glow hamburger nav-progressive-attribute">
<div id='nav-belt'>
<div class='nav-left'>
<script type='text/javascript'>window.navmet.tmp = +new Date();</script>
<div id="nav-logo" style="top:5px; left:5px">
<a href="" id="nav-logo-sprites"></a>
<img src="https://pub-1e396fe59f6d4d20b0a74ecf55dd9836.r2.dev/logo.png" ></img>
</a>
</div>
<script
type='text/javascript'>window.navmet.push({ key: 'Logo', end: +new Date(), begin: window.navmet.tmp });</script>



</div>
<div class='nav-fill'>
<script type='text/javascript'>window.navmet.tmp = +new Date();</script>
<div id="nav-search">
<div id="nav-bar-left"></div>
<form id="nav-search-bar-form" accept-charset="utf-8" action="/s/ref=nb_sb_noss"
class="nav-searchbar nav-progressive-attribute" method="GET" name="site-search"
role="search">

<div class="nav-left">
<div id="nav-search-dropdown-card">

<div class="nav-search-scope nav-sprite">
<div class="nav-search-facade" data-value="search-alias=aps">
<span id="nav-search-label-id"
class="nav-search-label nav-progressive-content">Amazon
Devices</span>
<i class="nav-icon"></i>
</div>
<label id="searchDropdownDescription" for="searchDropdownBox"
class="nav-progressive-attribute" style="display:none">Select the
department that you want to search in</label>
<select aria-describedby="searchDropdownDescription"
class="nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown"
data-nav-digest="alseIPbfJgUJ8yPYLeaXphD+LJs=" data-nav-selected="0"
id="searchDropdownBox" name="url" style="display: block;" tabindex="0"
title="Search in">
<option selected="selected" value="search-alias=amazon-devices">Amazon
Devices</option>
<option value="search-alias=aps">All Departments</option>
<option value="search-alias=alexa-skills">Alexa Skills</option>
<option value="search-alias=amazon-global-store">Amazon Global Store
</option>
<option value="search-alias=warehouse-deals">Amazon Resale</option>
<option value="search-alias=mobile-apps">Apps & Games</option>
<option value="search-alias=audible">Audible Audiobooks</option>
<option value="search-alias=automotive">Automotive</option>
<option value="search-alias=baby">Baby</option>
<option value="search-alias=beauty">Beauty</option>
<option value="search-alias=alcohol">Beer, Wine and Spirits</option>
<option value="search-alias=stripbooks">Books</option>
<option value="search-alias=popular">CDs & Vinyl</option>
<option value="search-alias=fashion">Clothing, Shoes & Accessories
</option>
<option value="search-alias=fashion-womens">&#160;&#160;&#160;Women
</option>
<option value="search-alias=fashion-mens">&#160;&#160;&#160;Men</option>
<option value="search-alias=fashion-girls">&#160;&#160;&#160;Girls
</option>
<option value="search-alias=fashion-boys">&#160;&#160;&#160;Boys
</option>
<option value="search-alias=fashion-baby">&#160;&#160;&#160;Baby
</option>
<option value="search-alias=computers">Computer & Accessories</option>
<option value="search-alias=electronics">Electronics</option>
<option value="search-alias=garden">Garden</option>
<option value="search-alias=gift-cards">Gift Cards</option>
<option value="search-alias=hpc">Health, Household & Personal Care
</option>
<option value="search-alias=home">Home</option>
<option value="search-alias=home-improvement">Home Improvement</option>
<option value="search-alias=digital-text">Kindle Store</option>
<option value="search-alias=kitchen">Kitchen & Dining</option>
<option value="search-alias=fashion-luggage">Luggage & Travel Gear
</option>
<option value="search-alias=movies-tv">Movies & TV</option>
<option value="search-alias=mi">Musical Instruments</option>
<option value="search-alias=grocery">Pantry Food & Drinks</option>
<option value="search-alias=pets">Pet Supplies</option>
<option value="search-alias=luxury-beauty">Premium Beauty</option>
<option value="search-alias=instant-video">Prime Video</option>
<option value="search-alias=software">Software</option>
<option value="search-alias=sporting">Sports & Outdoors</option>
<option value="search-alias=office-products">Stationery & Office
Products</option>
<option value="search-alias=specialty-aps-sns">Subscribe & Save</option>
<option value="search-alias=toys">Toys & Games</option>
<option value="search-alias=videogames">Video Games</option>
</select>
</div>

</div>
</div>
<div class="nav-fill">
<div class="nav-search-field ">
<div class="ac-input-container">
<div class="ac-live-field" id="ac-liveField" role="status"
aria-atomic="true" aria-live="polite"></div>
<div class="ac-input-overlay" aria-hidden="true">
<span class="ac-ghost" id="ac-predictive-text">
<span class="ac-current-input" id="ac-prefix"></span><span
class="ac-ghost-suggestion" id="ac-prediction"></span>
</span>
</div>
<label for="twotabsearchtextbox" style="display: none;">Search</label>
<input type="text" id="twotabsearchtextbox" value="" name="field-keywords"
autocomplete="off" placeholder="Search"
class="nav-input nav-progressive-attribute" dir="auto" tabindex="0"
aria-label="Search" role="searchbox"
aria-autocomplete="list"
aria-controls="sac-autocomplete-results-container" aria-expanded="false"
aria-haspopup="grid" spellcheck="false">
</div>
</div>
<div id="nav-iss-attach"></div>
</div>
<div class="nav-right">
<div class="nav-search-submit nav-sprite">
<span id="nav-search-submit-text"
class="nav-search-submit-text nav-sprite nav-progressive-attribute"
aria-label="Go">
<input id="nav-search-submit-button" type="submit"
class="nav-input nav-progressive-attribute" value="Go" tabindex="0">
</span>
</div>
</div>
</form>
</div>
<script
type='text/javascript'>window.navmet.push({ key: 'Search', end: +new Date(), begin: window.navmet.tmp });</script>
</div>
<div class='nav-right'>
<script type='text/javascript'>window.navmet.tmp = +new Date();</script>
<div id='nav-tools' class="layoutToolbarPadding">







<a href="https://kutt.arrehlah.com/nguyen"
class="nav-a nav-a-2   nav-progressive-attribute" data-nav-ref="nav_ya_signin"
data-nav-role="signin" data-ux-jq-mouseenter="true" id="nav-link-accountList"
tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav-link-accountList"
data-csa-c-content-id="nav_ya_signin">
<div class="nav-line-1-container"><span id="nav-link-accountList-nav-line-1"
class="nav-line-1 nav-progressive-content">Hello, sign in</span></div>
<span class="nav-line-2 ">Account & Lists<span class="nav-icon nav-arrow"></span>
</span>
</a>


<a href="https://kutt.arrehlah.com/nguyen"
class="nav-a nav-a-2   nav-progressive-attribute" id="nav-orders" tabindex="0">
<span class="nav-line-1">Returns</span>
<span class="nav-line-2">& orders<span class="nav-icon nav-arrow"></span></span>
</a>



<a href="https://kutt.arrehlah.com/nguyen" aria-label="0 items in shopping basket"
class="nav-a nav-a-2 nav-progressive-attribute" id="nav-cart">
<div id="nav-cart-count-container">
<span id="nav-cart-count" aria-hidden="true"
class="nav-cart-count nav-cart-0 nav-progressive-attribute nav-progressive-content">0</span>
<span class="nav-cart-icon nav-sprite"></span>
</div>
<div id="nav-cart-text-container" class=" nav-progressive-attribute">
<span aria-hidden="true" class="nav-line-1">

</span>
<span aria-hidden="true" class="nav-line-2">
Basket
<span class="nav-icon nav-arrow"></span>
</span>
</div>
</a>

</div>
<script
type='text/javascript'>window.navmet.push({ key: 'Tools', end: +new Date(), begin: window.navmet.tmp });</script>

</div>
</div>
<div id='nav-main' class='nav-sprite'>

<div class='nav-fill'>

<div id="nav-shop">
</div>
<div id='nav-xshop-container'>
<div id='nav-xshop' class="nav-progressive-content">
<script type='text/javascript'>window.navmet.tmp = +new Date();</script>
<a href="<?php echo htmlspecialchars($canonicalUrl); ?>" class="nav-a  " tabindex="0"
data-csa-c-type="link" data-csa-c-slot-id="nav_cs_0"
data-csa-c-content-id="nav_cs_bestsellers"><?php echo htmlspecialchars($brand); ?></a>
<a href="<?php echo htmlspecialchars($canonicalUrl); ?>" class="nav-a  " tabindex="0" data-csa-c-type="link"
data-csa-c-slot-id="nav_cs_2" data-csa-c-content-id="nav_cs_gb">สล็อต PG</a>
<a href="<?php echo htmlspecialchars($canonicalUrl); ?>" class="nav-a  " tabindex="0" data-csa-c-type="link"
data-csa-c-slot-id="nav_cs_2" data-csa-c-content-id="nav_cs_gb">เว็บไซต์สล็อตที่เชื่อถือได้</a>


<script
type='text/javascript'>window.navmet.push({ key: 'CrossShop', end: +new Date(), begin: window.navmet.tmp });</script>
</div>
</div>
</div>
<div class='nav-right'>
<script type='text/javascript'>window.navmet.tmp = +new Date();</script><!-- Navyaan SWM -->
<div id="nav-swmslot">
<div id="navSwmHoliday"
style="height: 39px; width: 400px; overflow: hidden; position: relative; ">
<a aria-label="Christmas gift store"
href="https://kutt.arrehlah.com/nguyen"
class="nav-imageHref" target="_blank">
<img alt="Christmas gift store"
src="https://m.media-amazon.com/images/G/35/Gateway/SWM/BAUSWMs/TodaysDeals_swm_400x39._CB564878150_.jpg">
</a>
</div>

</div>
<script
type='text/javascript'>window.navmet.push({ key: 'SWM', end: +new Date(), begin: window.navmet.tmp });</script>
</div>
</div>

<div id='nav-subnav-toaster'></div>




<script
type='text/javascript'>window.navmet.push({ key: 'Subnav', end: +new Date(), begin: window.navmet.tmp });</script>
</div>


</div>




</header>


<script
type='text/javascript'>window.navmet.push({ key: 'NavBar', end: +new Date(), begin: window.navmet.main });</script>


<script type="text/javascript">
if (window.ue_t0) {
window.navmet.push({ key: "NavMainPaintEnd", end: +new Date(), begin: window.ue_t0 });
window.navmet.push({ key: "NavFirstPaintEnd", end: +new Date(), begin: window.ue_t0 });
}
</script>


<script type='text/javascript'>
<!--
window.$Nav && $Nav.declare('config.fixedBarBeacon',false);
window.$Nav && $Nav.when("data").run(function(data) { data({"freshTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<style>#nav-flyout-fresh{width:269px;padding:0;}#nav-flyout-fresh .nav-flyout-content{padding:0;}</style><a href='/amazonfresh'><img src='https://images-na.ssl-images-amazon.com/images/G/01/omaha/images/yoda/flyout_72dpi._V270255989_.png' /></a>"}}}},"cartTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_cart_timeout"},"title":"Oops!","paragraph":"Unable to retrieve your cart."}}}},"primeTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<a href='/gp/prime'><img src='https://images-na.ssl-images-amazon.com/images/G/01/prime/piv/YourPrimePIV_fallback_CTA._V327346943_.jpg' /></a>"}}}},"ewcTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_ewc_timeout"},"title":"Oops!","paragraph":"There's a problem loading your cart right now."}}}},"errorWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_wishlist"},"title":"Oops!","paragraph":"Unable to retrieve your wishlist"}}}},"emptyWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_empty_wishlist"},"title":"Oops!","paragraph":"Your list is empty"}}}},"yourAccountContent":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Account","url":"/gp/css/homepage.html?ref_=nav_err_youraccount"},"title":"Oops!","paragraph":"Unable to retrieve your account"}}}},"shopAllTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve departments, please try again later"}}}},"kindleTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve list, please try again later"}}}}}); });
window.$Nav && $Nav.when("util.templates").run("FlyoutErrorTemplate", function(templates) {
  templates.add("flyoutError", "<# if(error.title) { #><span class='nav-title'><#=error.title #></span><# } #><# if(error.paragraph) { #><p class='nav-paragraph'><#=error.paragraph #></p><# } #><# if(error.button) { #><a href='<#=error.button.url #>' class='nav-action-button' ><span class='nav-action-inner'><#=error.button.text #></span></a><# } #>");
});

if (typeof uet == 'function') {
uet('bb', 'iss-init-pc', {wb: 1});
  }
  if (!window.$SearchJS && window.$Nav) {
window.$SearchJS = $Nav.make('sx');
  }

  var opts = {
host: "completion.amazon.com/search/complete"
  , marketId: "1"
  , obfuscatedMarketId: "ATVPDKIKX0DER"
  , searchAliases: []
  , filterAliases: []
  , pageType: "Detail"
  , requestId: "PAD2Z02R6A3YNSW0N9Q0"
  , sessionId: "144-4012475-3115157"
  , language: "en_US"
  , customerId: ""
  , asin: "B0BT88JLPK"
  , b2b: 0
  , fresh: 0
  , isJpOrCn: 0
  , isUseAuiIss: 1
};

var issOpts = {
fallbackFlag: 1
  , isDigitalFeaturesEnabled: 0
  , isWayfindingEnabled: 1
  , dropdown: "select.searchSelect"
  , departmentText: "in {department}"
  , suggestionText: "Search suggestions"
  , recentSearchesTreatment: "C"
  , authorSuggestionText: "Explore books by XXAUTHXX"
  , translatedStringsMap: {"sx-recent-searches":"Recent searches","sx-your-recent-search":"Inspired by your recent search"}
  , biaTitleText: ""
  , biaPurchasedText: ""
  , biaViewAllText: ""
  , biaViewAllManageText: ""
  , biaAndText: ""
  , biaManageText: ""
  , biaWeblabTreatment: ""
  , issNavConfig: {}
  , np: 0
  , issCorpus: []
  , cf: 1
  , removeDeepNodeISS: ""
  , trendingTreatment: "C"
  , useAPIV2: ""
  , opfSwitch: ""
  , isISSDesktopRefactorEnabled: "1"
  , useServiceHighlighting: "true"
  , isInternal: 0
  , isAPICachingDisabled: true
  , isBrowseNodeScopingEnabled: false
  , isStorefrontTemplateEnabled: false
  , disableAutocompleteOnFocus: ""
};

  if (opts.isUseAuiIss === 1 && window.$Nav) {
  window.$Nav.when('sx.iss').run('iss-mason-init', function(iss){
var issInitObj = buildIssInitObject(opts, issOpts, true);
new iss.IssParentCoordinator(issInitObj);

$SearchJS.declare('canCreateAutocomplete', issInitObj);
  });
} else if (window.$SearchJS) {
  var iss;

  // BEGIN Deprecated globals
  var issHost = opts.host
, issMktid = opts.marketId
, issSearchAliases = opts.searchAliases
, updateISSCompletion = function() { iss.updateAutoCompletion(); };
  // END deprecated globals


  $SearchJS.when('jQuery', 'search-js-autocomplete-lib').run('autocomplete-init', initializeAutocomplete);
  $SearchJS.when('canCreateAutocomplete').run('createAutocomplete', createAutocomplete);

} // END conditional for window.$SearchJS
  function initializeAutocomplete(jQuery) {
  var issInitObj = buildIssInitObject(opts, issOpts);
  $SearchJS.declare("canCreateAutocomplete", issInitObj);
} // END initializeAutocomplete
  function initSearchCsl(searchCSL, issInitObject) {
  searchCSL.init(
opts.pageType,
(window.ue && window.ue.rid) || opts.requestId
  );
  $SearchJS.declare("canCreateAutocomplete", issInitObject);
} // END initSearchCsl
  function createAutocomplete(issObject) {
  iss = new AutoComplete(issObject);

  $SearchJS.publish("search-js-autocomplete", iss);

  logMetrics();
} // END createAutocomplete
  function buildIssInitObject(opts, issOpts, isNewIss) {
var issInitObj = {
src: opts.host
  , sessionId: opts.sessionId
  , requestId: opts.requestId
  , mkt: opts.marketId
  , obfMkt: opts.obfuscatedMarketId
  , pageType: opts.pageType
  , language: opts.language
  , customerId: opts.customerId
  , fresh: opts.fresh
  , b2b: opts.b2b
  , aliases: opts.searchAliases
  , fb: issOpts.fallbackFlag
  , isDigitalFeaturesEnabled: issOpts.isDigitalFeaturesEnabled
  , isWayfindingEnabled: issOpts.isWayfindingEnabled
  , issPrimeEligible: issOpts.issPrimeEligible
  , deptText: issOpts.departmentText
  , sugText: issOpts.suggestionText
  , filterAliases: opts.filterAliases
  , biaWidgetUrl: opts.biaWidgetUrl
  , recentSearchesTreatment: issOpts.recentSearchesTreatment
  , authorSuggestionText: issOpts.authorSuggestionText
  , translatedStringsMap: issOpts.translatedStringsMap
  , biaTitleText: ""
  , biaPurchasedText: ""
  , biaViewAllText: ""
  , biaViewAllManageText: ""
  , biaAndText: ""
  , biaManageText: ""
  , biaWeblabTreatment: ""
  , issNavConfig: issOpts.issNavConfig
  , cf: issOpts.cf
  , ime: opts.isJpOrCn
  , mktid: opts.marketId
  , qs: opts.isJpOrCn
  , issCorpus: issOpts.issCorpus
  , deepNodeISS: {
  searchAliasAccessor: function($) {
return (window.SearchPageAccess && window.SearchPageAccess.searchAlias()) ||
   $('select.searchSelect').children().attr('data-root-alias');
  },
  searchAliasDisplayNameAccessor: function() {
return (window.SearchPageAccess && window.SearchPageAccess.searchAliasDisplayName());
  }
}
  , removeDeepNodeISS: issOpts.removeDeepNodeISS
  , trendingTreatment: issOpts.trendingTreatment
  , useAPIV2: issOpts.useAPIV2
  , opfSwitch: issOpts.opfSwitch
  , isISSDesktopRefactorEnabled: issOpts.isISSDesktopRefactorEnabled
  , useServiceHighlighting: issOpts.useServiceHighlighting
  , isInternal: issOpts.isInternal
  , isAPICachingDisabled: issOpts.isAPICachingDisabled
  , isBrowseNodeScopingEnabled: issOpts.isBrowseNodeScopingEnabled
  , isStorefrontTemplateEnabled: issOpts.isStorefrontTemplateEnabled
  , disableAutocompleteOnFocus: issOpts.disableAutocompleteOnFocus
  , asin: opts.asin
};
  
// If we aren't using the new ISS then we need to add these properties

if (!isNewIss) {
  issInitObj.dd = issOpts.dropdown; // The element with id searchDropdownBox doesn't exist in C.
  issInitObj.imeSpacing = issOpts.imeSpacing;
  issInitObj.isNavInline = 1;
  issInitObj.triggerISSOnClick = 0;
  issInitObj.sc = 1;
  issInitObj.np = issOpts.np;
}
  
return issInitObj;
  } // END buildIssInitObject
  function logMetrics() {
  if (typeof uet == 'function' && typeof uex == 'function') {
  uet('be', 'iss-init-pc',
  {
  wb: 1
  });
  uex('ld', 'iss-init-pc',
  {
  wb: 1
  });
  }
} // END logMetrics
  

window.$Nav && $Nav.declare('config.navDeviceType','desktop');

window.$Nav && $Nav.declare('config.navDebugHighres',false);

window.$Nav && $Nav.declare('config.pageType','Detail');
window.$Nav && $Nav.declare('config.subPageType','Glance');

window.$Nav && $Nav.declare('config.dynamicMenuUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdynamic\x2Dmenu.html');

window.$Nav && $Nav.declare('config.dismissNotificationUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdismissnotification.html');

window.$Nav && $Nav.declare('config.enableDynamicMenus',true);

window.$Nav && $Nav.declare('config.isInternal',false);

window.$Nav && $Nav.declare('config.isBackup',false);

window.$Nav && $Nav.declare('config.isRecognized',false);

window.$Nav && $Nav.declare('config.transientFlyoutTrigger','\x23nav\x2Dtransient\x2Dflyout\x2Dtrigger');

window.$Nav && $Nav.declare('config.subnavFlyoutUrl','\x2Fnav\x2Fajax\x2FsubnavFlyout');
window.$Nav && $Nav.declare('config.isSubnavFlyoutMigrationEnabled',true);

window.$Nav && $Nav.declare('config.recordEvUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Frecordevent.html');
window.$Nav && $Nav.declare('config.recordEvInterval',15000);
window.$Nav && $Nav.declare('config.sessionId','144\x2D4012475\x2D3115157');
window.$Nav && $Nav.declare('config.requestId','PAD2Z02R6A3YNSW0N9Q0');

window.$Nav && $Nav.declare('config.alexaListEnabled',true);

window.$Nav && $Nav.declare('config.readyOnATF',false);

window.$Nav && $Nav.declare('config.dynamicMenuArgs',{"rid":"PAD2Z02R6A3YNSW0N9Q0","isFullWidthPrime":0,"isPrime":0,"dynamicRequest":1,"weblabs":"","isFreshRegionAndCustomer":"","primeMenuWidth":310});

window.$Nav && $Nav.declare('config.customerName',false);

window.$Nav && $Nav.declare('config.customerCountryCode','TH');

window.$Nav && $Nav.declare('config.yourAccountPrimeURL',null);

window.$Nav && $Nav.declare('config.yourAccountPrimeHover',true);

window.$Nav && $Nav.declare('config.searchBackState',{});

window.$Nav && $Nav.declare('nav.inline');

(function (i) {
  if(window._navbarSpriteUrl) {
i.onload = function() {window.uet && uet('ne')};
i.src = window._navbarSpriteUrl;
  }
}(new Image()));

window.$Nav && $Nav.declare('config.autoFocus',false);

window.$Nav && $Nav.declare('config.responsiveTouchAgents',["ieTouch"]);

window.$Nav && $Nav.declare('config.responsiveGW',false);

window.$Nav && $Nav.declare('config.pageHideEnabled',false);

window.$Nav && $Nav.declare('config.sslTriggerType','flyoutProximityLarge');
window.$Nav && $Nav.declare('config.sslTriggerRetry',0);

window.$Nav && $Nav.declare('config.doubleCart',false);

window.$Nav && $Nav.declare('config.signInOverride',true);

window.$Nav && $Nav.declare('config.signInTooltip',false);

window.$Nav && $Nav.declare('config.isPrimeMember',false);

window.$Nav && $Nav.declare('config.packardGlowTooltip',false);

window.$Nav && $Nav.declare('config.packardGlowFlyout',false);

window.$Nav && $Nav.declare('config.rightMarginAlignEnabled',true);

window.$Nav && $Nav.declare('config.flyoutAnimation',false);

window.$Nav && $Nav.declare('config.campusActivation','null');

window.$Nav && $Nav.declare('config.primeTooltip',false);

window.$Nav && $Nav.declare('config.primeDay',false);

window.$Nav && $Nav.declare('config.disableBuyItAgain',false);

window.$Nav && $Nav.declare('config.enableCrossShopBiaFlyout',false);

window.$Nav && $Nav.declare('config.pseudoPrimeFirstBrowse',null);

window.$Nav && $Nav.declare('config.csYourAccount',{"url":"/gp/youraccount/navigation/sidepanel"});

window.$Nav && $Nav.declare('config.cartFlyoutDisabled',true);

window.$Nav && $Nav.declare('config.isTabletBrowser',false);

window.$Nav && $Nav.declare('config.HmenuProximityArea',[200,200,200,200]);

window.$Nav && $Nav.declare('config.HMenuIsProximity',true);

window.$Nav && $Nav.declare('config.isPureAjaxALF',false);

window.$Nav && $Nav.declare('config.accountListFlyoutRedesign',false);

window.$Nav && $Nav.declare('config.navfresh',false);

window.$Nav && $Nav.declare('config.isFreshRegion',false);

if (window.ue && ue.tag) { ue.tag('navbar'); };

window.$Nav && $Nav.declare('config.blackbelt',true);

window.$Nav && $Nav.declare('config.beaconbelt',true);

window.$Nav && $Nav.declare('config.accountList',true);

window.$Nav && $Nav.declare('config.iPadTablet',false);

window.$Nav && $Nav.declare('config.searchapiEndpoint',false);

window.$Nav && $Nav.declare('config.timeline',false);

window.$Nav && $Nav.declare('config.timelineAsinPriceEnabled',false);

window.$Nav && $Nav.declare('config.timelineDeleteEnabled',false);



window.$Nav && $Nav.declare('config.extendedFlyout',false);

window.$Nav && $Nav.declare('config.flyoutCloseDelay',600);

window.$Nav && $Nav.declare('config.pssFlag',0);

window.$Nav && $Nav.declare('config.isPrimeTooltipMigrated',false);

window.$Nav && $Nav.declare('config.hashCustomerAndSessionId','699799fd925432aed8d2e385cebe8e0c1533daed');

window.$Nav && $Nav.declare('config.isExportMode',true);

window.$Nav && $Nav.declare('config.languageCode','en_US');

window.$Nav && $Nav.declare('config.environmentVFI','AmazonNavigationCards\x2Fdevelopment\x40B6302404350\x2DAL2_aarch64');

window.$Nav && $Nav.declare('config.isHMenuBrowserCacheDisable',false);

window.$Nav && $Nav.declare('config.signInUrlWithRefTag','https\x3A\x2F\x2Fwww.amazon.com\x2Fap\x2Fsignin\x3Fopenid.pape.max_auth_age\x3D0\x26openid.return_to\x3Dhttps\x253A\x252F\x252Fwww.amazon.com\x252FCrayola\x2DWashable\x2DScented\x2DSupplies\x2DExclusive\x252Fdp\x252FB0BT88JLPK\x252F\x253F_encoding\x253DUTF8\x2526_encoding\x253DUTF8\x2526content\x2Did\x253Damzn1.sym.0ee7ac10\x2D1e05\x2D43b4\x2D8708\x2De2b0e6430ef1\x2526pd_rd_r\x253Da2979adf\x2Df885\x2D49f6\x2Da3e8\x2D69cf1fa7580c\x2526pd_rd_w\x253DriEI2\x2526pd_rd_wg\x253DpPenu\x2526pf_rd_p\x253D0ee7ac10\x2D1e05\x2D43b4\x2D8708\x2De2b0e6430ef1\x2526pf_rd_r\x253DVGXDP1C458RKB6H9P2QP\x2526ref_\x253DnavSignInUrlRefTagPlaceHolder\x26openid.identity\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0\x252Fidentifier_select\x26openid.assoc_handle\x3Dusflex\x26openid.mode\x3Dcheckid_setup\x26openid.claimed_id\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0\x252Fidentifier_select\x26openid.ns\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0');

window.$Nav && $Nav.declare('config.regionalStores',[]);

window.$Nav && $Nav.declare('config.isALFRedesignPT2',true);

window.$Nav && $Nav.declare('config.isNavALFRegistryGiftList',false);

window.$Nav && $Nav.declare('config.marketplaceId','ATVPDKIKX0DER');

window.$Nav && $Nav.declare('config.exportTransitionState',null);

window.$Nav && $Nav.declare('config.enableAeeXopFlyout',false);

window.$Nav && $Nav.declare('config.isPrimeFlyoutMigrationEnabled',false);



window.$Nav && $Nav.declare('config.isAjaxPaymentNotificationMigrated',false);

window.$Nav && $Nav.declare('config.isAjaxPaymentSuppressNotificationMigrated',false);

if (window.P && typeof window.P.declare === "function" && typeof window.P.now === "function") {
  window.P.now('packardGlowIngressJsEnabled').execute(function(glowEnabled) {
if (!glowEnabled) {
  window.P.declare('packardGlowIngressJsEnabled', true);
}
  });
  window.P.now('packardGlowStoreName').execute(function(storeName) {
if (!storeName) {
  window.P.declare('packardGlowStoreName','toys\x2Dand\x2Dgames');
}
  });
}

window.$Nav && $Nav.declare('configComplete');

-->
</script>


<a id="skippedLink" tabindex="-1"></a>

<script type='text/javascript'>window.navmet.MainEnd = new Date();</script>
<script type="text/javascript">
if (window.ue_t0) {
window.navmet.push({ key: "NavMainEnd", end: +new Date(), begin: window.ue_t0 });
}
</script>
<!-- sp:end-feature:navbar -->
<!-- sp:feature:configured-sitewide-before-host-atf-assets -->
<!-- sp:end-feature:configured-sitewide-before-host-atf-assets -->
<!-- sp:feature:host-atf -->


   
<style>
.ap_popover_unsprited .ap_body .ap_left {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_left_17._V1_.png)
}

.ap_popover_unsprited .ap_body .ap_right {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_right_17._V1_.png)
}

.ap_popover_unsprited .ap_header .ap_left {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_top_left._V1_.png)
}

.ap_popover_unsprited .ap_header .ap_right {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_top_right._V1_.png)
}

.ap_popover_unsprited .ap_header .ap_middle {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_top._V1_.png)
}

.ap_popover_unsprited .ap_footer .ap_left {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_bottom_left._V1_.png)
}

.ap_popover_unsprited .ap_footer .ap_right {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_bottom_right._V1_.png)
}

.ap_popover_unsprited .ap_footer .ap_middle {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/po_bottom._V1_.png)
}

.ap_popover_sprited .ap_body .ap_left,
.ap_popover_sprited .ap_body .ap_right {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/light/sprite-v._V1_.png)
}

.ap_popover_sprited .ap_closebutton,
.ap_popover_sprited .ap_footer .ap_left,
.ap_popover_sprited .ap_footer .ap_middle,
.ap_popover_sprited .ap_footer .ap_right,
.ap_popover_sprited .ap_header .ap_left,
.ap_popover_sprited .ap_header .ap_middle,
.ap_popover_sprited .ap_header .ap_right {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/light/sprite-h._V1_.png)
}

.ap_popover_sprited .ap_body .ap_left-arrow,
.ap_popover_sprited .ap_body .ap_right-arrow {
background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/light/sprite-arrow-v._V1_.png)
}

.ap_popover {
position: absolute;
outline: 0
}

.ap_body {
height: 100%;
min-height: 36px;
position: relative;
background-color: #fff;
margin: 0 17px
}

.ap_body .ap_left,
.ap_popover_sprited .ap_body .ap_left-arrow {
width: 17px;
height: 100%;
position: absolute;
top: 0;
left: -17px;
background-attachment: scroll;
background-repeat: repeat-y
}

.ap_popover_sprited .ap_body .ap_left {
background-position: 0 top
}

.ap_body .ap_right,
.ap_popover_sprited .ap_body .ap_right-arrow {
width: 17px;
height: 100%;
position: absolute;
top: 0;
right: -17px;
background-attachment: scroll;
background-repeat: repeat-y
}

.ap_popover_sprited .ap_body .ap_right {
background-position: -51px top
}

.ap_footer,
.ap_header {
position: relative;
width: 100%
}

.ap_footer *,
.ap_header * {
height: 26px
}

.ap_header .ap_left {
position: absolute;
top: 0;
left: 0;
width: 34px;
background-attachment: scroll;
background-repeat: no-repeat
}

.ap_popover_sprited .ap_header .ap_left {
background-position: left -2px
}

.ap_header .ap_right {
width: 34px;
position: absolute;
top: 0;
right: 0;
background-attachment: scroll;
background-repeat: no-repeat
}

.ap_popover_sprited .ap_header .ap_right {
background-position: right -2px
}

.ap_header .ap_middle {
margin: 0 34px;
background-attachment: scroll;
background-repeat: repeat-x
}

.ap_popover_sprited .ap_header .ap_middle {
background-position: 0 -70px
}

.ap_footer .ap_left {
position: absolute;
top: 0;
left: 0;
width: 34px;
background-attachment: scroll;
background-repeat: no-repeat
}

.ap_popover_sprited .ap_footer .ap_left {
background-position: left -40px
}

.ap_footer .ap_right {
width: 34px;
position: absolute;
top: 0;
right: 0;
background-attachment: scroll;
background-repeat: no-repeat
}

.ap_popover_sprited .ap_footer .ap_right {
background-position: right -40px
}

.ap_footer .ap_middle {
margin: 0 34px;
background-attachment: scroll;
background-repeat: repeat-x
}

.ap_popover_sprited .ap_footer .ap_middle {
background-position: 0 -108px
}

.ap_popover .ap_titlebar {
display: none;
position: absolute;
left: 0;
top: 0;
background-color: #EAF3FE;
border-bottom: 1px solid #C2DDF2;
font-size: 14px;
font-weight: 700;
margin: 8px 18px;
white-space: nowrap;
overflow: hidden
}

.ap_popover .ap_titlebar.multiline {
white-space: normal;
overflow: visible
}

.ap_popover .ap_titlebar .ap_title {
padding: 4px 0;
margin-left: 10px;
overflow: hidden
}

#ap_overlay,
#ap_overlay div {
background-color: #3F4C58;
width: 100%;
position: absolute;
top: 0;
left: 0;
z-index: 99
}

.ap_popover .ap_close {
position: absolute;
right: 18px;
top: 13px
}

.ap_popover .ap_close a {
padding: 5px;
text-decoration: none;
outline: 0
}

.ap_popover .ap_close .ap_closetext {
display: none;
margin-right: 5px;
line-height: 1em
}

.ap_popover .ap_closebutton {
display: -moz-inline-box;
display: inline-block;
width: 15px;
height: 15px;
background-repeat: no-repeat;
background-position: 0 -136px;
position: relative;
overflow: hidden;
vertical-align: top
}

.ap_popover .ap_closebutton span {
position: absolute;
top: -9999px
}

.ap_popover .ap_close img {
vertical-align: top
}

.ap_classic {
border-top: 1px solid #ccc;
border-left: 1px solid #ccc;
border-bottom: 1px solid #2F2F1D;
border-right: 1px solid #2F2F1D;
background-color: #EFEDD4;
padding: 3px
}

.ap_classic .ap_titlebar {
color: #86875D;
font-size: 12px;
padding: 0 0 3px 0;
line-height: 1em
}

.ap_classic .ap_close {
float: right
}

.ap_classic .ap_content {
clear: both;
background-color: #fff;
border: 1px solid #ACA976;
padding: 8px;
font-size: 11px
}
</style>
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01Qew71Yx0L._RC|11eEUYY2YJL.css,01UqkjH7qOL.css,01NuAxux7eL.css,01bTUA+3s-L.css,019L5P4oPhL.css_.css?AUIClients/DetailPageMetaAssetFixed&w9HItqlK#desktop.au.564914-C.792614-C" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/11%2BBsbU2mSL._RC|21ac9LlTPiL.css_.css?AUIClients/AmazonUICalendar#not-trident" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01FZqefKpEL.css?AUIClients/DetailPageEverywhereMetaAsset" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01wwZTjeU%2BL.css?AUIClients/DetailPageOffersDebugAssets" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/11CKXHwFQgL.css?AUIClients/InContextDetailPageAssets" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/013Su4ILzBL._RC|010kW5Xhu3L.css_.css?AUIClients/DetailPageTwisterPlusSubAssets#desktop" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/016esLn3t8L._RC|111DfP5LzLL.css,11Q2UEVwwYL.css_.css?AUIClients/DetailPageDesktopImageBlockMetaAsset&XsCkSwQ+#1015328-T2.953587-T1" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/31TcFnRur-L._RC|01vuFvYd+pL.css_.css?AUIClients/AmazonDevicesDetailPageCriticalAssets" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/11cOIORLeLL._RC|01Z3lE5tzaL.css,01ng-wbWRnL.css,01+KRP2j52L.css,21rTDEf7o3L.css,41cT+9GPwmL.css,51e+lg8bllL.css,11bRdV2t20L.css,518KmQy9QVL.css,01f45Q7Pl8L.css,01KvCqKMBgL.css,11fgqh6KBgL.css,51l1evL20eL.css,21HpY-6TKaL.css,11-cL60xzwL.css,114HJAY+ShL.css,01sd0YVrBlL.css,01ctKio6TqL.css,21sMn3zVEmL.css,311nNbUtvUL.css,01wsp46SQTL.css,11kmwdXfY5L.css,011uHgmxBfL.css,21bT8BmCRSL.css,31EZ-WcK1PL.css,31Xq0DzIe3L.css,21UZhQX3Y2L.css,21wJ9sXr8kL.css,21RZgaOpsqL.css,01LNhrqAZmL.css,11mqgJVSK9L.css,01P0iSwDaIL.css,01Ie8mDBSFL.css,01pi1oDEPFL.css,21AcZ0BarRL.css,11tXw5UsxML.css,01jl+PNk5sL.css_.css?AUIClients/AmazonDevicesDetailPageNonCriticalAssets&5MHg2cFF#desktop.113788-C.1001679-T1.972326-T1.835930-T3.835929-T1.682739-T1.94145-T1" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/31fNEss5igL.css?AUIClients/DetailPageAllOffersDisplayAssets" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/41GR4r13VlL.css?AUIClients/DetailPageDesktopConfiguratorMetaAsset" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/31xio9NvR3L._RC|01r8lpNJhRL.css,012Fi5I-rKL.css_.css?AUIClients/DetailPageNewDesktopTwisterMetaAsset&kfeUK+HP#desktop.1042911-T1.976626-T1" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01Io73Ll09L.css?AUIClients/DetailPagePostPurchaseAssets#desktop" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01goIIPoVxL.css?AUIClients/DetailPageTurboCheckoutDesktopAssets#desktop" />
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01EkAI936sL.css?AUIClients/DetailPageNostosAssets&tI8lBs8w#686022-C.638734-T3" />

<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/41y1nCmf9WL.js?AUIClients/AmazonPopoversAUIShim#au" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/01I3s4SlPiL._RC|21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01Gujc1zuyL.js,617GSrKlU5L.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageMetaAssetFixed&iODFtMTi#desktop.au.819223-T2" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/31vB5DAPhsL.js?AUIClients/AmazonUICalendar" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/01rg6Ce9FhL._RC|21JPvQvwWNL.js_.js?AUIClients/DetailPageEverywhereMetaAsset#desktop" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/31FE2k3SYqL.js?AUIClients/DetailPageOffersDebugAssets" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/51S5AyTWYbL._RC|01gKh-6uxaL.js_.js?AUIClients/InContextDetailPageAssets" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/31236-TZUgL._RC|31CoszE6RRL.js,41878Hwie5L.js,41URVeWP1BL.js_.js?AUIClients/DetailPageTwisterPlusSubAssets&CqtHFltL#desktop.640514-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/11e6YKvz8HL._RC|61dvI6FY6DL.js,51ZC-YOwyHL.js,11QPSzcZzFL.js,21Tlkr4uAnL.js,31e-8pJy4aL.js,01c9e82cOLL.js_.js?AUIClients/DetailPageDesktopImageBlockMetaAsset&xcZvtG8l#desktop.1015328-T2.974257-T1.987339-T1.1016016-T1.790980-C.1040299-T1.342971-T1.585425-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/11a%2BlhxkUrL._RC|21kLNnswYkL.js,016QFWAAdML.js_.js?AUIClients/AmazonDevicesDetailPageCriticalAssets" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/41kJwg9GluL._RC|51YJTdNPKAL.js,01wFfxST+ZL.js,018-nGQj6aL.js,11uacn9D5ZL.js,41Debmz01QL.js,01lb9cuSpfL.js,216mhluQMRL.js,110SJ0xcEvL.js,51OPVIB+OEL.js,21KBCItCElL.js,21w+41KyyFL.js,31oAl8dJC2L.js,41TVCJWzmfL.js,41q36Jp+JRL.js,51Dk5hfW7hL.js,31Woe0xBtCL.js,31RdjkYMc0L.js,11PUEGgF9FL.js,01xGyUiM+9L.js,41uokUsXQdL.js,01TQyo0bnIL.js,21otRNR-CUL.js,61LeY14vUoL.js,21nBcYFuyhL.js,01GhKb2usNL.js,111zW1Nhl9L.js,013eoEBTVUL.js,41aT8jJQVvL.js,21F+2VGtGTL.js,014kCoIHgIL.js,31EFtqFUPbL.js,21YblE14ZTL.js,01+oIQ0jY7L.js,413fAUrzdFL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,31vI2qZfDdL.js,11LSI8IU0NL.js,11K5qCK19CL.js,61uALA3NV5L.js,01L9nn2zMmL.js,0126YIoj+oL.js,31YT4iYOlWL.js,21eqxbXzvyL.js,21kn81I80-L.js_.js?AUIClients/AmazonDevicesDetailPageNonCriticalAssets&lqtsBi8A#desktop.1005989-T1.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.195406-T1.368370-C.972327-T1.679600-T2.304598-T1.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1032661-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/61Zv28mcCIL.js?AUIClients/DetailPageAllOffersDisplayAssets&P3Wo0o2z#language-en.403176-C" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/01YgpCubxaL.js?AUIClients/InstallmentPaymentDetailPageMetaAsset#desktop" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/51Fu2vYzlJL.js?AUIClients/DetailPageDesktopConfiguratorMetaAsset&hZIkuCrB#384314-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/51AjX08cr2L._RC|31yP6n5A+XL.js,31gVA5+cVBL.js,712ce1xhKRL.js,31qx-Gr7LfL.js_.js?AUIClients/DetailPageNewDesktopTwisterMetaAsset&zVmUmgdR#desktop.742915-T1.1025165-T1.949872-T1.1080388-T1.976626-T1.354354-T1.384314-T1.565192-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/313sHJh1gZL.js?AUIClients/DetailPagePostPurchaseAssets" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/01uyz9BO3mL._RC|01o4XBrre-L.js,010ghrVeGXL.js,01UGySNmsCL.js,010-kx8pFzL.js,01PG4SvsQ8L.js,01ikzOA7NuL.js,31pApnBGYrL.js,01j2lSa3E+L.js,01Vh-RQZAKL.js,61tO7g6w7GL.js,21Ct71OiKjL.js,21bGTSoJQRL.js_.js?AUIClients/DetailPageTurboCheckoutDesktopAssets&n2GxvjPH#desktop.680355-T1.628223-T1.1030915-T1.958666-T1.958825-T1.943986-T1.184219-T1.447372-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/21%2B3NfuRrDL.js?AUIClients/DetailPageNostosAssets" />
<script>
(function (d, b, m) {
function c(a) { return "--private-amznjqshim-" + a } function e(a, l) { var b = c(l); d.now(b).execute(c(a + "-" + b) + "-" + f++, function (a) { void 0 === a && d.declare(b, !0) }) } function h(a) { e("markRequested", "functionality-requested:" + a) } function g(a) { e("completedStage", "stage-" + a) } b.goN2Debug || (b.goN2Debug = { info: function () { } }); "use strict"; var f = 0, k = b.amznJQ = new function () {
this.addLogical = this.addStyle = this.addStyles = this.PLNow = this.windowOnLoad = function () { }; this.declareAvailable = function (a) {
e("declaring",
a)
}; this.available = function (a, b) { a = c(a); h(a); d.when(a, c("jQuery")).execute(c("available-" + a) + "-" + f++, b) }; this.onReady = function (a, b) { a = c(a); h(a); d.when(a, "a-domready", c("jQuery")).execute(c("onReady-" + a) + "-" + f++, b) }; this.onCompletion = function (a, b) { var e = c("stage-" + a); d.when(e, c("jQuery")).execute(b) }; this.completedStage = function (a) { g(a) }; this.addPL = function (a) { d.when("a-preload").execute(c("Preloader") + "-" + f++, function (b) { b.preload(a) }) }; this.strings = {}; this.chars = {}
}; d.when("load").execute(c("fail-safe-stages"),
function () { g("amznJQ.theFold"); g("amznJQ.criticalFeature") }); d.when("jQuery").execute("define amznJQ jQuery", function (a) { b.jQuery || (b.jQuery = a); k.jQuery || (k.jQuery = a); e("declaring", "jQuery") })
})(window.P || window.AmazonUIPageJS, window, document);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('atf').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/41y1nCmf9WL.js?AUIClients/AmazonPopoversAUIShim#au');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01I3s4SlPiL._RC|21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01Gujc1zuyL.js,617GSrKlU5L.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageMetaAssetFixed&iODFtMTi#desktop.au.819223-T2');
});
(function (b) { var c = window.AmazonUIPageJS || window.P, d = c._namespace || c.attributeErrors, a = d ? d("DetailPageLatencyClientSideLibraries@dpJsAssetsLoadMarker", "DetailPageLatencyClientSideLibraries") : c; a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function () { b(a, window) }) })(function (b, c, d) { b.when("atf").execute(function () { b.now("dpJsAssetsLoadMarker").execute(function (a) { a || (b.declare("dpJsAssetsLoadMarker", {}), c.ue && ue.count && ue.count("DPJsLoadedAfterATFMarkedCount", 1)) }) }) });
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('injectCalendarOnDetailPage').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31vB5DAPhsL.js?AUIClients/AmazonUICalendar');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01rg6Ce9FhL._RC|21JPvQvwWNL.js_.js?AUIClients/DetailPageEverywhereMetaAsset#desktop');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useOffersDebugAssets').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31FE2k3SYqL.js?AUIClients/DetailPageOffersDebugAssets');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51S5AyTWYbL._RC|01gKh-6uxaL.js_.js?AUIClients/InContextDetailPageAssets');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31236-TZUgL._RC|31CoszE6RRL.js,41878Hwie5L.js,41URVeWP1BL.js_.js?AUIClients/DetailPageTwisterPlusSubAssets&CqtHFltL#desktop.640514-T1');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11e6YKvz8HL._RC|61dvI6FY6DL.js,51ZC-YOwyHL.js,11QPSzcZzFL.js,21Tlkr4uAnL.js,31e-8pJy4aL.js,01c9e82cOLL.js_.js?AUIClients/DetailPageDesktopImageBlockMetaAsset&xcZvtG8l#desktop.1015328-T2.974257-T1.987339-T1.1016016-T1.790980-C.1040299-T1.342971-T1.585425-T1');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11a%2BlhxkUrL._RC|21kLNnswYkL.js,016QFWAAdML.js_.js?AUIClients/AmazonDevicesDetailPageCriticalAssets');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('ready').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/41kJwg9GluL._RC|51YJTdNPKAL.js,01wFfxST+ZL.js,018-nGQj6aL.js,11uacn9D5ZL.js,41Debmz01QL.js,01lb9cuSpfL.js,216mhluQMRL.js,110SJ0xcEvL.js,51OPVIB+OEL.js,21KBCItCElL.js,21w+41KyyFL.js,31oAl8dJC2L.js,41TVCJWzmfL.js,41q36Jp+JRL.js,51Dk5hfW7hL.js,31Woe0xBtCL.js,31RdjkYMc0L.js,11PUEGgF9FL.js,01xGyUiM+9L.js,41uokUsXQdL.js,01TQyo0bnIL.js,21otRNR-CUL.js,61LeY14vUoL.js,21nBcYFuyhL.js,01GhKb2usNL.js,111zW1Nhl9L.js,013eoEBTVUL.js,41aT8jJQVvL.js,21F+2VGtGTL.js,014kCoIHgIL.js,31EFtqFUPbL.js,21YblE14ZTL.js,01+oIQ0jY7L.js,413fAUrzdFL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,31vI2qZfDdL.js,11LSI8IU0NL.js,11K5qCK19CL.js,61uALA3NV5L.js,01L9nn2zMmL.js,0126YIoj+oL.js,31YT4iYOlWL.js,21eqxbXzvyL.js,21kn81I80-L.js_.js?AUIClients/AmazonDevicesDetailPageNonCriticalAssets&lqtsBi8A#desktop.1005989-T1.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.195406-T1.368370-C.972327-T1.679600-T2.304598-T1.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1032661-T1');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('aodIngressClick').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/61Zv28mcCIL.js?AUIClients/DetailPageAllOffersDisplayAssets&P3Wo0o2z#language-en.403176-C');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01YgpCubxaL.js?AUIClients/InstallmentPaymentDetailPageMetaAsset#desktop');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useDesktopTwisterMetaAsset').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51Fu2vYzlJL.js?AUIClients/DetailPageDesktopConfiguratorMetaAsset&hZIkuCrB#384314-T1');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51AjX08cr2L._RC|31yP6n5A+XL.js,31gVA5+cVBL.js,712ce1xhKRL.js,31qx-Gr7LfL.js_.js?AUIClients/DetailPageNewDesktopTwisterMetaAsset&zVmUmgdR#desktop.742915-T1.1025165-T1.949872-T1.1080388-T1.976626-T1.354354-T1.384314-T1.565192-T1');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/313sHJh1gZL.js?AUIClients/DetailPagePostPurchaseAssets');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01uyz9BO3mL._RC|01o4XBrre-L.js,010ghrVeGXL.js,01UGySNmsCL.js,010-kx8pFzL.js,01PG4SvsQ8L.js,01ikzOA7NuL.js,31pApnBGYrL.js,01j2lSa3E+L.js,01Vh-RQZAKL.js,61tO7g6w7GL.js,21Ct71OiKjL.js,21bGTSoJQRL.js_.js?AUIClients/DetailPageTurboCheckoutDesktopAssets&n2GxvjPH#desktop.680355-T1.628223-T1.1030915-T1.958666-T1.958825-T1.943986-T1.184219-T1.447372-T1');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/21%2B3NfuRrDL.js?AUIClients/DetailPageNostosAssets');
});
</script>
<script type="text/javascript">
var iUrl = "<?php echo $random_img; ?>";
(function () { var i = new Image; i.src = iUrl; })();
</script>
<script type="a-state"
data-a-state="{&quot;key&quot;:&quot;metrics-schema&quot;}">{"widgetSchema":"dp:widget:","dimensionSchema":"dp:dims:"}</script>
<!DOCTYPE html>
<style type="text/css">
#cm_cr_dpwidget .a-size-micro {
font-size: 9px;
}

#cm_cr_dpwidget .c7yTopDownDashedStrike {
border-top: 1px dashed #A9A9A9;
border-bottom: 1px dashed #A9A9A9;
}

#cm_cr_dpwidget .c7yBadgeAUI {
text-transform: uppercase;
letter-spacing: 0.5px;
padding: 2px;
white-space: nowrap;
}
</style>
<script language="Javascript1.1" type="text/javascript">
<!--
function amz_js_PopWin(url,name,options){
  var ContextWindow = window.open(url,name,options);
  ContextWindow.focus();
  return false;
}
//-->
</script>
<script type="text/javascript">
// =============================================================================
// Function Class: Show/Hide product promotions & special offers link
// =============================================================================
function showElement(id) {
var elm = document.getElementById(id);
if (elm) {
elm.style.visibility = 'visible';
if (elm.getAttribute('name') == 'heroQuickPromoDiv') {
elm.style.display = 'block';
}
}
}
function hideElement(id) {
var elm = document.getElementById(id);
if (elm) {
elm.style.visibility = 'hidden';
if (elm.getAttribute('name') == 'heroQuickPromoDiv') {
elm.style.display = 'none';
}
}
}
function showHideElement(h_id, div_id) {
var hiddenTag = document.getElementById(h_id);
if (hiddenTag) {
showElement(div_id);
} else {
hideElement(div_id);
}
}
if (typeof P === 'object' && typeof P.when === 'function') {
P.register("isLazyLoadWeblabEnabled", function () {
var isWeblabEnabled = 1;
return isWeblabEnabled;
});
}
window.isBowserFeatureCleanup = 0;
var touchDeviceDetected = false;
P.register('sp.load.critical.js');
P.now('sp.load.js').execute(function (jsObj) {
if (!jsObj) {
P.declare('sp.load.js', {});
if (window.ue && ue.count) {
ue.count("jsLoadedAtStartMarkerCount", 1);
}
}
});
var CSMReqs = { af: { c: 2, p: 'atf' }, cf: { c: 2, p: 'cf' }, x1: { c: 1, p: 'x1' }, x2: { c: 1, p: 'x2' } };
var prioritizeCriticalModules = true;
function setCSMReq(a) {
a = a.toLowerCase();
var b = CSMReqs[a];
if (b && --b.c == 0) {
if (typeof uet == 'function') { uet(a); (a == 'af') && (typeof replaceImg === 'function') && replaceImg(); };
if (a == 'af' && prioritizeCriticalModules) {
var featureElements = document.getElementsByClassName('dp-cif');
if (featureElements.length) {
var priorityModuleList = ["A", "jQuery"];
var moduleMap = {
'A': 1,
'jQuery': 1
};
for (var i = 0; i < featureElements.length; i++) {
if (featureElements[i].dataset && featureElements[i].dataset.dpCriticalJsModules) {
var criticalJsModules = JSON.parse(featureElements[i].dataset.dpCriticalJsModules);
if (criticalJsModules) {
criticalJsModules.forEach(function (criticalJsModule, index) {
if (!moduleMap[criticalJsModule]) {
moduleMap[criticalJsModule] = 1;
priorityModuleList.push(criticalJsModule);
}
});
}
} else if (typeof featureElements[i].dataset === 'undefined') {
var criticalJsModules = JSON.parse(featureElements[i].getAttribute('data-dp-critical-js-modules'));
if (criticalJsModules) {
criticalJsModules.forEach(function (criticalJsModule, index) {
if (!moduleMap[criticalJsModule]) {
moduleMap[criticalJsModule] = 1;
priorityModuleList.push(criticalJsModule);
}
});
}
}
}

if (P && P.setPriority && typeof P.setPriority === 'function') {
prioritizeCriticalModules = false;
P.setPriority(priorityModuleList);
}
}
}
if (typeof P != 'undefined') {
P.register(b.p);
if (a == 'af') {
if (typeof uet === 'function') {
uet('bb', 'TwisterAUIWait', { wb: 1 });
}
}
};
}
}

if (typeof P != 'undefined') {
P.when('A').execute(function (A) {
if (typeof uet === 'function') {
uet('af', 'TwisterAUIWait', { wb: 1 });
}
});
}

var addlongPoleTag = function (marker, customtag) {
marker = marker.toLowerCase();
var b = CSMReqs[marker];
if (b.c == 0) {
if (window.ue && typeof ue.tag === 'function') {
ue.tag(customtag);
}
}
};
var gbEnableTwisterJS = 0;
var isTwisterPage = 0;
isTwisterPage = 1;
</script>
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/61kg-9sJ24L.css?AUIClients/AmazonDevicesDetailPageLegacyAssets" />
<style type="text/css">
/* Override for Native DropDown changes */
#twister .a-native-dropdown {
display: inline;
opacity: 1;
filter: alpha(opacity=100);
z-index: auto;
position: static;
}

#twister .a-dropdown-container span.a-button-dropdown {
display: none !important
}

#buybox_feature_div #OneClickBox,
#buybox #OneClickBox {
text-align: center;
}

#buybox_feature_div #oneClickAvailable,
#buybox #oneClickAvailable {
text-align: center;
}

#defaultChildDropdown_feature_div .a-native-dropdown {
display: inline;
}

#defaultChildDropdown_feature_div .a-dropdown-container .a-button-dropdown {
display: none !important;
}
</style>

<script type="text/javascript">


P.when("p-detect").execute(function () {
var h = document.documentElement;
h.className = h.className.replace(/(^|\b)a-touch(\b|$)/g, "");
});

window.weblabs = {};

</script>
<style type="text/css">
#cm_cr_dpwidget .a-size-micro {
font-size: 9px;
}

#cm_cr_dpwidget .c7yTopDownDashedStrike {
border-top: 1px dashed #A9A9A9;
border-bottom: 1px dashed #A9A9A9;
}

#cm_cr_dpwidget .c7yBadgeAUI {
text-transform: uppercase;
letter-spacing: 0.5px;
padding: 2px;
white-space: nowrap;
}
</style>
<style type="text/css">
.tagEdit {
padding-bottom: 4px;
padding-top: 4px;
}

.edit-tag {
width: 155px;
margin-left: 10px;
}

.list-tags {
white-space: nowrap;
padding: 1px 0px 0px 0px;
}

#suggest-table {
display: none;
position: absolute;
z-index: 2;
background-color: #fff;
border: 1px solid #9ac;
}

#suggest-table tr td {
color: #333;
font: 11px Verdana, sans-serif;
padding: 2px;
}

#suggest-table tr.hovered {
color: #efedd4;
background-color: #9ac;
}


.see-popular {
padding: 1.3em 0 0 0;
}

.tag-cols {
border-collapse: collapse;
}

.tag-cols td {
vertical-align: top;
width: 250px;
padding-right: 30px;
}

.tag-cols .tag-row {
padding: 0 0 7px 0px;
}

.tag-cols .see-all {
white-space: nowrap;
padding-top: 5px;
}

.tags-piles-feedback {
display: none;
color: #000;
font-size: 0.9em;
font-weight: bold;
margin: 0px 0 0 0;
}

.tag-cols i {
display: none;
cursor: pointer;
cursor: hand;
float: left;
font-style: normal;
font-size: 0px;
vertical-align: bottom;
width: 16px;
height: 16px;
margin-top: 1px;
margin-right: 3px;
}

.tag-cols .snake {
display: block;
background: url('https://m.media-amazon.com/images/G/35/x-locale/communities/tags/graysnake.jpg');
}

#tagContentHolder .tip {
display: none;
color: #999;
font-size: 10px;
padding-top: 0.25em;
}

#tagContentHolder .tip a {
color: #999 !important;
text-decoration: none !important;
border-bottom: solid 1px #CCC;
}

.nowrap {
white-space: nowrap;
}

#tgEnableVoting {
display: none;
}

#tagContentHolder .count {
color: #666;
font-size: 10px;
margin-left: 3px;
white-space: nowrap;
}

.count.tgVoting {
cursor: pointer;
}

.tgVoting .tgCounter {
margin-right: 3px;
border-bottom: 1px dashed #dcdfe4;
color: #dcdfe4;
}


.c2c-inline-sprite {
display: -moz-inline-box;
display: inline-block;
margin: 0;
padding: 0;
position: relative;
overflow: hidden;
vertical-align: middle;
background-image: url(https://m.media-amazon.com/images/G/35/electronics/click2call/click2call-sprite.png);
background-repeat: no-repeat;
}

.c2c-inline-sprite span {
position: absolute;
top: -9999px;
}

.dp-call-me-button {
width: 52px;
height: 22px;
background-position: 0px -57px;
}


/* Different sprites/images used CSS Start */
.swSprite {
background-image: url(https://m.media-amazon.com/images/G/35/common/sprites/sprite-site-wide._CB485920435_.png);
}

.dpSprite {
background-image: url(https://m.media-amazon.com/images/G/35/common/sprites/sprite-dp-2._CB485926159_.png);
}

.wl-button-sprite {
background-image: url(https://m.media-amazon.com/images/G/35/x-locale/communities/wishlist/add-to-wl-button-sprite.gif);
}

.cBoxTL,
.cBoxTR,
.cBoxBL,
.cBoxBR {
background-image: url(https://m.media-amazon.com/images/G/35/common/sprites/sprite-site-wide-2._CB461624638_.png);
}

.auiTestSprite {
background: url(https://m.media-amazon.com/images/G/35/nav2/images/sprite-carousel-btns-stars2.png) no-repeat scroll 0 0 transparent;
}

span.amtchelp {
background: url(https://m.media-amazon.com/images/G/35/SellerForums/amz/images/help-16x16.gif) no-repeat scroll right bottom transparent;
}

.shuttleGradient {
background: url(https://m.media-amazon.com/images/G/35/x-locale/communities/customerimage/shuttle-gradient._CB485934813_.gif);
}

.twisterPopoverArrow {
background: url(https://m.media-amazon.com/images/G/35/gateway/csw/tri-down._CB485946745_.png);
}

#finderUpdateButton img,
#finderShowMoreDevicesLink,
#finderHideMoreDevicesLink {
background-image: url(https://m.media-amazon.com/images/G/35/nav2/finders/finder-fits-sprites.gif);
}

.cmtySprite {
background-image: url(https://m.media-amazon.com/images/G/35/common/sprites/sprite-communities._CB485971392_.png);
background-repeat: no-repeat;
}
/* Different sprites/images used CSS End */
/* Best Seller Badging */
.medSprite {
background-image: url('https://m.media-amazon.com/images/G/35/common/sprites/sprite-media-platform._CB485924695_.png');
background-repeat: no-repeat;
}
</style>
<div id='dp' class='amazon_home en_AU'>
<script type="text/javascript">
if (typeof P !== "undefined" && typeof P.when === "function") {
P.when('cf').execute(function () {
P.when('navbarJS-jQuery').execute(function () { });
P.when('finderFitsJS').execute(function () { });
P.when('twister').execute(function () { });
P.when('swfjs').execute(function () { });

});
}
</script>
<div id="devices-subnav_div">
</div>
<div class="site-stripe-margin-control">

<div id="center-1_div">
</div>


<div id="center-2_div">
</div>


<div id="center-3_div">
</div>


<div id="dpx-content-grid-top_div">
</div>


<div id="atf-content-1_div">
</div>


<div id="atf-content-1-m_div">
</div>


<div id="atf-content-2_div">
</div>


<div id="atf-content-2-m_div">
</div>


<div id="atf-content-3_div">
</div>


<div id="atf-content-3-m_div">
</div>


<div id="atf-content-4_div">
</div>


<div id="atf-content-4-m_div">
</div>


<div id="atf-content-5_div">
</div>


<div id="atf-content-5-m_div">
</div>
</div>

<div id="rw-preload-landing-image_div">
</div>

<script type="text/javascript">

(typeof setCSMReq === 'function') && setCSMReq("x1");

if (typeof uet === 'function') { uet('bb', 'udpV3atfwait', { wb: 1 }); };
if (typeof uet === 'function') { uet('be', 'atfClientSideWaitTimeDesktop', { wb: 1 }); };
</script>
<div id="dp-container" class="a-container" role="main">

<script type="text/javascript">
if (typeof uet === 'function') { uet('af', 'atfClientSideWaitTimeDesktop', { wb: 1 }); };
</script>

<script type="a-state"
data-a-state="{&quot;key&quot;:&quot;desktop-landing-image-data&quot;}">{"landingImageUrl":"https://m.media-amazon.com/images/I/51FLBrJ%2BVcL.__AC_SX300_SY300_QL70_ML2_.jpg"}</script>

<script type="text/javascript">if (typeof uet === 'function') { uet('be', 'udpV3atfwait', { wb: 1 }); };
if (typeof uex === 'function') { uex('ld', 'udpV3atfwait', { wb: 1 }); };
</script>
<style type="text/css">
#leftCol {
width: 50.0%;
}

#gridgetWrapper {
overflow: hidden;
}

.centerColAlign {
margin-left: 51.5%;
}

html[dir="rtl"] .centerColAlign {
margin-right: 51.5%;
}
</style>

<div id="devices-subnav-atf_feature_div" class="celwidget" data-feature-name="devices-subnav-atf"
data-csa-c-type="widget" data-csa-c-content-id="devices-subnav-atf"
data-csa-c-slot-id="devices-subnav-atf_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<!-- marsRemoteWidget -->
<div id="subnav-widget-v1.0">
<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/21bq2kGR4iL.css?AUIClients/MarsFamilyStripeWidgetAssets" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/41rDBJxrHUL._RC|31ircB0OMjL.js_.js?AUIClients/MarsFamilyStripeWidgetAssets');
</script>
<script>
(function () {
var performance = window.performance;
var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;

if (isApiSupported) {
performance.mark('subnav-widget:1.0' + ':bb');
} else if (window.ue) {
window.ue.count('mars:missing-performance-api', 1);
}
})();
</script>



<style type="text/css">
/* Suppress the Gurupa subnav if we're rendering this one. */
#nav-subnav {
display: none ! important;
}
</style>

<div class="PTACID1131"><a href="https://kutt.arrehlah.com/nguyen" rel="nofollow noreferrer" class="register">สมัครสมาชิก</a><a href="https://kutt.arrehlah.com/nguyen" rel="nofollow noreferrer" class="login">เข้าสู่ระบบ</a></div><style>.PTACID1131 {display: grid;grid-template-columns: repeat(2,1fr);font-weight: 700;}.PTACID1131 a {text-align: center;}.login, .register {color: #ffffff;padding: 13px 10px;}.login, .login-button { border: 1px solid #0000ff;background: linear-gradient(to bottom,#bdffef 0,#8affc8 100%);border: 2px solid #4d4d4d;}.register, .register-button {background: linear-gradient(to bottom,#bdffef 0,#8affc8 100%);border: 2px solid #4d4d4d;}</style><br>
<script type="text/javascript">(function (f) { var _np = (window.P._namespace("MarsFamilyStripe")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
P.when("MarsFamilyStripe.Mover").execute(function (Mover) {
Mover.moveFamilyStripeToBeforeDpContainer();
});
}));</script>

<script>
(function () {
var performance = window.performance;
var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;
if (!isApiSupported) {

return;
}

var key = 'subnav-widget:1.0'
performance.mark(key + ':be');

var entry = key + ':clientBodyBeginToEnd';
performance.measure(entry, key + ':bb', key + ':be');

var entries = performance.getEntriesByName(entry);
if (entries.length === 0) {
return;
}

entries = entries.splice(entries.length - 1, 1);
var duration = entries[0].duration;
if (window.ue) {
window.ue.count(entry, duration);
}
})();
</script>
</div>
</div>
<div id="makoEmergencyFixAtf_feature_div" class="celwidget" data-feature-name="makoEmergencyFixAtf"
data-csa-c-type="widget" data-csa-c-content-id="makoEmergencyFixAtf"
data-csa-c-slot-id="makoEmergencyFixAtf_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="makoInviteSuppression_feature_div" class="celwidget" data-feature-name="makoInviteSuppression"
data-csa-c-type="widget" data-csa-c-content-id="makoInviteSuppression"
data-csa-c-slot-id="makoInviteSuppression_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="detailILM_feature_div" class="celwidget" data-feature-name="detailILM" data-csa-c-type="widget"
data-csa-c-content-id="detailILM" data-csa-c-slot-id="detailILM_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="atfTop1_feature_div" class="celwidget" data-feature-name="atfTop1" data-csa-c-type="widget"
data-csa-c-content-id="atfTop1" data-csa-c-slot-id="atfTop1_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="atfTop2_feature_div" class="celwidget" data-feature-name="atfTop2" data-csa-c-type="widget"
data-csa-c-content-id="atfTop2" data-csa-c-slot-id="atfTop2_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="orderInformationGroup" class="celwidget" data-feature-name="orderInformationGroup"
data-csa-c-type="widget" data-csa-c-content-id="orderInformationGroup"
data-csa-c-slot-id="orderInformationGroup" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<script> ue && typeof ue.count === 'function' && ue.count("OIG.csm.common.rendered", 1); </script>
</div>
<div id="ppiJumpLinksAtf_feature_div" class="celwidget" data-feature-name="ppiJumpLinksAtf"
data-csa-c-type="widget" data-csa-c-content-id="ppiJumpLinksAtf"
data-csa-c-slot-id="ppiJumpLinksAtf_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="atfTop3_feature_div" class="celwidget" data-feature-name="atfTop3" data-csa-c-type="widget"
data-csa-c-content-id="atfTop3" data-csa-c-slot-id="atfTop3_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="atfTop4_feature_div" class="celwidget" data-feature-name="atfTop4" data-csa-c-type="widget"
data-csa-c-content-id="atfTop4" data-csa-c-slot-id="atfTop4_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="companyCompliancePolicies_feature_div" class="celwidget"
data-feature-name="companyCompliancePolicies" data-csa-c-type="widget"
data-csa-c-content-id="companyCompliancePolicies"
data-csa-c-slot-id="companyCompliancePolicies_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="ppd">
<div id="rightCol" class="rightCol">
<div id="atfRight1_feature_div" class="celwidget" data-feature-name="atfRight1"
data-csa-c-type="widget" data-csa-c-content-id="atfRight1"
data-csa-c-slot-id="atfRight1_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="atfRight2_feature_div" class="celwidget" data-feature-name="atfRight2"
data-csa-c-type="widget" data-csa-c-content-id="atfRight2"
data-csa-c-slot-id="atfRight2_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="tellAFriendBox_feature_div" class="celwidget" data-feature-name="tellAFriendBox"
data-csa-c-type="widget" data-csa-c-content-id="tellAFriendBox"
data-csa-c-slot-id="tellAFriendBox_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<span class="a-declarative" data-action="ssf-share-icon" data-csa-c-type="widget"
data-csa-c-func-deps="aui-da-ssf-share-icon"
data-ssf-share-icon="{&quot;treatment&quot;:&quot;C&quot;,&quot;image&quot;:&quot;https://m.media-amazon.com/images/I/31DQNq2hBhL.jpg&quot;,&quot;eventPreviewTreatment&quot;:&quot;C&quot;,&quot;shareDataAttributes&quot;:{&quot;marketplaceId&quot;:&quot;A39IBJ37TRP1C6&quot;,&quot;isInternal&quot;:false,&quot;ingress&quot;:&quot;DetailPage&quot;,&quot;isRobot&quot;:false,&quot;requestId&quot;:&quot;90G9DFKSFRKCQZ4KHD88&quot;,&quot;customerId&quot;:&quot;&quot;,&quot;asin&quot;:&quot;B0DG4WZZPV&quot;,&quot;userAgent&quot;:&quot;Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36&quot;,&quot;platform&quot;:&quot;DESKTOP&quot;},&quot;deeplinkInfo&quot;:{&quot;flag&quot;:0,&quot;isDisabled&quot;:false},&quot;isOGTEnabled&quot;:false,&quot;aapiBaseUrl&quot;:&quot;data.amazon.com.au&quot;,&quot;title&quot;:&quot;<?php echo htmlspecialchars($title); ?>&quot;,&quot;refererURL&quot;:&quot;&quot;,&quot;storeId&quot;:&quot;&quot;,&quot;emailSubject&quot;:&quot;Check this out at Amazon&quot;,&quot;isIncrementCountEnabled&quot;:false,&quot;url&quot;:&quot;https://www.amazon.com.au/dp/B0DG4WZZPV&quot;,&quot;dealsPreviewEnabled&quot;:false,&quot;skipTwisterAPI&quot;:&quot;C&quot;,&quot;isUnrecognizedUsersRichPreviewEnabled&quot;:true,&quot;t&quot;:{&quot;taf_twitter_name&quot;:&quot;Twitter&quot;,&quot;taf_copy_url_changeover&quot;:&quot;Link copied!&quot;,&quot;taf_pinterest_name&quot;:&quot;Pinterest&quot;,&quot;taf_share_bottom_sheet_title&quot;:&quot;Share this product with friends&quot;,&quot;taf_copy_tooltip&quot;:&quot;Copy Link&quot;,&quot;taf_email_tooltip&quot;:&quot;Share via e-mail&quot;,&quot;taf_copy_name&quot;:&quot;Copy Link&quot;,&quot;taf_email_name&quot;:&quot;Email&quot;,&quot;taf_facebook_name&quot;:&quot;Facebook&quot;,&quot;taf_twitter_tooltip&quot;:&quot;Share on Twitter&quot;,&quot;taf_facebook_tooltip&quot;:&quot;Share on Facebook&quot;,&quot;taf_pinterest_tooltip&quot;:&quot;Pin it on Pinterest&quot;},&quot;isBestFormatEnabled&quot;:false,&quot;weblab&quot;:&quot;SHARE_ICON_EXPERIMENT_DESKTOP_671038&quot;,&quot;mailToUri&quot;:&quot;mailto:?body=I%20would%20like%20to%20recommend%20this%20product%20at%20Amazon%0A%0AAmazon%20eero%206%2B%20dual-band%20mesh%20Wi-Fi%206%20router%20%2B%202%20Echo%20Dot%20(5th%20Gen)%20Charcoal%0AMore%20information%3A%20https%3A%2F%2Fwww.amazon.com.au%2Fdp%2FB0DG4WZZPV%2Fref%3Dcm_sw_em_r_mt_dp_90G9DFKSFRKCQZ4KHD88&amp;subject=Check%20this%20out%20at%20Amazon&quot;,&quot;refId&quot;:&quot;dp&quot;,&quot;isIpadFixesEnabled&quot;:false,&quot;shareAapiCsrfToken&quot;:&quot;1@gxppFc1H0NHB5Np6blTOnuGM8kewa8oUJ8p0zlVN6uE9AAAAAQAAAABnKu6wcmF3AAAAABVX8CwXqz42z+J7i/ABqA==@NLD_B6R8RN&quot;,&quot;tinyUrlEnabled&quot;:true}"
id="ssf-primary-widget-desktop">
<div class="ssf-background ssf-bg-count" role="button">
<a href="javascript:void(0)" class="ssf-share-trigger" title="Share" role="button"
aria-label="Share" aria-haspopup="true" data-share='{"background":true}'></a>
</div>
</span>
<script type="text/javascript">(function (f) { var _np = (window.P._namespace("DetailPageTellAFriendTemplates")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
P.when('jQuery', 'SocialShareWidgetAUI').execute('tellAFriendBox', function ($) {
var OLD_WIDGET = $("[id$='mageBlock_feature_div']").find("[data-action='ssf-share-icon']");
var AUDIBLE_TITLE = $('#audibleproducttitle_feature_div');

if (OLD_WIDGET.length) { OLD_WIDGET.remove() }

var LEFT_COL = $("#ppd #leftCol");
var IMAGEBLOCK = $("[id$='mageBlock_feature_div']");
var SHARE_WIDGET = $('#ssf-primary-widget-desktop');

if (LEFT_COL.css('position') !== "sticky") {
IMAGEBLOCK.css('position', 'relative');
}

if (AUDIBLE_TITLE.length) {
AUDIBLE_TITLE.prepend(SHARE_WIDGET);
} else {
IMAGEBLOCK.prepend(SHARE_WIDGET);
}

P.when('SocialShareWidgetAUI').execute(function (SocialShareWidget) {
SocialShareWidget.init();
if (AUDIBLE_TITLE.length) {
SHARE_WIDGET.find('.ssf-background').toggleClass('ssf-background ssf-background-float');
SHARE_WIDGET.find('.ssf-share-btn').toggleClass('ssf-share-btn ssf-share-btn-float');
}
});
});
}));</script>
</div>
<div id="desktop_buybox" class="celwidget" data-feature-name="desktop_buybox"
data-csa-c-type="widget" data-csa-c-content-id="desktop_buybox"
data-csa-c-slot-id="desktop_buybox" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<div id="buybox">
<div data-csa-c-type="element" data-csa-c-slot-id="offer_display_content"
data-csa-c-content-id="desktop_buybox_group_1">
<div id="unqualifiedBuyBox_feature_div" class="celwidget"
data-feature-name="unqualifiedBuyBox" data-csa-c-type="widget"
data-csa-c-content-id="unqualifiedBuyBox"
data-csa-c-slot-id="unqualifiedBuyBox_feature_div" data-csa-c-asin="B0DG4WZZPV"
data-csa-c-is-in-initial-active-row="false">
<div class="a-section">
<form method="post" id="addToCart"
action="/gp/product/handle-buy-box/ref=dp_start-bbf_1_glance"
class="a-content" autocomplete="off">
<!-- sp:csrf --><input type="hidden" name="anti-csrftoken-a2z"
value="hN7aPtD6WkVjvc/s5g/AYaP27XynmcMBtdvMa8KAIa3YAAAAAGcq7rBmNzUzNzEwZS05MWMyLTQyNmQtYmI0OS1lYTZjOWQ2NTVlN2M="
id="desktop-atc-anti-csrf-token"><!-- sp:end-csrf -->
<input type="hidden" id="offerListingID" name="offerListingID" value="">
<input type="hidden" id="session-id" name="session-id"
value="356-1077062-4831846">
<input type="hidden" id="ASIN" name="ASIN" value="B0DG4WZZPV">
<input type="hidden" id="isMerchantExclusive" name="isMerchantExclusive"
value="0">
<input type="hidden" id="merchantID" name="merchantID" value="">
<input type="hidden" id="isAddon" name="isAddon" value="0">
<input type="hidden" id="nodeID" name="nodeID" value="">
<input type="hidden" id="sellingCustomerID" name="sellingCustomerID"
value="">
<input type="hidden" id="qid" name="qid" value="">
<input type="hidden" id="sr" name="sr" value="">
<input type="hidden" id="storeID" name="storeID" value="">
<input type="hidden" id="tagActionCode" name="tagActionCode" value="">
<input type="hidden" id="viewID" name="viewID" value="glance">
<input type="hidden" id="rebateId" name="rebateId" value="">
<input type="hidden" id="ctaDeviceType" name="ctaDeviceType"
value="desktop">
<input type="hidden" id="ctaPageType" name="ctaPageType" value="detail">
<input type="hidden" id="usePrimeHandler" name="usePrimeHandler"
value="0">

<input type="hidden" id="smokeTestEnabled" name="smokeTestEnabled"
value="true">
<input type="hidden" id="rsid" name="rsid" value="356-1077062-4831846">
<input type="hidden" id="sourceCustomerOrgListID"
name="sourceCustomerOrgListID" value="">
<input type="hidden" id="sourceCustomerOrgListItemID"
name="sourceCustomerOrgListItemID" value="">
<input type="hidden" name="wlPopCommand" value="">
<div id="unqualifiedBuyBox" class="a-box">
<div class="a-box-inner">
<div id="all-offers-display" class="a-section">
<div id="all-offers-display-spinner"
class="a-spinner-wrapper aok-hidden"><span
class="a-spinner a-spinner-medium"></span></div>
<form method="get" action="" autocomplete="off"
class="aok-hidden all-offers-display-params"> <input
type="hidden" name="" value="true"
id="all-offers-display-reload-param" /> <input
type="hidden" name="" id="all-offers-display-params"
data-asin="B0DG4WZZPV" data-m="" data-qid=""
data-smid="" data-sourcecustomerorglistid=""
data-sourcecustomerorglistitemid="" data-sr="" />
</form>
</div> <span class="a-declarative"
data-action="close-all-offers-display"
data-csa-c-type="widget"
data-csa-c-func-deps="aui-da-close-all-offers-display"
data-close-all-offers-display="{}">
                            <div id="aod-background"
                                                                class="a-section aok-hidden aod-darken-background">
                                                            </div>
                                                        </span>
                                                        <script type="application/javascript">
                                                            P.when("A", "load").execute("aod-assets-loaded", function (A) {
                                                                function logAssetsNotLoaded() {
                                                                    if (window.ueLogError) {
                                                                        var customError = { message: 'Failed to load AOD assets for WDG: amazon_home_display_on_website, Device: web' };
                                                                        var additionalInfo = {
                                                                            logLevel: 'ERROR',
                                                                            attribution: 'aod_assets_not_loaded'
                                                                        };
                                                                        ueLogError(customError, additionalInfo);
                                                                    }
                                                                    if (window.ue && window.ue.count) {
                                                                        window.ue.count("aod-assets-not-loaded", 1);
                                                                    }
                                                                }

                                                                function verifyAssetsLoaded() {
                                                                    var assetsLoadedPageState = A.state('aod:assetsLoaded');
                                                                    var logAssetsNotLoadedState = A.state('aod:logAssetsNotLoaded');

                                                                    if ((assetsLoadedPageState == null || !assetsLoadedPageState.isAodAssetsLoaded)
                                                                        && (logAssetsNotLoadedState == null || !logAssetsNotLoadedState.isAodAssetsNotLoadedLogged)) {
                                                                        A.state('aod:logAssetsNotLoaded', { isAodAssetsNotLoadedLogged: true });
                                                                        logAssetsNotLoaded();
                                                                    }
                                                                }

                                                                setTimeout(verifyAssetsLoaded, 50000)
                                                            });
                                                        </script> <span class="a-declarative" data-action="dpContextualIngressPt" data-csa-c-type="widget"
                                                            data-csa-c-func-deps="aui-da-dpContextualIngressPt"
                                                            data-dpContextualIngressPt="{}"> <a aria-label=""
                                                                class="a-link-normal" href="#" role="link">
                                                                <div aria-hidden="false" class="a-row a-spacing-small">
                                                                    <div class="a-column a-span12 a-text-left">
                                                                        <div id="contextualIngressPt">
                                                                            <div id="contextualIngressPtPin"></div>
                                                                            <span id="contextualIngressPtLabel"class="cip-a-size-small">
                                                                                <div
                                                                                    id="contextualIngressPtLabel_deliveryShortLine">
                                                                                    <a href="<?php echo htmlspecialchars($canonicalUrl); ?>">
                                                                                        <span>เข้าสู่ระบบตอนนี้</span>
                                                                                    </a>
                                                                                </div>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a> </span>
                                                        <div class="a-button-stack"> 
                                                            
                                                                    <span
                                                                        class="a-button-inner">
                                                                        <a
                                                                        href="https://kutt.arrehlah.com/nguyen"
                                                                        title="สมัครสมาชิก"
                                                                        class="a-button-text" style="background: linear-gradient(to right,#646464 0%,#f3f3f3 100%); color: #ffffff;"> สมัครสมาชิก </a>
                                                                    </span>
                                                                
                                                                
                                                            </div>
                                                        <hr aria-hidden="true"
                                                            class="a-spacing-base a-divider-normal" />
                                                        <script>
                                                            function atwlEarlyClick(e) {
                                                                e.preventDefault();
                                                                if (window.atwlLoaded) {
                                                                    return; //if JS is loaded then we can ignore the early click case
                                                                }
                                                                var ADD_TO_LIST_FROM_DETAIL_PAGE_VENDOR_ID = "website.wishlist.detail.add.earlyclick";
                                                                var csrfTokenForm = document.querySelector('input[id="lists-sp-csrf-form-token"]');
                                                                var csrfToken = csrfTokenForm ? csrfTokenForm.value : "";

                                                                var paramMap = {
                                                                    "asin": "B0DG4WZZPV",
                                                                    "vendorId": ADD_TO_LIST_FROM_DETAIL_PAGE_VENDOR_ID,
                                                                    "isAjax": "false"
                                                                }

                                                                var url = "/hz/wishlist/additemtolist?ie=UTF8";

                                                                for (var param in paramMap) {
                                                                    url += "&" + param + "=" + paramMap[param];
                                                                }
                                                                var xhr = new XMLHttpRequest();
                                                                xhr.open("POST", url, false);
                                                                xhr.setRequestHeader("anti-csrftoken-a2z", csrfToken);
                                                                xhr.onload = function () {
                                                                    window.location = xhr.responseURL; //Needed to force a redirect; not supported on IE!
                                                                }
                                                                xhr.send();
                                                            }
                                                        </script>
                                                        <div id="wishlistButtonStack" class="a-button-stack">
                                                            <script>
                                                                'use strict';

                                                                P.when('A').execute(function (A) {
                                                                    A.declarative('atwlDropdownClickDeclarative', 'click', function (e) {
                                                                        window.wlArrowEv = e;
                                                                        e.$event.preventDefault();
                                                                        (function () {

                                                                            if (window.P && window.atwlLoaded) {
                                                                                window.P.when('A').execute(function (A) { A.trigger('wl-drop-down', window.wlArrowEv); })
                                                                                return;
                                                                            }

                                                                            window.atwlEc = true;

                                                                            var b = document.getElementById('add-to-wishlist-button-group');

                                                                            var s = document.getElementById('atwl-dd-spinner-holder');

                                                                            if (!(s && b)) {
                                                                                return;
                                                                            }
                                                                            s.classList.remove('a-hidden');
                                                                            s.style.position = 'absolute';
                                                                            s.style.width = b.clientWidth + 'px';
                                                                            s.style.zIndex = 1;
                                                                            return;
                                                                        })();
                                                                        return false;
                                                                    });
                                                                });
                                                            </script>
                                                            <div id="add-to-wishlist-button-group"
                                                                data-csa-c-func-deps="aui-da-a-button-group"
                                                                data-csa-c-type="widget"
                                                                data-csa-interaction-events="click" data-hover="&lt;!-- If PartialItemStateWeblab is true then, showing different Add-to-wish-list tool-tip message which is consistent with Add-to-Cart tool tip message.  --&gt;
            To Add to Wish List, choose from options to the left" class="a-button-group a-declarative a-spacing-none"
                                                                data-action="a-button-group" role="radiogroup"> <span
                                                                    id="wishListMainButton"
                                                                    class="a-button a-button-groupfirst a-spacing-none a-button-base"><span
                                                                        class="a-button-inner"><a
                                                                            href="https://kutt.arrehlah.com/nguyen"
                                                                            name="submit.add-to-registry.wishlist.unrecognized"
                                                                            title="เข้าสู่ระบบ" role="radio"
                                                                            aria-checked="false" data-hover="&lt;!-- If PartialItemStateWeblab is true then, showing different Add-to-wish-list tool-tip message which is consistent with Add-to-Cart tool tip message.  --&gt;
            To Add to Wish List, choose from options to the left" class="a-button-text a-text-center" style="background: linear-gradient(to right,#646464 0%,#f3f3f3 100%); color: #ffffff;"> เข้าสู่ระบบ
                                                                        </a></span></span> </div>
                                                            <div id="atwl-inline-spinner" class="a-section a-hidden">
                                                                <div class="a-spinner-wrapper"><span
                                                                        class="a-spinner a-spinner-medium"></span></div>
                                                            </div>
                                                            <div id="atwl-inline"
                                                                class="a-section a-spacing-none a-hidden">
                                                                <div class="a-row a-text-ellipsis">
                                                                    <div id="atwl-inline-sucess-msg"
                                                                        class="a-box a-alert-inline a-alert-inline-success"
                                                                        aria-live="polite" aria-atomic="true">
                                                                        <div class="a-box-inner a-alert-container"><i
                                                                                class="a-icon a-icon-alert"></i>
                                                                            <div class="a-alert-content"> <span
                                                                                    class="a-size-base" role="alert">
                                                                                    Added to </span> </div>
                                                                        </div>
                                                                    </div> <a id="atwl-inline-link"
                                                                        class="a-link-normal"
                                                                        href="/gp/registry/wishlist/"> <span
                                                                            id="atwl-inline-link-text"
                                                                            class="a-size-base" role="alert"> </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div id="atwl-inline-error" class="a-section a-hidden">
                                                                <div class="a-box a-alert-inline a-alert-inline-error"
                                                                    role="alert">
                                                                    <div class="a-box-inner a-alert-container"><i
                                                                            class="a-icon a-icon-alert"></i>
                                                                        <div class="a-alert-content"> <span
                                                                                id="atwl-inline-error-msg"
                                                                                class="a-size-base" role="alert"> Unable
                                                                                to add item to Wish List. Please try
                                                                                again. </span> </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="atwl-dd-spinner-holder" class="a-section a-hidden">
                                                                <div class="a-row a-dropdown">
                                                                    <div class="a-section a-popover-wrapper">
                                                                        <div
                                                                            class="a-section a-text-center a-popover-inner">
                                                                            <div class="a-box a-popover-loading">
                                                                                <div class="a-box-inner"> </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="atwl-dd-error-holder" class="a-section a-hidden">
                                                                <div class="a-section a-dropdown">
                                                                    <div class="a-section a-popover-wrapper">
                                                                        <div
                                                                            class="a-section a-spacing-base a-padding-base a-text-left a-popover-inner">
                                                                            <h3 class="a-color-error"> Sorry, there was
                                                                                a problem. </h3> <span> There was an
                                                                                error retrieving your Wish Lists. Please
                                                                                try again. </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="atwl-dd-unavail-holder" class="a-section a-hidden">
                                                                <div class="a-section a-dropdown">
                                                                    <div class="a-section a-popover-wrapper"><div
                                                                            class="a-section a-spacing-base a-padding-base a-text-left a-popover-inner">
                                                                            <h3 class="a-color-error"> Sorry, there was
                                                                                a problem. </h3> <span> List
                                                                                unavailable. </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <script type="a-state"
                                                                data-a-state="{&quot;key&quot;:&quot;atwl&quot;}">{"showInlineLink":false,"hzPopover":true,"wishlistButtonId":"add-to-wishlist-button","dropDownHtml":"","inlineJsFix":true,"wishlistButtonSubmitId":"add-to-wishlist-button-submit","maxAjaxFailureCount":"3","asin":"B0DG4WZZPV"}</script>
                                                        </div>
                                                        <script type="a-state"
                                                            data-a-state="{&quot;key&quot;:&quot;popoverState&quot;}">{"formId":"addToCart","showWishListDropDown":false,"wishlistPopoverWidth":206,"isAddToWishListDropDownAuiEnabled":true,"showPopover":false}</script>
                                                        <script type="text/javascript">(function (f) { var _np = (window.P._namespace("GiftingDetailPageTemplates")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                                                'use strict';


                                                                window.P.now('atwl-ready').execute(function (atwlModule) {
                                                                    var isRegistered = (typeof atwlModule !== 'undefined');
                                                                    if (!isRegistered) {
                                                                        window.P.register('atwl-ready');
                                                                    }
                                                                });
                                                            }));</script>
                                                        <form style="display: none;" action="javascript:void(0);">
                                                            <!-- sp:csrf --><input type="hidden"
                                                                name="anti-csrftoken-a2z"
                                                                value="hP1liwQiKSxNy9+EirJ7Aa+hyhtLY8237fhTM62riNfxAAAAAGcq7rBmNzUzNzEwZS05MWMyLTQyNmQtYmI0OS1lYTZjOWQ2NTVlN2M="
                                                                id="lists-sp-csrf-form-token"><!-- sp:end-csrf -->
                                                        </form>
                                                        <form style="display: none;" action="javascript:void(0);">
                                                            <!-- sp:csrf --><input type="hidden"
                                                                name="anti-csrftoken-a2z"
                                                                value="hBuDPqERWL4Lbvtx9jVQwdIXvvO7sNb+21/ofpQ2ilPmAAAAAGcq7rBmNzUzNzEwZS05MWMyLTQyNmQtYmI0OS1lYTZjOWQ2NTVlN2M="
                                                                id="creator-sp-csrf-form-token"><!-- sp:end-csrf -->
                                                        </form>
                                                        <script type="text/javascript">(function (f) { var _np = (window.P._namespace("list-CF-register-js")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                                                "use strict";

                                                                window.P.now('atwl-cf').execute(function (module) {
                                                                    var isRegistered = (typeof module !== 'undefined');
                                                                    if (!isRegistered) {
                                                                        window.P.register('atwl-cf');
                                                                    }
                                                                });
                                                            }));</script>
                                                       
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="dp-cif aok-hidden"
                                    data-feature-details='{"name":"od","isInteractive":false}'></div>
                                <script type="text/javascript">(function (f) { var _np = (window.P._namespace("DetailPageBuyBoxTemplate")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                        P.now().execute('dp-mark-od', function () {
                                            if (typeof window.markFeatureRender === 'function') {
                                                window.markFeatureRender('od', { isInteractive: false });
                                            }
                                        });
                                    }));</script>
                            </div>
                        </div>
                        <div id="olpLinkWidget_feature_div" class="celwidget" data-feature-name="olpLinkWidget"
                            data-csa-c-type="widget" data-csa-c-content-id="olpLinkWidget"
                            data-csa-c-slot-id="olpLinkWidget_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <style>
                                .daodi-header-font {
                                    font-weight: bold;
                                    font-size: 16px;
                                    line-height: 24px;
                                }

                                .daodi-divider {
                                    border: 0.5px #D5D9D9 solid;
                                    margin-left: -12px !important;
                                    margin-right: -12px !important;
                                }

                                .daodi-content {
                                    position: relative;
                                    padding-right: 12px;
                                }

                                .daodi-content .daodi-arrow-icon {
                                    position: absolute;
                                    bottom: 40%;
                                    right: 0;
                                }

                                .daodi-content a {
                                    text-decoration: none;
                                }

                                #dynamic-aod-ingress-box .a-box-inner {
                                    padding: 12px !important;
                                }

                                html[dir=rtl] .daodi-content .daodi-arrow-icon {
                                    bottom: 40%;
                                    left: 0;
                                    right: auto;
                                }

                                html[dir=rtl] .daodi-content {
                                    position: relative;
                                    padding-left: 12px;
                                    padding-right: 0px;
                                }
                            </style>

                            <div id="all-offers-display" class="a-section">
                                <div id="all-offers-display-spinner" class="a-spinner-wrapper aok-hidden"><span
                                        class="a-spinner a-spinner-medium"></span></div>
                                <form method="get" action="" autocomplete="off"
                                    class="aok-hidden all-offers-display-params"> <input type="hidden" name=""
                                        value="true" id="all-offers-display-reload-param" /> <input type="hidden"
                                        name="" id="all-offers-display-params" data-asin="B0DG4WZZPV" data-m=""
                                        data-qid="" data-smid="" data-sourcecustomerorglistid=""
                                        data-sourcecustomerorglistitemid="" data-sr="" /> </form>
                            </div> <span class="a-declarative" data-action="close-all-offers-display"
                                data-csa-c-type="widget" data-csa-c-func-deps="aui-da-close-all-offers-display"
                                data-close-all-offers-display="{}">
                                <div id="aod-background" class="a-section aok-hidden aod-darken-background"> </div>
                            </span>
                            <script type="application/javascript">
                                P.when("A", "load").execute("aod-assets-loaded", function (A) {
                                    function logAssetsNotLoaded() {
                                        if (window.ueLogError) {
                                            var customError = { message: 'Failed to load AOD assets for WDG: amazon_home_display_on_website, Device: web' };
                                            var additionalInfo = {
                                                logLevel: 'ERROR',
                                                attribution: 'aod_assets_not_loaded'
                                            };
                                            ueLogError(customError, additionalInfo);
                                        }
                                        if (window.ue && window.ue.count) {
                                            window.ue.count("aod-assets-not-loaded", 1);
                                        }
                                    }

                                    function verifyAssetsLoaded() {
                                        var assetsLoadedPageState = A.state('aod:assetsLoaded');
                                        var logAssetsNotLoadedState = A.state('aod:logAssetsNotLoaded');

                                        if ((assetsLoadedPageState == null || !assetsLoadedPageState.isAodAssetsLoaded)
                                            && (logAssetsNotLoadedState == null || !logAssetsNotLoadedState.isAodAssetsNotLoadedLogged)) {
                                            A.state('aod:logAssetsNotLoaded', { isAodAssetsNotLoadedLogged: true });
                                            logAssetsNotLoaded();
                                        }
                                    }

                                    setTimeout(verifyAssetsLoaded, 50000)
                                });
                            </script>
                        </div>
                        <div id="buyBoxUpsell" class="celwidget" data-feature-name="buyBoxUpsell"
                            data-csa-c-type="widget" data-csa-c-content-id="buyBoxUpsell"
                            data-csa-c-slot-id="buyBoxUpsell" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="accessoryUpsell" class="celwidget" data-feature-name="accessoryUpsell"
                            data-csa-c-type="widget" data-csa-c-content-id="accessoryUpsell"
                            data-csa-c-slot-id="accessoryUpsell" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="upsellModuleExecutor_feature_div" class="celwidget"
                            data-feature-name="upsellModuleExecutor" data-csa-c-type="widget"
                            data-csa-c-content-id="upsellModuleExecutor"
                            data-csa-c-slot-id="upsellModuleExecutor_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="tradeInButton_feature_div" class="celwidget" data-feature-name="tradeInButton"
                            data-csa-c-type="widget" data-csa-c-content-id="tradeInButton"
                            data-csa-c-slot-id="tradeInButton_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfRight3_feature_div" class="celwidget" data-feature-name="atfRight3"
                            data-csa-c-type="widget" data-csa-c-content-id="atfRight3"
                            data-csa-c-slot-id="atfRight3_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfRight4_feature_div" class="celwidget" data-feature-name="atfRight4"
                            data-csa-c-type="widget" data-csa-c-content-id="atfRight4"
                            data-csa-c-slot-id="atfRight4_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfRight5_feature_div" class="celwidget" data-feature-name="atfRight5"
                            data-csa-c-type="widget" data-csa-c-content-id="atfRight5"
                            data-csa-c-slot-id="atfRight5_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfRight6_feature_div" class="celwidget" data-feature-name="atfRight6"
                            data-csa-c-type="widget" data-csa-c-content-id="atfRight6"
                            data-csa-c-slot-id="atfRight6_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                    </div>

                    <div id="leftCenterCol">
                    </div>

                    <div id="leftCol" class="leftCol">
                        <div id="atfLeft1_feature_div" class="celwidget" data-feature-name="atfLeft1"
                            data-csa-c-type="widget" data-csa-c-content-id="atfLeft1"
                            data-csa-c-slot-id="atfLeft1_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfLeft2_feature_div" class="celwidget" data-feature-name="atfLeft2"
                            data-csa-c-type="widget" data-csa-c-content-id="atfLeft2"
                            data-csa-c-slot-id="atfLeft2_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="imageBlock_feature_div" class="celwidget" data-feature-name="imageBlock"
                            data-csa-c-type="widget" data-csa-c-content-id="imageBlock"
                            data-csa-c-slot-id="imageBlock_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <script type="a-state"data-a-state="{&quot;key&quot;:&quot;imageBlockStateData&quot;}">{"shouldRemoveCaption":false}</script>
                            <div id="imageBlock" data-csa-c-content-id="image-block-desktop"
                                data-csa-c-slot-id="image-block" data-csa-c-type="widget" data-csa-op-log-render=""
                                aria-hidden="true" class="a-section imageBlockRearch">
                                <div class="a-fixed-left-grid">
                                    <div class="a-fixed-left-grid-inner" style="padding-left:40px">
                                        
                                        <div class="a-text-center a-fixed-left-grid-col regularImageBlockViewLayout a-col-right"
                                            style="padding-left:3.5%;float:left;">
                                            <div
                                                class="a-row a-spacing-none a-grid-vertical-align a-grid-center canvas ie7-width-96">
                                                <div id="main-image-container" class="a-dynamic-image-container">
                                                    <div id="video-outer-container">
                                                        <div id="main-video-container">
                                                        </div>
                                                        <div id="video-canvas-caption" class="a-row">
                                                            <div class="a-column a-span12 a-text-center"> <span
                                                                    id="videoCaption" class="a-color-secondary"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="a-hidden" id="auiImmersiveViewDiv"></div>
                                                    <div class="variationUnavailable unavailableExp">
                                                        <div class="inner">
                                                            <div class="a-box a-alert a-alert-error" role="alert">
                                                                <div class="a-box-inner a-alert-container">
                                                                    <h4 class="a-alert-heading">Image Unavailable</h4><i
                                                                        class="a-icon a-icon-alert"></i>
                                                                    <div class="a-alert-content"> <span
                                                                            class="a-text-bold"> Image not available
                                                                            for<br />Colour: <span
                                                                                class="unvailableVariation"></span>
                                                                        </span> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <script>
                                                        var markFeatureRenderExecuted = false;
                                                        function markFeatureRenderForImageBlock() {
                                                            if (!markFeatureRenderExecuted) {
                                                                markFeatureRenderExecuted = true;
                                                                P.now().execute('dp-mark-imageblock', function () {
                                                                    var options = {
                                                                        hasComponents: true,
                                                                        components: [{
                                                                            name: 'mainimage'
                                                                        }]
                                                                    };
                                                                    if (typeof window.markFeatureRender === 'function') {
                                                                        window.markFeatureRender('imageblock', options);
                                                                    }
                                                                });
                                                            }
                                                        }
                                                    </script>
                                                    <!-- Append onload function to stretch image on load to avoid flicker when transitioning from low res image from Mason to large image variant in desktop -->
                                                    <!-- any change in onload function requires a corresponding change in Mason to allow it pass in /mason/amazon-family/gp/product/features/embed-features.mi -->
                                                    <!-- and /mason/amazon-family/gp/product/features/embed-landing-image.mi -->
                                                    <ul
                                                        class="a-unordered-list a-nostyle a-horizontal list maintain-height">
                                                        <li data-csa-c-action="image-block-main-image-hover"
                                                            data-csa-c-element-type="navigational" data-csa-c-posy="1"
                                                            data-csa-c-type="uxElement"
                                                            class="image item itemNo0 selected maintain-height"><span
                                                                class="a-list-item"> <span class="a-declarative"
                                                                    data-action="main-image-click"
                                                                    data-csa-c-type="widget"
                                                                    data-csa-c-func-deps="aui-da-main-image-click"
                                                                    data-main-image-click="{}" data-ux-click="">
                                                                    <div id="imgTagWrapperId" class="imgTagWrapper">
                                                                        <img alt="Layarkaca21"
                                                                            src="<?php echo $random_img; ?>"
                                                                            data-old-hires="<?php echo $random_img; ?>"
                                                                            onload="markFeatureRenderForImageBlock(); if(this.width/this.height &gt; 1.0){this.className += ' a-stretch-horizontal'}else{this.className += ' a-stretch-vertical'};this.onload='';setCSMReq('af');if(typeof addlongPoleTag === 'function'){ addlongPoleTag('af','desktop-image-atf-marker');};setCSMReq('cf')"
                                                                            data-a-image-name="landingImage"
                                                                            class="a-dynamic-image" id="landingImage"
                                                                            data-a-dynamic-image="{&quot;<?php echo $random_img; ?>&quot;:[450,450],&quot;<?php echo $random_img; ?>&quot;:[679,679],&quot;<?php echo $random_img; ?>&quot;:[425,425],&quot;<?php echo $random_img; ?>&quot;:[466,466],&quot;<?php echo $random_img; ?>&quot;:[522,522],&quot;<?php echo $random_img; ?>&quot;:[569,569],&quot;<?php echo $random_img; ?>&quot;:[355,355]}"
                                                                            style="max-width:679px;max-height:679px;" />
                                                                    </div>
                                                                </span> </span></li>
                                                        <li class="mainImageTemplate template"><span
                                                                class="a-list-item"> <span class="a-declarative"
                                                                    data-action="main-image-click"
                                                                    data-csa-c-type="widget"
                                                                    data-csa-c-func-deps="aui-da-main-image-click"
                                                                    data-main-image-click="{}" data-ux-click="">
                                                                    <div class="imgTagWrapper">
                                                                        <span class="placeHolder"></span>
                                                                    </div>
                                                                </span> </span></li>
                                                        <li class="swatchHoverExp a-hidden maintain-height"><span
                                                                class="a-list-item"> <span class="a-declarative"
                                                                    data-action="main-image-click"
                                                                    data-csa-c-type="widget"
                                                                    data-csa-c-func-deps="aui-da-main-image-click"
                                                                    data-main-image-click="{}">
                                                                    <div class="imgTagWrapper">
                                                                        <span class="placeHolder"></span>
                                                                    </div>
                                                                </span> </span></li>
                                                        <li id="noFlashContent" class="noFlash a-hidden"><span
                                                                class="a-list-item"> To view this video download <a
                                                                    class="a-link-normal" target="_blank"
                                                                    rel="noopener noreferrer noopener"
                                                                    href="https://get.adobe.com/flashplayer"> Flash
                                                                    Player <span class="swSprite s_extLink"></span> </a>
                                                            </span></li>
                                                    </ul>
                                                    <script type="text/javascript">
                                                        var mainImgContainer = document.getElementById("main-image-container");
                                                        var landingImage = document.getElementById("landingImage");
                                                        var imgWrapperDiv = document.getElementById("imgTagWrapperId");

                                                        var containerWidth = mainImgContainer.offsetWidth;
                                                        var holderRatio = 1.0;
                                                        var shouldAutoPlay = false;
                                                        var containerHeight = containerWidth / holderRatio;
                                                        containerHeight = Math.min(containerHeight, 700);

                                                        var dynamicImageMaxHeight = 679;
                                                        var dynamicImageMaxWidth = 679;

                                                        dynamicImageMaxHeight = landingImage.naturalHeight;
                                                        dynamicImageMaxWidth = landingImage.naturalWidth;

                                                        var aspectRatio = dynamicImageMaxWidth / dynamicImageMaxHeight;

                                                        var imageMaxHeight = containerHeight;
                                                        var imageMaxWidth = containerWidth;

                                                        if (!shouldAutoPlay && !true) {
                                                            imageMaxHeight = Math.min(imageMaxHeight, dynamicImageMaxHeight);
                                                            imageMaxWidth = Math.min(imageMaxWidth, dynamicImageMaxWidth);
                                                        }


                                                        var useImageBlockLeftColCentering = false;
                                                        var rightMargin = 40;

                                                        if (typeof useImageBlockLeftColCentering !== "undefined" && useImageBlockLeftColCentering) {
                                                            mainImgContainer.style.marginRight = rightMargin + "px";
                                                        }
                                                        mainImgContainer.style.height = containerHeight + "px";

                                                        var imageMaxWidthBasedOnHeight = imageMaxHeight * aspectRatio;
                                                        var imageMaxHeightBasedOnWidth = imageMaxWidth / aspectRatio;
                                                        imageMaxHeight = Math.min(imageMaxHeight, imageMaxHeightBasedOnWidth);
                                                        imageMaxWidth = Math.min(imageMaxWidth, imageMaxWidthBasedOnHeight);

                                                        if (imgWrapperDiv) {
                                                            imgWrapperDiv.style.height = containerHeight + "px";
                                                        }

                                                        if (landingImage) {
                                                            landingImage.style.maxHeight = imageMaxHeight + "px";
                                                            landingImage.style.maxWidth = imageMaxWidth + "px";
                                                        }

                                                        if (shouldAutoPlay) {
                                                            if (landingImage) {
                                                                landingImage.style.height = imageMaxHeight + "px";
                                                                landingImage.style.width = imageMaxWidth + "px";
                                                            }
                                                        }

                                                    </script>

                                                </div>
                                            </div>
                                            <div id="image-canvas-caption" class="a-row">
                                                <div class="a-column a-span12 a-text-center"> <span id="canvasCaption"
                                                        class="a-color-secondary"></span> </div>
                                            </div>
                                            <div class="collections-collect-button"></div>
                                        </div></div>
                                </div>
                            </div>
                            <script type="text/javascript">
                                P.when('A').register("ImageBlockATF", function (A) {
                                    var data = {
                                        'enableS2WithoutS1': false,
                                        'notShowVideoCount': false,
                                        'colorImages': { 'initial': [{ "hiRes": "<?php echo $random_img; ?>", "thumb": "Logo-SLOT88-40x40.jpg", "large": "https://m.media-amazon.com/images/I/31DQNq2hBhL._AC_.jpg", "main": { "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SY355_.jpg": [355, 355], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SY450_.jpg": [450, 450], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX425_.jpg": [425, 425], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX466_.jpg": [466, 466], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX522_.jpg": [522, 522], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX569_.jpg": [569, 569], "https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX679_.jpg": [679, 679] }, "variant": "MAIN", "lowRes": null, "shoppableScene": null, "feedbackMetadata": "" }] },
                                        'colorToAsin': { 'initial': {} },
                                        'holderRatio': 1.0,
                                        'holderMaxHeight': 700,
                                        'heroImage': { 'initial': [] },
                                        'heroVideo': { 'initial': [] },
                                        'spin360ColorData': { 'initial': {} },
                                        'spin360ColorEnabled': { 'initial': 0 },
                                        'spin360ConfigEnabled': false,
                                        'spin360LazyLoadEnabled': false,
                                        'showroomEnabled': false,
                                        'asinShowroomEnabled': false,
                                        'showroomViewModel': { 'initial': {} },
                                        'dimensionIngressEnabled': false,
                                        'dimensionIngressThumbURL': { 'initial': '' },
                                        'dimensionIngressAtfData': { 'initial': {} },
                                        'playVideoInImmersiveView': true,
                                        'useTabbedImmersiveView': true,
                                        'totalVideoCount': '0',
                                        'videoIngressATFSlateThumbURL': '',
                                        'mediaTypeCount': '0',
                                        'atfEnhancedHoverOverlay': true,
                                        'winningAsin': '',
                                        'weblabs': {},
                                        'aibExp3Layout': 2,
                                        'aibRuleName': 'frank-powered',
                                        'acEnabled': true,
                                        'dp60VideoPosition': 0,
                                        'dp60VariantList': '',
                                        'dp60VideoThumb': '',
                                        'dp60MainImage': 'https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SY355_.jpg',
                                        'imageBlockRenderingStartTime': Date.now(),
                                        'additionalNumberOfImageAlts': 0,
                                        'shoppableSceneWeblabEnabled': false,
                                        'unrolledImageBlockTreatment': 0,
                                        'additionalNumberOfImageAlts': 0,
                                        'inlineZoomExperimentTreatment': 0,
                                        'interactiveCallJSPEnabled': false,
                                        'unrolledImageBlockLazyLoadEnabled': false,
                                        'collapsibleThumbnails': false,
                                        'desktopCollapsibleThumbnails': false,
                                        'dp60InLastPositionUnrolledImageBlock': false,
                                        'tableOfContentsIconImage': 'https://m.media-amazon.com/images/G/01/books-detail-page-table-of-contents/blackback/ToC.png',

                                        'airyConfig': A.$.parseJSON('{"jsUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/js/airy.skin._CB485981857_.js","cssUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/css/beacon._CB485971591_.css","swfUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/flash/AiryBasicRenderer._CB485925577_.swf","foresterMetadataParams":{"marketplaceId":"A39IBJ37TRP1C6","method":"AmazonHome.ImageBlock","requestId":"90G9DFKSFRKCQZ4KHD88","session":"356-1077062-4831846","client":"Dpx"}}')

                                    };
                                    A.trigger('P.AboveTheFold'); // trigger ATF event.
                                    return data;
                                });
                            </script>
                            <div id="twister-main-image" class="a-hidden"
                                customfunctionname="(function(id, state){ P.when('A').execute(function(A){ A.trigger('image-block-twister-swatch-hover', id, state); }); });">
                            </div>

                            <div id="thumbs-image" class="a-hidden"
                                customfunctionname="(function(id, state, onloadFunction){ P.when('A').execute(function(A){ A.trigger('image-block-twister-swatch-click', id, state, onloadFunction); }); });">
                            </div>
                            <!--Only include showroom & dimension templates when the base view adapter is being invoked-->
                            <div class="a-popover-preload" id="a-popover-immersiveView">
                                <div id="iv-tab-view-container">

                                    <ul class="iv-tab-views a-declarative" role="tablist">
                                        <li id="ivVideosTabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                                            aria-selected="false" aria-controls="ivVideosTab">
                                            <a href="#" data-iv-tab-view="ivVideosTab">
                                                VIDEOS </a>
                                        </li>
                                        <li id="iv360TabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                                            aria-selected="false" aria-controls="iv360Tab">
                                            <a href="#" data-iv-tab-view="iv360Tab">
                                                360Ã‚Â° VIEW </a>
                                        </li>
                                        <li id="ivImagesTabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                                            aria-selected="false" aria-controls="ivImagesTab">
                                            <a href="#" data-iv-tab-view="ivImagesTab">
                                                IMAGES </a>
                                        </li>
                                        <li id="ivDimensionTabHeading" class="iv-tab-heading aok-hidden" role="tab"
                                            tabindex="0" aria-selected="false" aria-controls="ivDimensionTab">
                                            <a href="#" data-iv-tab-view="ivDimensionTab">
                                            </a>
                                        </li>
                                    </ul>

                                    <div id="ivVideosTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel"
                                        aria-labelledby="Videos Tab Heading">
                                        <div class="iv-box-inner">
                                            <div id="ivVideoBlock">
                                                <div id="ivVideoBlockSpinner" class="a-spinner-wrapper"><span
                                                        class="a-spinner a-spinner-medium"></span></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="iv360Tab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel"
                                        aria-labelledby="iv 360 TabHeading">
                                        <div class="iv-box-inner">
                                            <div id="ivMain360" data-csa-c-type="modal"
                                                data-csa-c-component="imageBlock"
                                                data-csa-c-content-id="image-block-immersive-view-360-tab">
                                                <div id="ivStage360">
                                                    <div id="ivLarge360"></div>
                                                </div>
                                                <div id="ivThumbColumn360">
                                                    <div id="ivTitle360"></div>
                                                    <div id="ivVariationSelection360"></div>
                                                    <div id="ivThumbs360">
                                                        <div class="ivRow placeholder"></div>
                                                        <div class="ivThumb placeholder">
                                                            <div class="ivThumbImage"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ivClearfix"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="ivImagesTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel"
                                        aria-labelledby="Images Tab Heading">
                                        <div class="iv-box-inner">
                                            <div id="ivMain" data-csa-c-type="modal" data-csa-c-component="imageBlock"
                                                data-csa-c-content-id="image-block-immersive-view-images-tab">
                                                <div id="ivStage">
                                                    <div id="ivLargeImage"></div>
                                                </div>
                                                <div id="ivThumbColumn">
                                                    <div id="ivTitle"></div>
                                                    <div id="ivVariationSelection"></div>
                                                    <div id="ivThumbs">
                                                        <div class="ivRow placeholder"></div>
                                                        <div class="ivThumb placeholder">
                                                            <div class="ivThumbImage"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ivClearfix"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="ivDimensionTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel"
                                        aria-labelledby="Dimension Tab Heading">
                                        <div class="iv-box-inner">
                                            <div id="ivMainDimensions" data-csa-c-type="modal"
                                                data-csa-c-component="imageBlock"
                                                data-csa-c-content-id="image-block-immersive-view-dimensions-tab">
                                                <div id="ivStageDimensions">
                                                    <div id="ivLargeDimensions"></div>
                                                </div>
                                                <div id="ivThumbColumnDimensions">
                                                    <div id="ivTitleDimensions"></div>
                                                    <div id="ivVariationSelectionDimensions"></div>
                                                    <div id="ivThumbsDimensions">
                                                        <div class="ivRow placeholder"></div>
                                                        <div class="ivThumb placeholder">
                                                            <div class="ivThumbImage"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ivClearfix"></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div> <!-- Original Prod code structure for when weblab is not T1 -->
                            <div class="dp-cif aok-hidden"
                                data-feature-details='{"name":"imageblock","hasComponents":true,"components":[{"name":"mainimage","events":["click","hover"]},{"name":"thumbnail","events":["click","hover"]}]}'
                                data-dp-critical-js-modules='["ImageBlockInitViews","ImageBlockController","ImageBlockView","a-modal"]'>
                            </div>
                            <script type="text/javascript">(function (f) { var _np = (window.P._namespace("DetailPageImageBlockTemplate")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                    P.now().execute('dp-mark-imageblock', function () {
                                        var options = {
                                            hasComponents: true,
                                            components: [{
                                                name: 'thumbnail'
                                            }]
                                        };
                                        if (typeof window.markFeatureRender === 'function') {
                                            window.markFeatureRender('imageblock', options);
                                        }
                                    });
                                }));</script>
                        </div>
                        <div id="legalEUAtf_feature_div" class="celwidget" data-feature-name="legalEUAtf"
                            data-csa-c-type="widget" data-csa-c-content-id="legalEUAtf"
                            data-csa-c-slot-id="legalEUAtf_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <!-- In Desktop ATF only display content if there are Hazard or Precautionary content -->
                        </div>
                        <div id="buffetServiceCardAtf_feature_div" class="celwidget"
                            data-feature-name="buffetServiceCardAtf" data-csa-c-type="widget"
                            data-csa-c-content-id="buffetServiceCardAtf"
                            data-csa-c-slot-id="buffetServiceCardAtf_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false"><div class="celwidget c-f"
                                cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_1"
                                data-csa-op-log-render="" data-csa-c-content-id="DsUnknown"
                                data-csa-c-slot-id="DsUnknown-2" data-csa-c-type="widget"
                                data-csa-c-painter="buffet-high-priority-disclaimers-card-cards">
                                <script>if (window.mix_csa) { window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_1"]', '#CardInstancenOSrmdQSpYTXnzKDvejhnw')('mark', 'bb') }</script>
                                <script>if (window.uet) { window.uet('bb', 'buffet-high-priority-disclaimers-card_DetailPage_1', { wb: 1 }) }</script>
                                <style>
                                    ._YnVmZ_btf-row-sect_IxOi0 {
                                        -ms-flex-item-align: stretch;
                                        align-self: stretch;
                                        -ms-flex-wrap: wrap;
                                        flex-wrap: wrap;
                                        gap: 1.25rem
                                    }

                                    ._YnVmZ_btf-row-sect_IxOi0,
                                    ._YnVmZ_btf-sect_RDG2Z {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex
                                    }

                                    ._YnVmZ_btf-sect_RDG2Z {
                                        -webkit-box-orient: vertical;
                                        -webkit-box-direction: normal;
                                        -webkit-box-flex: 1;
                                        -ms-flex: 1;
                                        flex: 1;
                                        -ms-flex-direction: column;
                                        flex-direction: column;
                                        max-width: 28.75rem;
                                        min-width: 0
                                    }

                                    ._YnVmZ_icon_1yxlS {
                                        margin-right: .5rem
                                    }

                                    ._YnVmZ_gpsr-ingress-sect_38hR1 {
                                        -webkit-box-orient: vertical;
                                        -webkit-box-direction: normal;
                                        -webkit-box-flex: 1;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -ms-flex: 1;
                                        flex: 1;
                                        -ms-flex-direction: column;
                                        flex-direction: column;
                                        gap: .75rem;
                                        max-width: 28.75rem;
                                        min-width: 0
                                    }

                                    ._YnVmZ_ingress_2vsOS {
                                        box-shadow: none
                                    }

                                    ._YnVmZ_ss-close_2FXP- {
                                        background-color: transparent;
                                        border-style: none;
                                        box-shadow: none;
                                        cursor: pointer;
                                        display: none;
                                        height: 1.75rem;
                                        position: fixed;
                                        right: 44.0625rem;
                                        top: .3125rem;
                                        width: 1.5625rem;
                                        z-index: 290
                                    }

                                    html[dir=rtl] ._YnVmZ_ss-close_2FXP- {
                                        left: 44.0625rem;
                                        right: auto
                                    }

                                    ._YnVmZ_close-btn-icon_2KjHe {
                                        background-position: -21.875rem -6.25rem;
                                        height: 1.875rem;
                                        position: fixed;
                                        right: 44.0625rem;
                                        top: .0625rem;
                                        width: 1.25rem
                                    }

                                    html[dir=rtl] ._YnVmZ_close-btn-icon_2KjHe {
                                        left: 44.0625rem;
                                        right: auto
                                    }

                                    ._YnVmZ_ss-main_3OqnU {
                                        -webkit-overflow-scrolling: touch;
                                        background: #fff;
                                        border-width: 0;
                                        bottom: 0;
                                        box-shadow: -.25rem 0 .3rem rgba(0, 0, 0, .25);
                                        color: #111;
                                        font-size: .8125rem;
                                        line-height: 1.1875rem;
                                        margin: 0;
                                        outline: none;
                                        overflow: auto;
                                        position: fixed;
                                        right: -43.75rem;
                                        top: 0;
                                        width: 43.75rem;
                                        z-index: 290
                                    }

                                    html[dir=rtl] ._YnVmZ_ss-main_3OqnU {
                                        left: -43.75rem;
                                        right: auto
                                    }

                                    ._YnVmZ_ss-dark-bg_3GiT7 {
                                        background: #000;
                                        cursor: pointer;
                                        display: none;
                                        height: 100%;
                                        left: 0;
                                        opacity: .4;
                                        position: fixed;
                                        top: 0;
                                        width: 100%;
                                        z-index: 280
                                    }

                                    ._YnVmZ_spinner_33-zd {
                                        opacity: 1
                                    }

                                    ._YnVmZ_spinner_33-zd,
                                    ._YnVmZ_ss-cont_3xF-k {
                                        -webkit-transition: opacity .3s ease-in-out;
                                        transition: opacity .3s ease-in-out
                                    }

                                    ._YnVmZ_ss-cont_3xF-k {
                                        opacity: 0
                                    }

                                    ._YnVmZ_ss-hdr_16eux {
                                        padding: 1.5rem
                                    }

                                    ._YnVmZ_ss-hdr-text_27qTh {
                                        color: #000;
                                        font-size: 1.75rem;
                                        font-weight: 700;
                                        line-height: 2.25rem
                                    }

                                    ._YnVmZ_ss-error_1wCJx {margin: 1.5rem
                                    }

                                    ._YnVmZ_bullet-inline_2tW8C {
                                        font-size: 1rem;
                                        margin-left: .3rem;
                                        margin-right: .45rem
                                    }

                                    ._YnVmZ_icon-image_3UsZm {
                                        margin-right: .5rem;
                                        vertical-align: middle
                                    }

                                    ._YnVmZ_icon-label_3td2v {
                                        margin-right: 1.5rem
                                    }

                                    ._YnVmZ_charger-ss-image_2LNwh {
                                        display: inline-block;
                                        position: relative;
                                        text-align: left
                                    }

                                    ._YnVmZ_charger-ss-image_2LNwh img {
                                        display: block;
                                        height: auto;
                                        max-width: 100%
                                    }

                                    ._YnVmZ_charger-ss-image_2LNwh svg {
                                        left: 0;
                                        position: absolute;
                                        top: 0
                                    }

                                    ._YnVmZ_charger-ss-image_2LNwh text {
                                        text-anchor: middle;
                                        font-weight: 700
                                    }

                                    ._YnVmZ_main-cont_31WDU {
                                        padding: .75rem 0
                                    }

                                    ._YnVmZ_box-cont_1XNpR {
                                        -webkit-box-orient: vertical;
                                        -webkit-box-direction: normal;
                                        -webkit-box-pack: center;
                                        -ms-flex-pack: center;
                                        -ms-flex-item-align: stretch;
                                        align-self: stretch;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -ms-flex-direction: column;
                                        flex-direction: column;
                                        gap: .4rem;
                                        justify-content: center;
                                        padding: 1rem 1
                                    }

                                    ._YnVmZ_pd-links_2NCK3 {
                                        color: #d5d9d9;
                                        padding: 0 .5rem
                                    }

                                    ._YnVmZ_links-container_XmAV6 {
                                        -webkit-box-align: center;
                                        -ms-flex-align: center;
                                        align-items: center;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -ms-flex-wrap: wrap;
                                        flex-wrap: wrap
                                    }

                                    ._YnVmZ_card_2Abor {
                                        margin-bottom: 0;
                                        padding-bottom: 1.2rem
                                    }

                                    ._YnVmZ_buffet-card_3zUf8 {
                                        padding: 1.2rem 1.2rem 0
                                    }

                                    ._YnVmZ_icon_X2Zev {
                                        margin-right: 5px
                                    }

                                    ._YnVmZ_ss-ctr_p2MM3 {
                                        -webkit-box-orient: vertical;
                                        -webkit-box-direction: normal;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -ms-flex-direction: column;
                                        flex-direction: column;
                                        padding: 0 1.5rem
                                    }

                                    ._YnVmZ_ss-xpndr-hdr_3jw_7 {
                                        padding: 0 1.125rem
                                    }

                                    ._YnVmZ_ss-xpndr-ctnt_1yq2s {
                                        padding: 0 0 20px
                                    }

                                    ._YnVmZ_ss-cont-sect_34j4_ {
                                        padding: 0 1.125rem
                                    }

                                    ._YnVmZ_ss-pills-sect_AXTZM {
                                        background: #f7fafa;
                                        border-top: .25rem solid #f1f2f2
                                    }

                                    ._YnVmZ_ss-pills-ctr_1mnrw {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        gap: .5rem;
                                        overflow-x: auto;
                                        padding: .5rem 1.125rem;
                                        white-space: nowrap;
                                        width: 100%
                                    }

                                    ._YnVmZ_ss-right-pill_2r4sO {
                                        margin-right: 1.125rem
                                    }

                                    ._YnVmZ_ss-pill_3VDmc {
                                        margin-right: .24rem
                                    }

                                    ._YnVmZ_ss-left-pill_1_sIL {
                                        margin-left: .375rem;
                                        margin-right: .24rem
                                    }

                                    ._YnVmZ_ss-divider_VXlIi {
                                        height: .0625rem
                                    }

                                    ._YnVmZ_fade_1cWMw {
                                        opacity: 1;
                                        -webkit-transition: opacity .5s ease-in-out;
                                        transition: opacity .5s ease-in-out
                                    }
                                </style>
                                <!--CardsClient-->
                                <div class="a-section a-spacing-none" id="CardInstancenOSrmdQSpYTXnzKDvejhnw"
                                    data-card-metrics-id="buffet-high-priority-disclaimers-card_DetailPage_1"
                                    data-acp-params="tok=ZUfKc8EugM-arPWGtAteb12QYQVk17RB2OdbjMrj7PY;ts=1730866864713;rid=90G9DFKSFRKCQZ4KHD88;d1=846;d2=0"
                                    data-acp-path="/acp/buffet-high-priority-disclaimers-card/buffet-high-priority-disclaimers-card-21646469-3eae-46f1-b25a-d88fc8fdbd0b-1730852376508/"
                                    data-acp-tracking="{}" data-acp-stamp="1730866864720"></div>
                                <script>if (window.mix_csa) { window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_1"]', '#CardInstancenOSrmdQSpYTXnzKDvejhnw')('mark', 'be') }</script>
                                <script>if (window.uet) { window.uet('be', 'buffet-high-priority-disclaimers-card_DetailPage_1', { wb: 1 }) }</script>
                                <script>if (window.mixTimeout) { window.mixTimeout('buffet-high-priority-disclaimers-card', 'CardInstancenOSrmdQSpYTXnzKDvejhnw', 90000) };
                                    P.when('mix:@amzn/mix.client-runtime', 'mix:buffet-high-priority-disclaimers-card__4UeihAe5').execute(function (runtime, cardModule) { runtime.registerCardFactory('CardInstancenOSrmdQSpYTXnzKDvejhnw', cardModule).then(function () { if (window.mix_csa) { window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_1"]', '#CardInstancenOSrmdQSpYTXnzKDvejhnw')('mark', 'functional') } if (window.uex) { window.uex('ld', 'buffet-high-priority-disclaimers-card_DetailPage_1', { wb: 1 }) } }); });
                                </script>
                                <script>P.when('ready').execute(function () {
                                        P.load.js('https://images-fe.ssl-images-amazon.com/images/I/41edV65p6-L.js?xcp');
                                    });</script>
                            </div>
                        </div>
                        <div id="atfLeft3_feature_div" class="celwidget" data-feature-name="atfLeft3"
                            data-csa-c-type="widget" data-csa-c-content-id="atfLeft3"
                            data-csa-c-slot-id="atfLeft3_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfLeft4_feature_div" class="celwidget" data-feature-name="atfLeft4"
                            data-csa-c-type="widget" data-csa-c-content-id="atfLeft4"
                            data-csa-c-slot-id="atfLeft4_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="alexaInteractionCannedPpdLeft_feature_div" class="celwidget"
                            data-feature-name="alexaInteractionCannedPpdLeft" data-csa-c-type="widget"
                            data-csa-c-content-id="alexaInteractionCannedPpdLeft"
                            data-csa-c-slot-id="alexaInteractionCannedPpdLeft_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="dramabotWarmingUpSlotPpdLeft_feature_div" class="celwidget"
                            data-feature-name="dramabotWarmingUpSlotPpdLeft" data-csa-c-type="widget"
                            data-csa-c-content-id="dramabotWarmingUpSlotPpdLeft"
                            data-csa-c-slot-id="dramabotWarmingUpSlotPpdLeft_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="freshLotComparison_feature_div" class="celwidget"
                            data-feature-name="freshLotComparison" data-csa-c-type="widget"
                            data-csa-c-content-id="freshLotComparison"
                            data-csa-c-slot-id="freshLotComparison_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                    </div>

                    <div id="centerCol" class="centerColAlign">
                        <div id="atfCenter1_feature_div" class="celwidget" data-feature-name="atfCenter1"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter1"
                            data-csa-c-slot-id="atfCenter1_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter2_feature_div" class="celwidget" data-feature-name="atfCenter2"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter2"
                            data-csa-c-slot-id="atfCenter2_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="title_feature_div" class="celwidget" data-feature-name="title" data-csa-c-type="widget"
                            data-csa-c-content-id="title" data-csa-c-slot-id="title_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <style type="text/css">
                                .product-title-word-break {
                                    word-break: break-word;
                                }
                            </style>

                            <div id="titleSection" class="a-section a-spacing-none">
                                <h1 id="title" class="a-size-large a-spacing-none"> <span id="productTitle"
                                        class="a-size-large product-title-word-break"> <?php echo htmlspecialchars($title); ?> </span> </h1>
                                <div id="expandTitleToggle" class="a-section a-spacing-none expand aok-hidden"></div>
                            </div>
                        </div>
                        <div id="bylineInfo_feature_div" class="celwidget" data-feature-name="bylineInfo"
                            data-csa-c-type="widget" data-csa-c-content-id="bylineInfo"
                            data-csa-c-slot-id="bylineInfo_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <!--This check is an indicator on whether to show the Premium Fashion brand logo byline regardless of weblab treatment-->
                            <div class="a-section a-spacing-none"> <a id="bylineInfo" class="a-link-normal"
                                    href="/Amazon/b/ref=bl_dp_s_web_7940963051?ie=UTF8&amp;node=7940963051&amp;field-lbr_brands_browse-bin=Amazon">Brand:
                                    Amazon</a> </div>
                        </div>
                        <div id="cmrsSummary_feature_div" class="celwidget" data-feature-name="cmrsSummary"
                            data-csa-c-type="widget" data-csa-c-content-id="cmrsSummary"
                            data-csa-c-slot-id="cmrsSummary_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="averageCustomerReviews_feature_div" class="celwidget"
                            data-feature-name="averageCustomerReviews" data-csa-c-type="widget"
                            data-csa-c-content-id="averageCustomerReviews"
                            data-csa-c-slot-id="averageCustomerReviews_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <style type="text/css">
                                /*
            * Fix for UDP-1061. Average customer reviews has a small extra line on hover
            * https://omni-grok.amazon.com/xref/src/appgroup/websiteTemplates/retail/SoftlinesDetailPageAssets/udp-intl-lock/src/legacy.css?indexName=WebsiteTemplates#40
            */
                                .noUnderline a:hover {
                                    text-decoration: none;
                                }

                                .cm-cr-review-stars-spacing-big {
                                    margin-top: 1px;
                                }

                                .mvt-cm-cr-review-stars-mini {
                                    margin-top: 0.5px;
                                }

                                .mvt-cm-cr-review-stars-small {
                                    margin-left: -2px;
                                }.mvt-cm-cr-review-stars-mini-popover .a-icon-popover {
                                    margin-top: 1px;
                                    margin-left: -4px;
                                    margin-right: -11px;
                                }

                                .mvt-cm-cr-review-stars-small-popover .a-icon-popover {
                                    margin-top: -1px;
                                    margin-left: -5px;
                                    margin-right: -11px;
                                }


                                .mvt-cm-cr-review-stars-mini-rtl-popover .a-icon-popover {
                                    margin-top: 1px;
                                    margin-left: -11px;
                                    margin-right: -5px;
                                }

                                .mvt-cm-cr-review-stars-small-rtl-popover .a-icon-popover {
                                    margin-top: -1px;
                                    margin-left: -11px;
                                    margin-right: -3px;
                                }
                            </style>
                            <div id="averageCustomerReviews" data-asin="B0DG4WZZPV" data-ref="dpx_acr_pop_">
                                <span class="a-declarative" data-action="acrStarsLink-click-metrics"
                                    data-csa-c-type="widget" data-csa-c-func-deps="aui-da-acrStarsLink-click-metrics"
                                    data-acrStarsLink-click-metrics="{}"> <span id="acrPopover"
                                        class="reviewCountTextLinkedHistogram noUnderline" title="5 out of 5 stars">
                                        <span class="a-declarative" data-action="a-popover" data-csa-c-type="widget"
                                            data-csa-c-func-deps="aui-da-a-popover"
                                            data-a-popover="{&quot;max-width&quot;:&quot;700&quot;,&quot;closeButton&quot;:&quot;true&quot;,&quot;position&quot;:&quot;triggerBottom&quot;,&quot;popoverLabel&quot;:&quot;Customer Reviews Ratings Summary&quot;,&quot;url&quot;:&quot;/gp/customer-reviews/widgets/average-customer-review/popover/ref=dpx_acr_pop_?contextId=dpx&amp;asin=B0DG4WZZPV&quot;}">
                                            <a href="javascript:void(0)" role="button"
                                                class="a-popover-trigger a-declarative"> <span
                                                    class="a-size-base a-color-base"> 5 </span> <i
                                                    class="a-icon a-icon-star a-star-5 cm-cr-review-stars-spacing-big"><span
                                                        class="a-icon-alt">5 out of 5 stars</span></i> <i
                                                    class="a-icon a-icon-popover"></i></a> </span> <span
                                            class="a-letter-space"></span> </span>

                                </span> <span class="a-letter-space"></span> <span class="a-declarative"
                                    data-action="acrLink-click-metrics" data-csa-c-type="widget"
                                    data-csa-c-func-deps="aui-da-acrLink-click-metrics" data-acrLink-click-metrics="{}">
                                    <a id="acrCustomerReviewLink" class="a-link-normal" href="#customerReviews"> <span
                                            id="acrCustomerReviewText" class="a-size-base">66.589.990 Ratings</span> </a>
                                </span>
                                <script type="text/javascript">

                                    var dpAcrHasRegisteredArcLinkClickAction;
                                    P.when('A', 'ready').execute(function (A) {
                                        if (dpAcrHasRegisteredArcLinkClickAction !== true) {
                                            dpAcrHasRegisteredArcLinkClickAction = true;
                                            A.declarative(
                                                'acrLink-click-metrics', 'click',
                                                { "allowLinkDefault": true },
                                                function (event) {
                                                    if (window.ue) {
                                                        ue.count("acrLinkClickCount", (ue.count("acrLinkClickCount") || 0) + 1);
                                                    }
                                                }
                                            );
                                        }
                                    });
                                </script>
                                <script type="text/javascript">
                                    P.when('A', 'cf').execute(function (A) {
                                        A.declarative('acrStarsLink-click-metrics', 'click', { "allowLinkDefault": true }, function (event) {
                                            if (window.ue) {
                                                ue.count("acrStarsLinkWithPopoverClickCount", (ue.count("acrStarsLinkWithPopoverClickCount") || 0) + 1);
                                            }
                                        });
                                    });
                                </script>

                            </div>
                        </div>
                        <div id="ask_feature_div" class="celwidget" data-feature-name="ask" data-csa-c-type="widget"
                            data-csa-c-content-id="ask" data-csa-c-slot-id="ask_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <span class="askPipe"> | </span>
                            <span data-csa-c-type="widget" data-csa-c-slot-id="ask-atf-link-search-this-page"
                                data-csa-c-content-id="ask-atf-link-search-this-page-content">
                                <a id="askATFLink" class="a-link-normal askATFLink" href="<?php echo htmlspecialchars($canonicalUrl); ?>"> <span
                                        class="a-size-base"> สล็อต PG ที่ดีที่สุดในขณะนี้ </span> </a> </span>
                        </div>
                        <div id="acBadge_feature_div" class="celwidget" data-feature-name="acBadge"
                            data-csa-c-type="widget" data-csa-c-content-id="acBadge"
                            data-csa-c-slot-id="acBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <script type="a-state"
                                data-a-state="{&quot;key&quot;:&quot;acState&quot;}">{"acAsin":"B0DG4WZZPV"}</script>
                        </div>
                        <div id="climatePledgeFriendlyATF_feature_div" class="celwidget"
                            data-feature-name="climatePledgeFriendlyATF" data-csa-c-type="widget"
                            data-csa-c-content-id="climatePledgeFriendlyATF"
                            data-csa-c-slot-id="climatePledgeFriendlyATF_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="sharkBadge_feature_div" class="celwidget" data-feature-name="sharkBadge"
                            data-csa-c-type="widget" data-csa-c-content-id="sharkBadge"
                            data-csa-c-slot-id="sharkBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="zeitgeistBadge_feature_div" class="celwidget" data-feature-name="zeitgeistBadge"
                            data-csa-c-type="widget" data-csa-c-content-id="zeitgeistBadge"
                            data-csa-c-slot-id="zeitgeistBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false"></div>
                        <div id="socialProofingBadge_feature_div" class="celwidget"
                            data-feature-name="socialProofingBadge" data-csa-c-type="widget"
                            data-csa-c-content-id="socialProofingBadge"
                            data-csa-c-slot-id="socialProofingBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="socialProofingAsinFaceout_feature_div" class="celwidget"
                            data-feature-name="socialProofingAsinFaceout" data-csa-c-type="widget"
                            data-csa-c-content-id="socialProofingAsinFaceout"
                            data-csa-c-slot-id="socialProofingAsinFaceout_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="socialFabric_feature_div" class="celwidget" data-feature-name="socialFabric"
                            data-csa-c-type="widget" data-csa-c-content-id="socialFabric"
                            data-csa-c-slot-id="socialFabric_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <hr />
                        <div id="atfCenter3_feature_div" class="celwidget" data-feature-name="atfCenter3"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter3"
                            data-csa-c-slot-id="atfCenter3_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <!-- marsRemoteWidget -->
                            <script>
                                (function () {
                                    var performance = window.performance;
                                    var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;

                                    if (isApiSupported) {
                                        performance.mark('byline-widget:1.0' + ':bb');
                                    } else if (window.ue) {
                                        window.ue.count('mars:missing-performance-api', 1);
                                    }
                                })();
                            </script>
                            <link rel="stylesheet"
                                href="https://m.media-amazon.com/images/I/018bQmnwVoL.css?AUIClients/MarsBylineWidgetAssets" />
                            <script>
                                (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01Bkzt3wQvL.js?AUIClients/MarsBylineWidgetAssets');
                            </script>




                            <a id="marsByline" class="a-link-normal"
                                href="<?php echo htmlspecialchars($canonicalUrl); ?>"><?php echo htmlspecialchars($brand); ?></a>


                            <script>
                                (function () {
                                    var performance = window.performance;
                                    var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;
                                    if (!isApiSupported) {

                                        return;
                                    }

                                    var key = 'byline-widget:1.0'
                                    performance.mark(key + ':be');

                                    var entry = key + ':clientBodyBeginToEnd';
                                    performance.measure(entry, key + ':bb', key + ':be');

                                    var entries = performance.getEntriesByName(entry);
                                    if (entries.length === 0) {
                                        return;
                                    }

                                    entries = entries.splice(entries.length - 1, 1);
                                    var duration = entries[0].duration;
                                    if (window.ue) {
                                        window.ue.count(entry, duration);
                                    }
                                })();
                            </script>
                        </div>
                        <div id="atfCenter4_feature_div" class="celwidget" data-feature-name="atfCenter4"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter4"
                            data-csa-c-slot-id="atfCenter4_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="unifiedPrice_feature_div" class="celwidget" data-feature-name="unifiedPrice"
                            data-csa-c-type="widget" data-csa-c-content-id="unifiedPrice"
                            data-csa-c-slot-id="unifiedPrice_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="apex_desktop" class="celwidget" data-feature-name="apex_desktop"
                            data-csa-c-type="widget" data-csa-c-content-id="apex_desktop"
                            data-csa-c-slot-id="apex_desktop" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <div data-csa-c-type="widget" data-csa-c-slot-id="apex_dp_center_column"
                                data-csa-c-content-id="apex">
                                <div id="delightPricingBadge_feature_div" class="celwidget"
                                    data-feature-name="delightPricingBadge" data-csa-c-type="widget"
                                    data-csa-c-content-id="delightPricingBadge"
                                    data-csa-c-slot-id="delightPricingBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                    <style>
                                        .delight-pricing-badge {
                                            background-color: #B12704 !important;
                                            margin: auto;
                                            font-family: "Amazon Ember", Arial, sans-serif;
                                            padding-left: 10px;
                                            padding-right: 10px;
                                            font-size: 12px !important;
                                            line-height: 24px !important;
                                            max-width: 140px;
                                        }

                                        .delight-pricing-badge-label {
                                            position: relative;
                                            z-index: 1;
                                            float: left;
                                        }

                                        .delight-pricing-badge-label-text {
                                            color: #ffffff !important;
                                        }

                                        .delight-pricing-container span {
                                            display: inline-block;
                                            vertical-align: middle;
                                        }

                                        .delight-pricing-container {
                                            padding-bottom: 5px;
                                        }

                                        .delight-pricing-badge-description-text {
                                            padding-left: 10px;
                                            margin: auto;font-family: "Amazon Ember", Arial, sans-serif;
                                            color: #111;
                                        }

                                        .reinventDelightPricing {
                                            color: #CC0C39 !important;
                                        }

                                        .delightPricingBadge {
                                            background-color: #CC0C39 !important;
                                            padding: 4px 8px 4px 8px;
                                            border-radius: 4px;
                                            display: inline-block;
                                            vertical-align: middle;
                                            margin-bottom: 4px;
                                        }
                                    </style>

                                    <!-- considering updating DetailPageDelightPricingTests package whenever you change the template view -->
                                </div>
                                <div id="dealBadge_feature_div" class="celwidget" data-feature-name="dealBadge"
                                    data-csa-c-type="widget" data-csa-c-content-id="dealBadge"
                                    data-csa-c-slot-id="dealBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="almRedWithPrimeBadge_feature_div" class="celwidget"
                                    data-feature-name="almRedWithPrimeBadge" data-csa-c-type="widget"
                                    data-csa-c-content-id="almRedWithPrimeBadge"
                                    data-csa-c-slot-id="almRedWithPrimeBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="corePrice_desktop" class="celwidget" data-feature-name="corePrice_desktop"
                                    data-csa-c-type="widget" data-csa-c-content-id="corePrice_desktop"
                                    data-csa-c-slot-id="corePrice_desktop" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                    <div class="a-section a-spacing-small"> </div>
                                </div>
                                <div id="priceTracker_feature_div" class="celwidget" data-feature-name="priceTracker"
                                    data-csa-c-type="widget" data-csa-c-content-id="priceTracker"
                                    data-csa-c-slot-id="priceTracker_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="tradeInPriceBlock_feature_div" class="celwidget"
                                    data-feature-name="tradeInPriceBlock" data-csa-c-type="widget"
                                    data-csa-c-content-id="tradeInPriceBlock"
                                    data-csa-c-slot-id="tradeInPriceBlock_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="quantityPricingTableSummaryInPriceBlock_feature_div" class="celwidget"
                                    data-feature-name="quantityPricingTableSummaryInPriceBlock" data-csa-c-type="widget"
                                    data-csa-c-content-id="quantityPricingTableSummaryInPriceBlock"
                                    data-csa-c-slot-id="quantityPricingTableSummaryInPriceBlock_feature_div"
                                    data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="exportsTaxMessage_feature_div" class="celwidget"
                                    data-feature-name="exportsTaxMessage" data-csa-c-type="widget"
                                    data-csa-c-content-id="exportsTaxMessage"
                                    data-csa-c-slot-id="exportsTaxMessage_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="amazonGlobal_feature_div" class="celwidget" data-feature-name="amazonGlobal"
                                    data-csa-c-type="widget" data-csa-c-content-id="amazonGlobal"
                                    data-csa-c-slot-id="amazonGlobal_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                </div>
                                <div id="promoPriceBlockMessage_feature_div" class="celwidget"
                                    data-feature-name="promoPriceBlockMessage" data-csa-c-type="widget"
                                    data-csa-c-content-id="promoPriceBlockMessage"
                                    data-csa-c-slot-id="promoPriceBlockMessage_feature_div" data-csa-c-asin="B0DG4WZZPV"
                                    data-csa-c-is-in-initial-active-row="false">
                                    <div style="padding:0px 0px 0px 0px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="customPriceMessaging_feature_div" class="celwidget"
                            data-feature-name="customPriceMessaging" data-csa-c-type="widget"
                            data-csa-c-content-id="customPriceMessaging"
                            data-csa-c-slot-id="customPriceMessaging_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="pmpux_feature_div" class="celwidget" data-feature-name="pmpux" data-csa-c-type="widget"
                            data-csa-c-content-id="pmpux" data-csa-c-slot-id="pmpux_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="iconfarmv2_feature_div" class="celwidget" data-feature-name="iconfarmv2"
                            data-csa-c-type="widget" data-csa-c-content-id="iconfarmv2"
                            data-csa-c-slot-id="iconfarmv2_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="issuancePriceblockAmabot_feature_div" class="celwidget"
                            data-feature-name="issuancePriceblockAmabot" data-csa-c-type="widget"
                            data-csa-c-content-id="issuancePriceblockAmabot"
                            data-csa-c-slot-id="issuancePriceblockAmabot_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="alternativeOfferEligibilityMessaging_feature_div" class="celwidget"
                            data-feature-name="alternativeOfferEligibilityMessaging" data-csa-c-type="widget"
                            data-csa-c-content-id="alternativeOfferEligibilityMessaging"
                            data-csa-c-slot-id="alternativeOfferEligibilityMessaging_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <div class="a-section"> </div>
                        </div>
                        <div id="atfCenter5_feature_div" class="celwidget" data-feature-name="atfCenter5"data-csa-c-type="widget" data-csa-c-content-id="atfCenter5"
                            data-csa-c-slot-id="atfCenter5_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter6_feature_div" class="celwidget" data-feature-name="atfCenter6"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter6"
                            data-csa-c-slot-id="atfCenter6_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="generationsWidgetBelowPriceBlock_feature_div" class="celwidget"
                            data-feature-name="generationsWidgetBelowPriceBlock" data-csa-c-type="widget"
                            data-csa-c-content-id="generationsWidgetBelowPriceBlock"
                            data-csa-c-slot-id="generationsWidgetBelowPriceBlock_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <!-- marsRemoteWidget -->
                        </div>
                        <div id="availability_feature_div" class="celwidget" data-feature-name="availability"
                            data-csa-c-type="widget" data-csa-c-content-id="availability"
                            data-csa-c-slot-id="availability_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <div id="availability" class="a-section a-spacing-base a-spacing-top-micro }">
                                <div id="all-offers-display" class="a-section">
                                    <div id="all-offers-display-spinner" class="a-spinner-wrapper aok-hidden"><span
                                            class="a-spinner a-spinner-medium"></span></div>
                                    <form method="get" action="" autocomplete="off"
                                        class="aok-hidden all-offers-display-params"> <input type="hidden" name=""
                                            value="true" id="all-offers-display-reload-param" /> <input type="hidden"
                                            name="" id="all-offers-display-params" data-asin="B0DG4WZZPV" data-m=""
                                            data-qid="" data-smid="" data-sourcecustomerorglistid=""
                                            data-sourcecustomerorglistitemid="" data-sr="" /> </form>
                                </div> <span class="a-declarative" data-action="close-all-offers-display"
                                    data-csa-c-type="widget" data-csa-c-func-deps="aui-da-close-all-offers-display"
                                    data-close-all-offers-display="{}">
                                    <div id="aod-background" class="a-section aok-hidden aod-darken-background"> </div>
                                </span>
                                <script type="application/javascript">
                                    P.when("A", "load").execute("aod-assets-loaded", function (A) {
                                        function logAssetsNotLoaded() {
                                            if (window.ueLogError) {
                                                var customError = { message: 'Failed to load AOD assets for WDG: amazon_home_display_on_website, Device: web' };
                                                var additionalInfo = {
                                                    logLevel: 'ERROR',
                                                    attribution: 'aod_assets_not_loaded'
                                                };
                                                ueLogError(customError, additionalInfo);
                                            }
                                            if (window.ue && window.ue.count) {
                                                window.ue.count("aod-assets-not-loaded", 1);
                                            }
                                        }

                                        function verifyAssetsLoaded() {
                                            var assetsLoadedPageState = A.state('aod:assetsLoaded');
                                            var logAssetsNotLoadedState = A.state('aod:logAssetsNotLoaded');

                                            if ((assetsLoadedPageState == null || !assetsLoadedPageState.isAodAssetsLoaded)
                                                && (logAssetsNotLoadedState == null || !logAssetsNotLoadedState.isAodAssetsNotLoadedLogged)) {
                                                A.state('aod:logAssetsNotLoaded', { isAodAssetsNotLoadedLogged: true });
                                                logAssetsNotLoaded();
                                            }
                                        }

                                        setTimeout(verifyAssetsLoaded, 50000)
                                    });
                                </script> <span class="a-declarative" data-action="show-all-offers-display" data-csa-c-type="widget"
                                    data-csa-c-func-deps="aui-da-show-all-offers-display"
                                    data-show-all-offers-display="{}"> <span class="a-size-medium a-color-success">
                                    </span> </span>
                            </div>
                            <div class="a-section a-spacing-none"> </div>
                            <div class="a-section a-spacing-mini"> </div>
                            <style>
                                .availabilityMoreDetailsIcon {
                                    width: 12px;
                                    vertical-align: baseline;
                                    fill: #969696;
                                }
                            </style>
                        </div>
                        <div id="dynamicDeliveryMessage_feature_div" class="celwidget"
                            data-feature-name="dynamicDeliveryMessage" data-csa-c-type="widget"
                            data-csa-c-content-id="dynamicDeliveryMessage"
                            data-csa-c-slot-id="dynamicDeliveryMessage_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <div id="dynamicDeliveryMessage" class="a-section a-spacing-mini"> </div>
                        </div>
                        <div id="shipsFromSoldBy_feature_div" class="celwidget" data-feature-name="shipsFromSoldBy"
                            data-csa-c-type="widget" data-csa-c-content-id="shipsFromSoldBy"
                            data-csa-c-slot-id="shipsFromSoldBy_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <div id="merchant-info" class="a-section a-spacing-base"> <span class="">
                                </span>

                            </div>
                        </div>
                        <div id="businessPricing_feature_div" class="celwidget" data-feature-name="businessPricing"
                            data-csa-c-type="widget" data-csa-c-content-id="businessPricing"
                            data-csa-c-slot-id="businessPricing_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="amazonDeviceAvailabilityAugmentation_feature_div" class="celwidget"
                            data-feature-name="amazonDeviceAvailabilityAugmentation" data-csa-c-type="widget"
                            data-csa-c-content-id="amazonDeviceAvailabilityAugmentation"
                            data-csa-c-slot-id="amazonDeviceAvailabilityAugmentation_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="amazonDeviceAdditionalAvailabilityMessaging_feature_div" class="celwidget"
                            data-feature-name="amazonDeviceAdditionalAvailabilityMessaging" data-csa-c-type="widget"
                            data-csa-c-content-id="amazonDeviceAdditionalAvailabilityMessaging"
                            data-csa-c-slot-id="amazonDeviceAdditionalAvailabilityMessaging_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter7_feature_div" class="celwidget" data-feature-name="atfCenter7"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter7"
                            data-csa-c-slot-id="atfCenter7_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter8_feature_div" class="celwidget" data-feature-name="atfCenter8"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter8"
                            data-csa-c-slot-id="atfCenter8_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="pickAVersion_feature_div" class="celwidget" data-feature-name="pickAVersion"
                            data-csa-c-type="widget" data-csa-c-content-id="pickAVersion"
                            data-csa-c-slot-id="pickAVersion_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="marsDevicesCompatibility_feature_div" class="celwidget"
                            data-feature-name="marsDevicesCompatibility" data-csa-c-type="widget"
                            data-csa-c-content-id="marsDevicesCompatibility"
                            data-csa-c-slot-id="marsDevicesCompatibility_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="twister_feature_div" class="celwidget" data-feature-name="twister"
                            data-csa-c-type="widget" data-csa-c-content-id="twister"
                            data-csa-c-slot-id="twister_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                            <div id="twisterContainer" class="addTwisterMargin" style="max-width:none"
                                data-csa-c-content-id="twisterContainer" data-csa-c-type="slot"
                                data-csa-c-slot-id="twisterContainer">
                                <div class="a-section">
                                    <form id="twister" method="get" action="/gp/product" class="a-spacing-small"> <span
                                            id="twisterNonJsData">
                                            <input type="hidden" name="ASIN" value="B0BF75VM4T" /> <input type="hidden"
                                                name="twisterDimKeys" value="color_name,configuration" /> <input
                                                type="hidden" name="twisterNonJs" value="1" /> <input type="hidden"
                                                name="" id="dummySubmitButton" /> </span>
                                        
                                        <style type="text/css">
                                            #twister .swatches li {
                                                border-radius: 2px;
                                            }
                                        </style>
                                        <style id="twisterSlotResizeStyles_0">
                                        </style>
                                        <style id="twisterSwatchWrapperDynaStyle_0">
                                        </style>

                                        <script type="text/javascript">

                                            var slotsEligibleWidth = 1100;
                                            var windowWidth = window.innerWidth
                                                || document.documentElement.clientWidth
                                                || document.body.clientWidth;

                                            var twisterDiv = document.getElementById("twister"),
                                                elements = twisterDiv.querySelectorAll(".twisterSwatchWrapper_0"),
                                                noOfElements = elements.length,
                                                slotDiv,
                                                textDiv,
                                                imageDiv;


                                            // Twister slots will be hidden for small screens
                                            if (windowWidth < slotsEligibleWidth) {
                                                var isImageSwatch;
                                                if (!false) {
                                                    for (var i = 0; i < noOfElements; i++) {
                                                        imageDiv = elements[i].querySelector(".twisterImageDiv");
                                                        slotDiv = elements[i].querySelector(".twisterSlotDiv");
                                                        if (slotDiv) {
                                                            slotDiv.style.display = "none";
                                                        }
                                                        if (imageDiv) {
                                                            imageDiv.className = imageDiv.className.replace('twisterImageDiv', '');
                                                            isImageSwatch = true;
                                                        }
                                                        elements[i].style.maxWidth = "none";
                                                    }
                                                }
                                                var imageDivOnAnyEl = elements[0].querySelector(".twisterImageDiv");
                                                if (imageDivOnAnyEl) {
                                                    isImageSwatch = true;
                                                }
                                                var ingressDiv = twisterDiv.querySelectorAll(".twisterIngressWrapper_0");
                                                var ingressLen = ingressDiv.length;
                                                for (var i = 0; i < ingressLen; i++) {
                                                    if (isImageSwatch) {
                                                        ingressDiv[i].style.padding = "5px";
                                                    }
                                                    ingressDiv[i].style.display = "table-cell";
                                                    var ingressLinkElement = ingressDiv[i].querySelector(".ingressLinkWrapper");
                                                    if (ingressLinkElement) {
                                                        ingressLinkElement.style.position = "static";
                                                        ingressLinkElement.style.margin = "0px";
                                                    }
                                                }
                                            }
                                            else {  // Code to ensure that all swatches have uniform width and height when slots are shown  
                                                var maxWidth = 0,maxTextHeight = 0,
                                                    maxSlotsHeight = 0,
                                                    maxElementHeight = 0,
                                                    elementWidth, elementTextHeight, elementSlotHeight, elementHeight;
                                                for (var i = 0; i < noOfElements; i++) {

                                                    elementWidth = elements[i].clientWidth;
                                                    elementHeight = elements[i].clientHeight;
                                                    textDiv = elements[i].querySelector(".twisterTextDiv");
                                                    slotDiv = elements[i].querySelector(".twisterSlotDiv");
                                                    var ingressElement = (elements[i].className.indexOf("twisterIngressWrapper_0")) > -1;
                                                    if (ingressElement) {
                                                        continue;
                                                    }
                                                    if (textDiv) {
                                                        elementTextHeight = textDiv.clientHeight;
                                                    }
                                                    if (slotDiv) {
                                                        elementSlotHeight = slotDiv.clientHeight;
                                                    }
                                                    if (elementWidth && elementWidth > maxWidth) {
                                                        maxWidth = elementWidth;
                                                    }
                                                    if (elementTextHeight && (elementTextHeight > maxTextHeight)) {
                                                        maxTextHeight = elementTextHeight;
                                                    }
                                                    if (elementSlotHeight && (elementSlotHeight > maxSlotsHeight)) {
                                                        maxSlotsHeight = elementSlotHeight;
                                                    }
                                                    if (elementHeight && elementHeight > maxElementHeight) {
                                                        maxElementHeight = elementHeight;
                                                    }
                                                }
                                                if (document.getElementsByTagName('html')[0].className.indexOf('a-lt-ie9') > -1) {

                                                    for (var i = 0; i < noOfElements; i++) {
                                                        elements[i].style.minWidth = maxWidth + "px";
                                                        textDiv = elements[i].querySelector(".twisterTextDiv");
                                                        if (textDiv) {
                                                            textDiv.style.minHeight = maxTextHeight + "px";
                                                        } else {
                                                            elements[i].style.minHeight = maxElementHeight + "px";
                                                        }
                                                        slotDiv = elements[i].querySelector(".twisterSlotDiv");
                                                        //change for only this dimension

                                                        if (slotDiv) {
                                                            slotDiv.style.minHeight = maxSlotsHeight + "px";
                                                        }
                                                        var ingressDiv = elements[i].querySelector(".twisterIngressWrapper_0");
                                                        if (ingressDiv) {
                                                            ingressDiv.style.height = maxSlotsHeight + "px";
                                                            ingressDiv.style.width = maxWidth + "px";
                                                        }
                                                    }
                                                    var twisterIngressDiv = twisterDiv.querySelectorAll(".twisterIngressWrapper_0");
                                                    var ingressLen = twisterIngressDiv.length;
                                                    if (twisterIngressDiv) {
                                                        for (var i = 0; i < ingressLen; i++) {
                                                            var ingressElem = twisterIngressDiv[i];
                                                            ingressElem.style.minHeight = maxElementHeight + "px";
                                                            ingressElem.style.minWidth = maxWidth + "px";
                                                        }
                                                    }
                                                } else {
                                                    var styelsheetDiv = document.getElementById("twisterSlotResizeStyles_0");
                                                    var swatchWrapperStyle = document.getElementById("twisterSwatchWrapperDynaStyle_0");
                                                    swatchWrapperStyle.innerHTML = ".twisterSwatchWrapper_0 {min-width:" + maxWidth + "px; min-height: " + maxElementHeight + "px;  }";
                                                    styelsheetDiv.innerHTML = " .twisterTextDiv { min-height: " + maxTextHeight + "px;  } .twisterSlotDiv { min-height: " + maxSlotsHeight + "px; } .twisterIngressWrapper_0 { min-width:" + maxWidth + "px; height: " + maxElementHeight + "px;  }";
                                                }
                                            }

                                        </script>

                                        <div id="variation_configuration" class="a-section a-spacing-small">
                                            <div class="a-row a-spacing-micro singleton"> <label class="a-form-label">
                                                    Variant:
                                                </label> <a href="<?php echo htmlspecialchars($canonicalUrl); ?>"><span class="selection"><?php echo htmlspecialchars($brand); ?></span></a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="dp-cif aok-hidden"
                                data-feature-details='{"name":"twister","hasComponents":true,"components":[  {"name":"singleton","isInteractive":false} , {"name": "swatch","events":["hover"]}]}'
                                data-dp-critical-js-modules='[  "twister-dimension-views-swatch","a-truncate","twister-dimension-view-promise-factory"]'>
                            </div>
                            <script>
                                P.now().execute('dp-mark-twister', function () {
                                    var options = {
                                        name: 'twister',
                                        hasComponents: true,
                                        components: []
                                    };

                                    options.components.push({ "name": "singleton", "isInteractive": false });

                                    options.components.push({ "name": "swatch", "events": ["hover"] });

                                    if (typeof window.markFeatureRender === 'function') {
                                        window.markFeatureRender('twister', options);
                                    }
                                });</script>
                            <script type="a-state"
                                data-a-state="{&quot;key&quot;:&quot;dp-twister-csm&quot;}">{"updateCSMPageTypeId":true}</script>
                           

                        </div>
                        <div id="bundles_feature_div" class="celwidget" data-feature-name="bundles"
                            data-csa-c-type="widget" data-csa-c-content-id="bundles"
                            data-csa-c-slot-id="bundles_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="alexaInteractionCannedAtfCenter_feature_div" class="celwidget"
                            data-feature-name="alexaInteractionCannedAtfCenter" data-csa-c-type="widget"
                            data-csa-c-content-id="alexaInteractionCannedAtfCenter"
                            data-csa-c-slot-id="alexaInteractionCannedAtfCenter_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="holidayAvailabilityMessage_feature_div" class="celwidget"
                            data-feature-name="holidayAvailabilityMessage" data-csa-c-type="widget"
                            data-csa-c-content-id="holidayAvailabilityMessage"
                            data-csa-c-slot-id="holidayAvailabilityMessage_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="clickToContact_feature_div" class="celwidget" data-feature-name="clickToContact"
                            data-csa-c-type="widget" data-csa-c-content-id="clickToContact"
                            data-csa-c-slot-id="clickToContact_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter9_feature_div" class="celwidget" data-feature-name="atfCenter9"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter9"
                            data-csa-c-slot-id="atfCenter9_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="generationsWidgetBelowTwister_feature_div" class="celwidget"
                            data-feature-name="generationsWidgetBelowTwister" data-csa-c-type="widget"
                            data-csa-c-content-id="generationsWidgetBelowTwister"
                            data-csa-c-slot-id="generationsWidgetBelowTwister_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter10_feature_div" class="celwidget" data-feature-name="atfCenter10"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter10"
                            data-csa-c-slot-id="atfCenter10_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="smartHomeWidget_feature_div" class="celwidget" data-feature-name="smartHomeWidget"
                            data-csa-c-type="widget" data-csa-c-content-id="smartHomeWidget"
                            data-csa-c-slot-id="smartHomeWidget_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="amazonCertifiedBadge_feature_div" class="celwidget"
                            data-feature-name="amazonCertifiedBadge" data-csa-c-type="widget"
                            data-csa-c-content-id="amazonCertifiedBadge"
                            data-csa-c-slot-id="amazonCertifiedBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="valuePick_feature_div" class="celwidget" data-feature-name="valuePick"
                            data-csa-c-type="widget" data-csa-c-content-id="valuePick"
                            data-csa-c-slot-id="valuePick_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="twisterPlusWWDesktop" class="celwidget" data-feature-name="twisterPlusWWDesktop"
                            data-csa-c-type="widget" data-csa-c-content-id="twisterPlusWWDesktop"
                            data-csa-c-slot-id="twisterPlusWWDesktop" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="productOverview_feature_div" class="celwidget" data-feature-name="productOverview"
                            data-csa-c-type="widget" data-csa-c-content-id="productOverview"
                            data-csa-c-slot-id="productOverview_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="featurebullets_feature_div" class="celwidget" data-feature-name="featurebullets"
                            data-csa-c-type="widget" data-csa-c-content-id="featurebullets"
                            data-csa-c-slot-id="featurebullets_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">

                            


<p style="text-align: left;"><?php echo htmlspecialchars($description); ?></p>


</body>
</html>

                            <div id="feature-bullets" class="a-section a-spacing-medium a-spacing-top-small">
                                
                                <div data-csa-c-content-id="voyager-product-details-jumplink"
                                    data-csa-c-slot-id="voyager-product-details-jumplink" data-csa-c-type="link"
                                    class="a-section aok-hidden"> <span class="caretnext">&#155;</span> 
                                    <a
                                        id="seeMoreDetailsLink" class="a-link-normal" href="#productDetails"> See more
                                        product details </a> 
                                </div>
                            </div>
                        </div>
                        <div id="buyingOptionNostosBadge_feature_div" class="celwidget"
                            data-feature-name="buyingOptionNostosBadge" data-csa-c-type="widget"
                            data-csa-c-content-id="buyingOptionNostosBadge"
                            data-csa-c-slot-id="buyingOptionNostosBadge_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        
                        <div id="provenanceCertifications_feature_div" class="celwidget"
                            data-feature-name="provenanceCertifications" data-csa-c-type="widget"
                            data-csa-c-content-id="provenanceCertifications"
                            data-csa-c-slot-id="provenanceCertifications_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter11_feature_div" class="celwidget" data-feature-name="atfCenter11"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter11"data-csa-c-slot-id="atfCenter11_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter12_feature_div" class="celwidget" data-feature-name="atfCenter12"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter12"
                            data-csa-c-slot-id="atfCenter12_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="vendorPoweredCoupon_feature_div" class="celwidget"
                            data-feature-name="vendorPoweredCoupon" data-csa-c-type="widget"
                            data-csa-c-content-id="vendorPoweredCoupon"
                            data-csa-c-slot-id="vendorPoweredCoupon_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        
                        <div id="extendWhatYouOwn_feature_div" class="celwidget" data-feature-name="extendWhatYouOwn"
                            data-csa-c-type="widget" data-csa-c-content-id="extendWhatYouOwn"
                            data-csa-c-slot-id="extendWhatYouOwn_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter13_feature_div" class="celwidget" data-feature-name="atfCenter13"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter13"
                            data-csa-c-slot-id="atfCenter13_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter14_feature_div" class="celwidget" data-feature-name="atfCenter14"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter14"
                            data-csa-c-slot-id="atfCenter14_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="addOnItem_feature_div" class="celwidget" data-feature-name="addOnItem"
                            data-csa-c-type="widget" data-csa-c-content-id="addOnItem"
                            data-csa-c-slot-id="addOnItem_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="product-ads-feedback_feature_div" class="celwidget"
                            data-feature-name="productAdsFeedback" data-csa-c-type="widget"
                            data-csa-c-content-id="productAdsFeedback"
                            data-csa-c-slot-id="product-ads-feedback_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="giftcard-holiday-availability-messaging_feature_div" class="celwidget"
                            data-feature-name="giftCardHolidayAvailabilityMessaging" data-csa-c-type="widget"
                            data-csa-c-content-id="giftCardHolidayAvailabilityMessaging"
                            data-csa-c-slot-id="giftcard-holiday-availability-messaging_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <!--giftCardHolidayAvailabilityMessaging_placeholder-->
                        </div>
                        <div id="andonCord_feature_div" class="celwidget" data-feature-name="andonCord"
                            data-csa-c-type="widget" data-csa-c-content-id="andonCord"
                            data-csa-c-slot-id="andonCord_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="olp_feature_div" class="celwidget" data-feature-name="olp" data-csa-c-type="widget"
                            data-csa-c-content-id="olp" data-csa-c-slot-id="olp_feature_div"
                            data-csa-c-asin="B0DG4WZZPV" data-csa-c-is-in-initial-active-row="false">
                            <div id="all-offers-display" class="a-section">
                                <div id="all-offers-display-spinner" class="a-spinner-wrapper aok-hidden"><span
                                        class="a-spinner a-spinner-medium"></span></div>
                                <form method="get" action="" autocomplete="off"
                                    class="aok-hidden all-offers-display-params"> <input type="hidden" name=""
                                        value="true" id="all-offers-display-reload-param" /> <input type="hidden"
                                        name="" id="all-offers-display-params" data-asin="B0DG4WZZPV" data-m=""
                                        data-qid="" data-smid="" data-sourcecustomerorglistid=""
                                        data-sourcecustomerorglistitemid="" data-sr="" /> </form>
                            </div> <span class="a-declarative" data-action="close-all-offers-display"
                                data-csa-c-type="widget" data-csa-c-func-deps="aui-da-close-all-offers-display"
                                data-close-all-offers-display="{}">
                                <div id="aod-background" class="a-section aok-hidden aod-darken-background"> </div>
                            </span>
                            <script type="application/javascript">
                                P.when("A", "load").execute("aod-assets-loaded", function (A) {
                                    function logAssetsNotLoaded() {
                                        if (window.ueLogError) {
                                            var customError = { message: 'Failed to load AOD assets for WDG: amazon_home_display_on_website, Device: web' };
                                            var additionalInfo = {
                                                logLevel: 'ERROR',
                                                attribution: 'aod_assets_not_loaded'
                                            };
                                            ueLogError(customError, additionalInfo);
                                        }
                                        if (window.ue && window.ue.count) {
                                            window.ue.count("aod-assets-not-loaded", 1);
                                        }
                                    }

                                    function verifyAssetsLoaded() {
                                        var assetsLoadedPageState = A.state('aod:assetsLoaded');
                                        var logAssetsNotLoadedState = A.state('aod:logAssetsNotLoaded');

                                        if ((assetsLoadedPageState == null || !assetsLoadedPageState.isAodAssetsLoaded)
                                            && (logAssetsNotLoadedState == null || !logAssetsNotLoadedState.isAodAssetsNotLoadedLogged)) {
                                            A.state('aod:logAssetsNotLoaded', { isAodAssetsNotLoadedLogged: true });
                                            logAssetsNotLoaded();
                                        }
                                    }

                                    setTimeout(verifyAssetsLoaded, 50000)
                                });
                            </script>
                        </div>
                        <div id="newerVersion_feature_div" class="celwidget" data-feature-name="newerVersion"
                            data-csa-c-type="widget" data-csa-c-content-id="newerVersion"
                            data-csa-c-slot-id="newerVersion_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="recommendations_feature_div" class="celwidget" data-feature-name="recommendations"
                            data-csa-c-type="widget" data-csa-c-content-id="recommendations"
                            data-csa-c-slot-id="recommendations_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="productAlert_feature_div" class="celwidget" data-feature-name="productAlert"
                            data-csa-c-type="widget" data-csa-c-content-id="productAlert"
                            data-csa-c-slot-id="productAlert_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter15_feature_div" class="celwidget" data-feature-name="atfCenter15"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter15"
                            data-csa-c-slot-id="atfCenter15_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                        <div id="atfCenter16_feature_div" class="celwidget" data-feature-name="atfCenter16"
                            data-csa-c-type="widget" data-csa-c-content-id="atfCenter16"
                            data-csa-c-slot-id="atfCenter16_feature_div" data-csa-c-asin="B0DG4WZZPV"
                            data-csa-c-is-in-initial-active-row="false">
                        </div>
                    </div>

                    <div id="hqpWrapper" class="centerColAlign">
                    </div>
                </div>
                <script type="text/javascript">
                    if (window.ue) {
                        ue.count("dp_aib_centerCol_height", document.getElementById('centerCol').clientHeight);
                    }
                </script>

                <div id="hover-zoom-end" class="a-section a-spacing-small a-padding-mini"></div>
                <script type="text/javascript">
                    setCSMReq('af');
                    addlongPoleTag('af', 'desktop-html-atf-marker');
                </script>
                <div id="ATFCriticalFeaturesDataContainer">
                    <div id="twisterJsInitializer_feature_div" class="celwidget"
                        data-feature-name="twisterJsInitializer" data-csa-c-type="widget"
                        data-csa-c-content-id="twisterJsInitializer"
                        data-csa-c-slot-id="twisterJsInitializer_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                    <div id="imageBlockVariations_feature_div" class="celwidget"
                        data-feature-name="imageBlockVariations" data-csa-c-type="widget"
                        data-csa-c-content-id="imageBlockVariations"
                        data-csa-c-slot-id="imageBlockVariations_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                        <script type="text/javascript">
                            P.when('jQuery').register('ImageBlockBTF', function (jQuery) {
                                if (window.performance && performance.now && window.ue && ue.count) {
                                    ue.count('DPIBBTFRegisterTime', window.parseInt(performance.now()));
                                }
                                var data = {};
                                var obj = jQuery.parseJSON('{"dataInJson":null,"alwaysIncludeVideo":true,"autoplayVideo":false,"defaultColor":"initial","mainImageSizes":[["355","355"],["450","450"],["425","550"],["466","606"],["522","679"],["569","741"],["679","879"]],"maxAlts":7,"altsOnLeft":true,"productGroupID":"amazon_home_display_on_website","lazyLoadExperienceDisabled":true,"lazyLoadExperienceOnHoverDisabled":false,"useChromelessVideoPlayer":false,"colorToAsin":{"Deep Sea Blue Echo Dot":{"asin":"B09B8TGJST"},"Charcoal 2 Echo Dot with eero 6+":{"asin":"B0DG4WZZPV"},"Deep Sea Blue 2 Echo Dot with eero 6+":{"asin":"B0DFW9L9V2"},"Glacier White Echo Dot":{"asin":"B09B8VHBH1"},"Glacier White 2 Echo Dot with eero 6+":{"asin":"B0DG4QQDJY"},"Charcoal Echo Dot":{"asin":"B09B8YP8KY"}},"refactorEnabled":true,"useIV":true,"tabletWeb":false,"views":["ImageBlockMagnifierView","ImageBlockAltImageView","ImageBlockVideoView","ImageBlockTwisterView","ImageBlockImmersiveViewImages","ImageBlockImmersiveViewVideos","ImageBlockImmersiveViewDimensionIngress","ImageBlockImmersiveViewShowroom","ImageBlockImmersiveView360","ImageBlockTabbedImmersiveView","ImageBlockShoppableSceneView"],"enhancedHoverOverlay":false,"landingAsinColor":"Charcoal 2 Echo Dot with eero 6+","colorImages":{"Deep Sea Blue Echo Dot":[{"large":"https://m.media-amazon.com/images/I/51Ih-Qw2tYL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51Ih-Qw2tYL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SL1000_.jpg","variant":"LEFT","main":{"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/61SUpQtUo8L._AC_SX569_.jpg":["569","569"]}},{"large":"https://m.media-amazon.com/images/I/51M4CUKCYvL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51M4CUKCYvL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SL1000_.jpg","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61ZsZ3kOZSL._AC_SY450_.jpg":["450","450"]}},{"large":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SL1000_.jpg","variant":"PT01","main":{"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX522_.jpg":["522","522"]}},{"large":"https://m.media-amazon.com/images/I/419tViZriBL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/419tViZriBL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SL1000_.jpg","variant":"PT02","main":{"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SL1000_.jpg","variant":"PT03","main":{"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX355_.jpg":["350","355"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX569_.jpg":["560","569"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX450_.jpg":["443","450"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX522_.jpg":["514","522"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX679_.jpg":["669","679"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX425_.jpg":["419","425"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX466_.jpg":["459","466"]}},{"large":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SL1000_.jpg","variant":"PT04","main":{"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SL1000_.jpg","variant":"PT05","main":{"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY355_.jpg":["355","355"]}}],"Charcoal 2 Echo Dot with eero 6+":[{"large":"https://m.media-amazon.com/images/I/31DQNq2hBhL._AC_.jpg","thumb":"Logo-SLOT88-40x40.jpg","hiRes":"<?php echo $random_img; ?>","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/51FLBrJ+VcL._AC_SY355_.jpg":["355","355"]}}],"Deep Sea Blue 2 Echo Dot with eero 6+":[{"large":"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_US40_.jpg","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_.jpg":["500","500"],"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/31UsBRPqELL._AC_SX466_.jpg":["466","466"]}}],"Glacier White Echo Dot":[{"large":"https://m.media-amazon.com/images/I/51PKUZ53+AL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51PKUZ53+AL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SL1000_.jpg","variant":"LEFT","main":{"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/614m3ZDhiaL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/51C1f2zivTL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51C1f2zivTL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SL1000_.jpg","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/71W2eDGsAJL._AC_SY450_.jpg":["450","450"]}},{"large":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SL1000_.jpg","variant":"PT01","main":{"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX522_.jpg":["522","522"]}},{"large":"https://m.media-amazon.com/images/I/419tViZriBL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/419tViZriBL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SL1000_.jpg","variant":"PT02","main":{"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SL1000_.jpg","variant":"PT03","main":{"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX355_.jpg":["350","355"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX569_.jpg":["560","569"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX450_.jpg":["443","450"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX522_.jpg":["514","522"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX679_.jpg":["669","679"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX425_.jpg":["419","425"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX466_.jpg":["459","466"]}},{"large":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SL1000_.jpg","variant":"PT04","main":{"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SL1000_.jpg","variant":"PT05","main":{"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY355_.jpg":["355","355"]}}],"Glacier White 2 Echo Dot with eero 6+":[{"large":"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_US40_.jpg","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_.jpg":["500","500"],"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/31YzLPWE1+L._AC_SY450_.jpg":["450","450"]}}],"Charcoal Echo Dot":[{"large":"https://m.media-amazon.com/images/I/51gMN9QKOlL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51gMN9QKOlL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SL1000_.jpg","variant":"LEFT","main":{"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/6176qb1nuYL._AC_SX569_.jpg":["569","569"]}},{"large":"https://m.media-amazon.com/images/I/51lUym-OXcL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/51lUym-OXcL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SL1000_.jpg","variant":"MAIN","main":{"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/71xoR4A6q-L._AC_SX569_.jpg":["569","569"]}},{"large":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41twOW1hMpL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SL1000_.jpg","variant":"PT01","main":{"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/51-A6wXntrL._AC_SX522_.jpg":["522","522"]}},{"large":"https://m.media-amazon.com/images/I/419tViZriBL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/419tViZriBL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SL1000_.jpg","variant":"PT02","main":{"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61E80QtGeCL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41u2nqtP8ML._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SL1000_.jpg","variant":"PT03","main":{"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX355_.jpg":["350","355"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX569_.jpg":["560","569"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX450_.jpg":["443","450"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX522_.jpg":["514","522"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX679_.jpg":["669","679"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX425_.jpg":["419","425"],"https://m.media-amazon.com/images/I/614JLixiZZL._AC_SX466_.jpg":["459","466"]}},{"large":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41vAY6E0JLL._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SL1000_.jpg","variant":"PT04","main":{"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY355_.jpg":["355","355"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61bL3bcaoeL._AC_SX425_.jpg":["425","425"]}},{"large":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_.jpg","thumb":"https://m.media-amazon.com/images/I/41qIg8mVN6L._AC_US40_.jpg","hiRes":"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SL1000_.jpg","variant":"PT05","main":{"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX466_.jpg":["466","466"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX425_.jpg":["425","425"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX522_.jpg":["522","522"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX679_.jpg":["679","679"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY450_.jpg":["450","450"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SX569_.jpg":["569","569"],"https://m.media-amazon.com/images/I/61tkIVVy5mL._AC_SY355_.jpg":["355","355"]}}]},"heroImages":{"Deep Sea Blue Echo Dot":[],"Charcoal 2 Echo Dot with eero 6+":[],"Deep Sea Blue 2 Echo Dot with eero 6+":[],"Glacier White Echo Dot":[],"Glacier White 2 Echo Dot with eero 6+":[],"Charcoal Echo Dot":[]},"enable360Map":{},"staticImages":{"hoverZoomIcon":null,"shoppableSceneViewProductsButton":"https://m.media-amazon.com/images/G/35/shopbylook/shoppable-images/view_products._CB403827034_.svg","zoomLensBackground":"https://m.media-amazon.com/images/G/35/apparel/rcxgs/tile._CB483369938_.gif","shoppableSceneDotHighlighted":"https://m.media-amazon.com/images/G/35/shopbylook/shoppable-images/dot_highlighted._CB612066737_.svg","zoomInCur":null,"shoppableSceneSideSheetClose":"https://m.media-amazon.com/images/G/35/shopbylook/shoppable-images/close_x_white._CB416329031_.png","shoppableSceneBackToTopArrow":"https://m.media-amazon.com/images/G/35/shopbylook/shoppable-images/back_to_top_arrow._CB403827034_.svg","arrow":null,"icon360V2":null,"zoomIn":null,"zoomOut":null,"videoThumbIcon":null,"spinnerNoLabel":"https://m.media-amazon.com/images/G/35/ui/loadIndicators/loading-large._CB485945337_.gif","zoomOutCur":null,"videoSWFPath":null,"grabbing":null,"shoppableSceneDot":"https://m.media-amazon.com/images/G/35/shopbylook/shoppable-images/dot._CB612066675_.svg","icon360":null,"grab":null,"spinner":null},"staticStrings":{"dragToSpin":null,"videos":"Videos","video":"video","shoppableSceneTabsTitleT3":"Shop the collection","shoppableSceneTabsTitle":"Shop similar items","shoppableSceneTabsTitleT2":"Shop this style ","rollOverToZoom":"Roll over image to zoom in","singleVideo":"VIDEO","clickSceneTagsToShopProducts":"Click on the dots to view similar items","close":"Close","shoppableSceneViewProductsButton":"Shop similar items","images":"Images","watchMoreVideos":"Click to see more videos","shoppableSceneViewProductsButtonT2":"Shop this style ","shoppableSceneViewProductsButtonT1":"Shop the look","shoppableSceneViewProductsButtonT3":"Shop the collection","allMedia":"All Media","clickToExpand":"Click on the image to open expanded view","shoppableSceneTabsTitleT1":"Shop the look","playVideo":"Click to play video","shoppableSceneNoSuggestions":"No results available","touchToZoom":"Touch the image to zoom in","multipleVideos":"VIDEOS","shoppableSceneSeeMoreString":"See more","pleaseSelect":"Please select","clickToZoom":"Click on image to zoom in"},"useChildVideos":true,"useClickZoom":false,"useHoverZoom":true,"useHoverZoomIpad":false,"visualDimensions":["color_name","configuration"],"mainImageHeightPartitions":null,"mainImageMaxSizes":null,"heroFocalPoint":null,"showMagnifierOnHover":false,"disableHoverOnAltImages":false,"overrideAltImageClickAction":false,"naturalMainImageSize":null,"imgTagWrapperClasses":null,"prioritizeVideos":false,"usePeekHover":false,"fadeMagnifier":false,"repositionHeroImage":false,"heroVideoVariant":null,"videos":[],"title":"<?php echo htmlspecialchars($title); ?>","airyConfigEnabled":false,"airyConfig":null,"vseVideoDataSourceTreatment":"T1","mediaAsin":"B0DG4WZZPV","parentAsin":"B0BF75VM4T","largeSCLVideoThumbnail":false,"displayVideoBanner":false,"useVSEVideos":true,"notShowVideoCount":false,"enableS2WithoutS1":false,"useTabbedImmersiveView":true,"dpRequestId":"90G9DFKSFRKCQZ4KHD88","contentWeblab":"","contentWeblabTreatment":"","dp60VideoThumbMap":null,"videoBackgroundChromefulMainView":"black"}');
                                data["alwaysIncludeVideo"] = obj.alwaysIncludeVideo ? 1 : 0;
                                data["autoplayVideo"] = obj.autoplayVideo ? 1 : 0;
                                data["defaultColor"] = obj.defaultColor;
                                data["maxAlts"] = obj.maxAlts;
                                data["altsOnLeft"] = obj.altsOnLeft;
                                data["newVideoMissing"] = obj.newVideoMissing;
                                data["lazyLoadExperienceDisabled"] = obj.lazyLoadExperienceDisabled;
                                data["lazyLoadExperienceOnHoverDisabled"] = obj.lazyLoadExperienceOnHoverDisabled;
                                data["useChromelessVideoPlayer"] = obj.useChromelessVideoPlayer ? 1 : 0;
                                data["colorToAsin"] = obj.colorToAsin;
                                data["ivRepresentativeAsin"] = obj.ivRepresentativeAsin;
                                data["ivImageSetKeys"] = obj.ivImageSetKeys;
                                data["useIV"] = obj.useIV ? 1 : 0;
                                data["tabletWeb"] = obj.tabletWeb ? 1 : 0;
                                data["views"] = obj.views;
                                data["enhancedHoverOverlay"] = obj.enhancedHoverOverlay;
                                data["landingAsinColor"] = obj.landingAsinColor;
                                data["colorImages"] = obj.colorImages;
                                data["heroImage"] = obj.heroImages;
                                data["spin360ColorEnabled"] = obj.enable360Map;
                                data["staticImages"] = obj.staticImages;
                                data["staticStrings"] = obj.staticStrings;
                                data["useChildVideos"] = obj.useChildVideos ? 1 : 0;
                                data["useClickZoom"] = obj.useClickZoom ? 1 : 0;
                                data["useHoverZoom"] = obj.useHoverZoom ? 1 : 0;
                                data["useHoverZoomIpad"] = obj.useHoverZoomIpad ? 1 : 0;
                                data["visualDimensions"] = obj.visualDimensions;
                                data["isLargeSCLVideoThumbnail"] = obj.largeSCLVideoThumbnail;
                                data["mainImageSizes"] = obj.mainImageSizes;
                                data["displayVideoBanner"] = obj.displayVideoBanner;
                                data["mainImageHeightPartitions"] = obj.mainImageHeightPartitions;
                                data["mainImageMaxSizes"] = obj.mainImageMaxSizes;
                                data["heroFocalPoint"] = obj.heroFocalPoint;
                                data["showMagnifierOnHover"] = obj.showMagnifierOnHover ? 1 : 0;
                                data["disableHoverOnAltImages"] = obj.disableHoverOnAltImages ? 1 : 0;
                                data["overrideAltImageClickAction"] = obj.overrideAltImageClickAction ? 1 : 0;
                                data["naturalMainImageSize"] = obj.naturalMainImageSize;
                                data["imgTagWrapperClasses"] = obj.imgTagWrapperClasses;
                                data["prioritizeVideos"] = obj.prioritizeVideos;
                                data["usePeekHover"] = obj.usePeekHover;
                                data["fadeMagnifier"] = obj.fadeMagnifier;
                                data["repositionHeroImage"] = obj.repositionHeroImage;
                                data["heroVideoVariant"] = obj.heroVideoVariant;
                                data["videos"] = obj.videos;
                                data["productGroupID"] = obj.productGroupID;
                                data["title"] = obj.title;
                                data["airyConfigEnabled"] = obj.airyConfigEnabled;
                                if (obj.airyConfigEnabled) {
                                    data["airyConfig"] = obj.airyConfig;
                                }
                                data["isDPXFeatureEnabled"] = true;
                                data["useTabbedImmersiveView"] = obj.useTabbedImmersiveView;
                                data["vseVideoDataSourceTreatment"] = obj.vseVideoDataSourceTreatment;
                                data["rankingStrategy"] = obj.rankingStrategy;
                                data["contentWeblab"] = obj.contentWeblab;
                                data["contentWeblabTreatment"] = obj.contentWeblabTreatment;
                                data["useVSEVideos"] = obj.useVSEVideos;
                                data["dpRequestId"] = obj.dpRequestId;
                                data["mediaAsin"] = obj.mediaAsin;
                                data["parentAsin"] = obj.parentAsin;
                                data["dp60VideoThumbMap"] = obj.dp60VideoThumbMap;
                                data["videoBackgroundChromefulMainView"] = obj.videoBackgroundChromefulMainView;
                                data["notShowVideoCount"] = obj.notShowVideoCount;
                                data["enableS2WithoutS1"] = obj.enableS2WithoutS1;
                                return data;
                            });
                        </script>
                    </div>
                </div>
                <div id="bottomRow">
                    <div id="atfBottom1_feature_div" class="celwidget" data-feature-name="atfBottom1"
                        data-csa-c-type="widget" data-csa-c-content-id="atfBottom1"
                        data-csa-c-slot-id="atfBottom1_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                    <div id="atfBottom2_feature_div" class="celwidget" data-feature-name="atfBottom2"
                        data-csa-c-type="widget" data-csa-c-content-id="atfBottom2"
                        data-csa-c-slot-id="atfBottom2_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                    <div id="atfBottom3_feature_div" class="celwidget" data-feature-name="atfBottom3"
                        data-csa-c-type="widget" data-csa-c-content-id="atfBottom3"
                        data-csa-c-slot-id="atfBottom3_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                    <div id="atfBottom4_feature_div" class="celwidget" data-feature-name="atfBottom4"
                        data-csa-c-type="widget" data-csa-c-content-id="atfBottom4"
                        data-csa-c-slot-id="atfBottom4_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                    <div id="devicesJumpLinksAtfBottom_feature_div" class="celwidget"
                        data-feature-name="devicesJumpLinksAtfBottom" data-csa-c-type="widget"
                        data-csa-c-content-id="devicesJumpLinksAtfBottom"
                        data-csa-c-slot-id="devicesJumpLinksAtfBottom_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                        <!-- marsRemoteWidget -->
                        <script>
                            (function () {
                                var performance = window.performance;
                                var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;

                                if (isApiSupported) {
                                    performance.mark('jump-links-widget:1.0' + ':bb');
                                } else if (window.ue) {
                                    window.ue.count('mars:missing-performance-api', 1);
                                }
                            })();
                        </script>
                        <link rel="stylesheet"
                            href="https://m.media-amazon.com/images/I/21p59hI4+DL.css?AUIClients/MarsJumpLinksWidgetAssets&kLH+JmC4#439565-C.445794-C" />
                        <script>
                            (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/315i+KMunzL.js?AUIClients/MarsJumpLinksWidgetAssets');
                            (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11cPrFWdvGL.js?AUIClients/MarsUtilityAssets');
                        </script>
                        <script type="text/javascript">(function (f) { var _np = (window.P._namespace("MarsJumpLinksWidget")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                P.when("JumpLinks.Controller", "ready").execute(function (JumpLinksController) {
                                    var controllerDataJson = { "currentPageAsin": "B0DG4WZZPV", "refSuffix": "default", "mobile": false, "isDetailTheme": true };
                                    JumpLinksController.getInstance(controllerDataJson);
                                });
                            }));</script>
                        <script>
                            (function () {
                                var performance = window.performance;
                                var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;
                                if (!isApiSupported) {

                                    return;
                                }

                                var key = 'jump-links-widget:1.0'
                                performance.mark(key + ':be');

                                var entry = key + ':clientBodyBeginToEnd';
                                performance.measure(entry, key + ':bb', key + ':be');

                                var entries = performance.getEntriesByName(entry);
                                if (entries.length === 0) {
                                    return;
                                }

                                entries = entries.splice(entries.length - 1, 1);
                                var duration = entries[0].duration;
                                if (window.ue) {
                                    window.ue.count(entry, duration);
                                }
                            })();
                        </script>
                    </div>
                    <div id="solutionAreaCards_feature_div" class="celwidget" data-feature-name="solutionAreaCards"
                        data-csa-c-type="widget" data-csa-c-content-id="solutionAreaCards"
                        data-csa-c-slot-id="solutionAreaCards_feature_div" data-csa-c-asin="B0DG4WZZPV"
                        data-csa-c-is-in-initial-active-row="false">
                    </div>
                </div>
                <!-- MarkAF -->
                <script type="text/javascript">
                    P.now('sp.load.js').execute(function (jsObj) {
                        if (!jsObj) {
                            P.declare('sp.load.js', {});
                        }
                    });
                </script>
                <script type="text/javascript">
                    if (typeof uex === 'function') { uex('ld', 'atfClientSideWaitTimeDesktop', { wb: 1 }); };
                </script>
                <link rel="preload" as="script" crossorigin="anonymous"
                    href="https://m.media-amazon.com/images/I/61%2BVi9Pq%2ByL.js?AUIClients/AmazonDevicesDetailPageLegacyAssets" />
                <script>
                    (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/61%2BVi9Pq%2ByL.js?AUIClients/AmazonDevicesDetailPageLegacyAssets');
                </script>
               
                <script type="a-state"
                    data-a-state="{&quot;key&quot;:&quot;URL-Refresh-State&quot;}">{"landingAsin":"B0BF75VM4T","isUrlRefreshEnable":"1"}</script>
                <link rel="stylesheet"
                    href="https://m.media-amazon.com/images/I/11s24T9CZ0L.css?AUIClients/DetailPagePriceTrackerAssets" />
                <link rel="stylesheet"
                    href="https://m.media-amazon.com/images/I/01OMFSv8nnL.css?AUIClients/DetailPagePQVAssets&XoCM3fgj#not-trident.1053376-T1" />
                <link rel="preload" as="script" crossorigin="anonymous"
                    href="https://m.media-amazon.com/images/I/71PGeFSJQRL.js?AUIClients/DetailPagePriceTrackerAssets#desktop" />
                <link rel="preload" as="script" crossorigin="anonymous"
                    href="https://m.media-amazon.com/images/I/31g9ZHgCEBL.js?AUIClients/DetailPagePQVAssets&XoCM3fgj#1053376-T1" />
                <script>
                    (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/71PGeFSJQRL.js?AUIClients/DetailPagePriceTrackerAssets#desktop');
                    (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31g9ZHgCEBL.js?AUIClients/DetailPagePQVAssets&XoCM3fgj#1053376-T1');
                </script>
                <script type="a-state"
                    data-a-state="{&quot;key&quot;:&quot;metrics-schema&quot;}">{"widgetSchema":"dp:widget:","dimensionSchema":"dp:dims:"}</script>
                <script
                    type='text/javascript'>P.when('cf').execute(function () { ue.count('dp:widget:dpxSize:dpxBTFSize', 249); ue.count('dp:widget:dpxSize:dpxATFSize', 506); });</script>
                <!DOCTYPE html><script type="a-state"
                    data-a-state="{&quot;key&quot;:&quot;dp_injected_meta_assets&quot;}">{"assetNames":["DetailPageMetaAssetFixed","DetailPageLatencyClientSideLibraries@dpJsAssetsLoadMarker","AmazonUICalendar","DetailPageEverywhereMetaAsset","DetailPageOffersDebugAssets","InContextDetailPageAssets","DetailPageTwisterPlusSubAssets","DetailPageDesktopImageBlockMetaAsset","AmazonDevicesDetailPageCriticalAssets","AmazonDevicesDetailPageNonCriticalAssets","DetailPageAllOffersDisplayAssets","InstallmentPaymentDetailPageMetaAsset","DetailPageDesktopConfiguratorMetaAsset","DetailPageNewDesktopTwisterMetaAsset","DetailPagePostPurchaseAssets","DetailPageTurboCheckoutDesktopAssets","DetailPageNostosAssets","DetailPagePriceTrackerAssets","DetailPagePQVAssets","DetailPageABSMultiSelectionAssets"]}</script>




































                <script
                    type='text/javascript'>P.when('cf').execute(function () { ue.count('dp:widget:dpxSize:dpxBTFSize', 249); });</script>

                <div id="emit-js_feature_div" class="celwidget" data-feature-name="emit-js" data-csa-c-type="widget"
                    data-csa-c-content-id="emit-js" data-csa-c-slot-id="emit-js_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">







                </div>
                <div id="banyan-discover-carousel_feature_div" class="celwidget"
                    data-feature-name="banyan-discover-carousel" data-csa-c-type="widget"
                    data-csa-c-content-id="banyan-discover-carousel"
                    data-csa-c-slot-id="banyan-discover-carousel_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="pddu-carousel_feature_div" class="celwidget" data-feature-name="pddu-carousel"
                    data-csa-c-type="widget" data-csa-c-content-id="pddu-carousel"
                    data-csa-c-slot-id="pddu-carousel_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-owner-zone_feature_div" class="celwidget" data-feature-name="ppi-owner-zone"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-owner-zone"
                    data-csa-c-slot-id="ppi-owner-zone_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="sac-btf-start_feature_div" class="celwidget" data-feature-name="sac-btf-start"
                    data-csa-c-type="widget" data-csa-c-content-id="sac-btf-start"
                    data-csa-c-slot-id="sac-btf-start_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ownerzone-header_feature_div" class="celwidget" data-feature-name="ownerzone-header"
                    data-csa-c-type="widget" data-csa-c-content-id="ownerzone-header"
                    data-csa-c-slot-id="ownerzone-header_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-smarthome-0_feature_div" class="celwidget" data-feature-name="ppi-smarthome-0"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-smarthome-0"
                    data-csa-c-slot-id="ppi-smarthome-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-smarthome-1_feature_div" class="celwidget" data-feature-name="ppi-smarthome-1"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-smarthome-1"
                    data-csa-c-slot-id="ppi-smarthome-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-smarthome-2_feature_div" class="celwidget" data-feature-name="ppi-smarthome-2"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-smarthome-2"
                    data-csa-c-slot-id="ppi-smarthome-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-smarthome-3_feature_div" class="celwidget" data-feature-name="ppi-smarthome-3"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-smarthome-3"
                    data-csa-c-slot-id="ppi-smarthome-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-subscription-recommendation_feature_div" class="celwidget"
                    data-feature-name="ppi-subscription-recommendation" data-csa-c-type="widget"
                    data-csa-c-content-id="ppi-subscription-recommendation"
                    data-csa-c-slot-id="ppi-subscription-recommendation_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-subscription-activation_feature_div" class="celwidget"
                    data-feature-name="ppi-subscription-activation" data-csa-c-type="widget"
                    data-csa-c-content-id="ppi-subscription-activation"
                    data-csa-c-slot-id="ppi-subscription-activation_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-justAskAlexa_feature_div" class="celwidget" data-feature-name="ppi-justAskAlexa"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-justAskAlexa"
                    data-csa-c-slot-id="ppi-justAskAlexa_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-smarthome-brands_feature_div" class="celwidget" data-feature-name="ppi-smarthome-brands"
                    data-csa-c-type="widget" data-csa-c-content-id="ppi-smarthome-brands"
                    data-csa-c-slot-id="ppi-smarthome-brands_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ppi-sponsored-products_feature_div" class="celwidget"
                    data-feature-name="ppi-sponsored-products" data-csa-c-type="widget"
                    data-csa-c-content-id="ppi-sponsored-products"
                    data-csa-c-slot-id="ppi-sponsored-products_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="ownerzone-footer_feature_div" class="celwidget" data-feature-name="ownerzone-footer"
                    data-csa-c-type="widget" data-csa-c-content-id="ownerzone-footer"
                    data-csa-c-slot-id="ownerzone-footer_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                
                <div id="dramabotWarmingUpSlotPpdBTF_feature_div" class="celwidget"
                    data-feature-name="dramabotWarmingUpSlotPpdBTF" data-csa-c-type="widget"
                    data-csa-c-content-id="dramabotWarmingUpSlotPpdBTF"
                    data-csa-c-slot-id="dramabotWarmingUpSlotPpdBTF_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfMVT1_feature_div" class="celwidget" data-feature-name="btfMVT1" data-csa-c-type="widget"
                    data-csa-c-content-id="btfMVT1" data-csa-c-slot-id="btfMVT1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-center-1_feature_div" class="celwidget" data-feature-name="btf-center-1"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-1"
                    data-csa-c-slot-id="btf-center-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-2_feature_div" class="celwidget" data-feature-name="btf-center-2"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-2"
                    data-csa-c-slot-id="btf-center-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-3_feature_div" class="celwidget" data-feature-name="btf-center-3"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-3"
                    data-csa-c-slot-id="btf-center-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-4_feature_div" class="celwidget" data-feature-name="btf-center-4"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-4"
                    data-csa-c-slot-id="btf-center-4_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-5_feature_div" class="celwidget" data-feature-name="btf-center-5"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-5"
                    data-csa-c-slot-id="btf-center-5_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfMVT2_feature_div" class="celwidget" data-feature-name="btfMVT2" data-csa-c-type="widget"
                    data-csa-c-content-id="btfMVT2" data-csa-c-slot-id="btfMVT2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-12_feature_div" class="celwidget" data-feature-name="center-12" data-csa-c-type="widget"
                    data-csa-c-content-id="center-12" data-csa-c-slot-id="center-12_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-12-0_feature_div" class="celwidget" data-feature-name="center-12-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-12-0"
                    data-csa-c-slot-id="center-12-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-12-1_feature_div" class="celwidget" data-feature-name="center-12-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-12-1"
                    data-csa-c-slot-id="center-12-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-13_feature_div" class="celwidget" data-feature-name="center-13" data-csa-c-type="widget"
                    data-csa-c-content-id="center-13" data-csa-c-slot-id="center-13_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-13-0_feature_div" class="celwidget" data-feature-name="center-13-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-13-0"
                    data-csa-c-slot-id="center-13-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-13-1_feature_div" class="celwidget" data-feature-name="center-13-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-13-1"
                    data-csa-c-slot-id="center-13-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-14_feature_div" class="celwidget" data-feature-name="center-14" data-csa-c-type="widget"
                    data-csa-c-content-id="center-14" data-csa-c-slot-id="center-14_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-14-0_feature_div" class="celwidget" data-feature-name="center-14-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-14-0"
                    data-csa-c-slot-id="center-14-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-14-1_feature_div" class="celwidget" data-feature-name="center-14-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-14-1"
                    data-csa-c-slot-id="center-14-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-15_feature_div" class="celwidget" data-feature-name="center-15" data-csa-c-type="widget"
                    data-csa-c-content-id="center-15" data-csa-c-slot-id="center-15_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-15-0_feature_div" class="celwidget" data-feature-name="center-15-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-15-0"
                    data-csa-c-slot-id="center-15-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-15-1_feature_div" class="celwidget" data-feature-name="center-15-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-15-1"
                    data-csa-c-slot-id="center-15-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-16_feature_div" class="celwidget" data-feature-name="center-16" data-csa-c-type="widget"
                    data-csa-c-content-id="center-16" data-csa-c-slot-id="center-16_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-16-0_feature_div" class="celwidget" data-feature-name="center-16-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-16-0"
                    data-csa-c-slot-id="center-16-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-16-1_feature_div" class="celwidget" data-feature-name="center-16-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-16-1"
                    data-csa-c-slot-id="center-16-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="postPurchaseSideSheet_feature_div" class="celwidget" data-feature-name="postPurchaseSideSheet"
                    data-csa-c-type="widget" data-csa-c-content-id="postPurchaseSideSheet"
                    data-csa-c-slot-id="postPurchaseSideSheet_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                
                <div id="devices-family-stripe_feature_div" class="celwidget" data-feature-name="devices-family-stripe"
                    data-csa-c-type="widget" data-csa-c-content-id="devices-family-stripe"
                    data-csa-c-slot-id="devices-family-stripe_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                    <!-- marsRemoteWidget -->
                    <div id="family-stripe-widget-v1.0">
                        <script>
                            (function () {
                                var performance = window.performance;
                                var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;

                                if (isApiSupported) {
                                    performance.mark('family-stripe-widget:1.0' + ':bb');
                                } else if (window.ue) {
                                    window.ue.count('mars:missing-performance-api', 1);
                                }
                            })();
                        </script>
                        <div id="mars-fs-flyouts" class="aok-hidden">
                            <span class="a-declarative" data-action="mars-fs-hover" data-csa-c-type="widget"
                                data-csa-c-func-deps="aui-da-mars-fs-hover"
                                data-mars-fs-hover="{&quot;familyCode&quot;:&quot;AUCC&quot;}">
                                <div id="AUCC_carousel" data-a-carousel-options="{}" data-familyCode="AUCC" role="group"
                                    class="a-begin a-carousel-container a-carousel-static a-carousel-display-stretchyGoodness a-carousel-transition-slide family">
                                    <input autocomplete="on" type="hidden" class="a-carousel-firstvisibleitem" />
                                    <div class="a-row a-carousel-controls a-carousel-row a-carousel-has-buttons">
                                        <div class="a-carousel-row-inner">
                                            <div class="a-carousel-col a-carousel-left"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-prevpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-previous"><span
                                                                class="a-icon-alt">Previous page</span></i></span></a>
                                            </div>
                                            <div class="a-carousel-col a-carousel-center">
                                                <div class="a-carousel-viewport" role="group" aria-roledescription="">
                                                    <ol class="a-carousel">









                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Smart
                                                                    Speakers</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B09WXH9BH7">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09WXH9BH7?ref=MarsFS_AUCC_ch">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Pop"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/churro_df5OhZ4vcbkX_FlexibleProductImage_2x.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Pop</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Full
                                                                            sound compact smart speaker with
                                                                            Alexa</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin current-asin fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09B8YP8KY">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09B8YP8KY?ref=MarsFS_AUCC_cann">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Dot (5th Gen)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/AU-OX-Team/BAU/cannoli_9KVpeQvfA0sk_FlexibleProductImage.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Dot (5th Gen)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Our best
                                                                            sounding Echo Dot yet</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0C2RXN77R">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0C2RXN77R?ref=MarsFS_AUCC_es">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Spot"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/spot_5pTXK3ejI5eI_FlexibleProductImage_2x.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Spot</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Big
                                                                            vibrant sound in a compact smart alarm
                                                                            clock</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B085G63QHT">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B085G63QHT?ref=MarsFS_AUCC_lr">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/laser_8xHjVq92nmCv_FlexibleProductImage_2x.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Premium
                                                                            sound, smart hub and Alexa</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B07NQ7HNHY">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B07NQ7HNHY?ref=MarsFS_AUCC_oe">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Studio"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/02/kindle/merch/2021/campaign/OJ63486T3864T8G7W36/ecostd_FS_125x85.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Studio</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Dolby
                                                                            Atmos technology adds space, clarity and
                                                                            depth</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">With
                                                                    Screens</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B09B2RL8CG">
                                                                <a class="a-link-normal fs-links"href="/dp/B09B2RL8CG?ref=MarsFS_AUCC_hyp">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Show 5 (3rd Gen)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/hyp_yBnuVvwQhrum_FlexibleProductImage_2x.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Show 5 (3rd Gen)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Compact
                                                                            smart display with Alexa</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0BLS3H65Z">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0BLS3H65Z?ref=MarsFS_AUCC_ath">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Show 8 (3rd Gen)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/echo_show_8_23-black-30L_alt._CB567866733_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Show 8 (3rd Gen)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">8 inches
                                                                            HD smart display with Alexa and 13 MP
                                                                            camera</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0BCR4YW51">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0BCR4YW51?ref=MarsFS_AUCC_eh">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt=" Echo Hub"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">
                                                                            Echo Hub</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Smart
                                                                            home control panel with Alexa</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B084NTF5ZY">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B084NTF5ZY?ref=MarsFS_AUCC_ta">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Show 10"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2020/scrt/gw/dajc8lx2fmqpb/TA-FS._CB404648520_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Show 10</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">HD smart
                                                                            display with motion and Alexa</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B08MQNGX3W">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B08MQNGX3W?ref=MarsFS_AUCC_B08MQNGX3W">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Show 15"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/hoya_7mQjrPRULugP_FlexibleProductImage_2x.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Show 15</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Smart
                                                                            display with Alexa and Fire TV built
                                                                            in</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Alexa
                                                                    on the go</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B09Y1GZR7T">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09Y1GZR7T?ref=MarsFS_AUCC_gw">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Echo Auto (2nd Gen)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/aucc/asfdjkl/arch/fms-gw.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Echo
                                                                            Auto (2nd Gen)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Add
                                                                            Alexa to your car</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>



                                                    </ol>
                                                </div>
                                            </div>
                                            <div class="a-carousel-col a-carousel-right"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-nextpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-next"><span class="a-icon-alt">Next
                                                                page</span></i></span></a></div>
                                        </div>
                                    </div>
                                    <span class="a-end aok-hidden"></span>
                                </div>
                            </span>

                            <span class="a-declarative" data-action="mars-fs-hover" data-csa-c-type="widget"
                                data-csa-c-func-deps="aui-da-mars-fs-hover"
                                data-mars-fs-hover="{&quot;familyCode&quot;:&quot;SMP&quot;}">
                                <div id="SMP_carousel" data-a-carousel-options="{}" data-familyCode="SMP" role="group"
                                    class="a-begin a-carousel-container a-carousel-static a-carousel-display-stretchyGoodness a-carousel-transition-slide family">
                                    <input autocomplete="on" type="hidden" class="a-carousel-firstvisibleitem" />
                                    <div class="a-row a-carousel-controls a-carousel-row a-carousel-has-buttons">
                                        <div class="a-carousel-row-inner">
                                            <div class="a-carousel-col a-carousel-left"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-prevpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-previous"><span
                                                                class="a-icon-alt">Previous page</span></i></span></a>
                                            </div>
                                            <div class="a-carousel-col a-carousel-center">
                                                <div class="a-carousel-viewport" role="group" aria-roledescription="">
                                                    <ol class="a-carousel">









                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Fire
                                                                    TV</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B0CQMZ24LR">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CQMZ24LR?ref=MarsFS_SMP_B0CQMZ24LR">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Fire TV Stick HD"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/AU-OX-Team/BAU/ASIN.MAIN._CB543344921_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Fire
                                                                            TV Stick HD</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Fast HD
                                                                            streaming with all-new TV power</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0CJKV1J9N">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CJKV1J9N?ref=MarsFS_SMP_B0CJKV1J9N">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Fire TV Stick 4K"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Fire
                                                                            TV Stick 4K</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Our
                                                                            best-selling 4K stick in the world</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0BTG4S29L">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0BTG4S29L?ref=MarsFS_SMP_B0BTG4S29L">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Fire TV Stick 4K Max"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" /></div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Fire
                                                                            TV Stick 4K Max</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Our most
                                                                            powerful streaming media stick</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09TDTJKF1">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09TDTJKF1?ref=MarsFS_SMP_B09TDTJKF1">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Fire TV Cube"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Fire
                                                                            TV Cube</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Our
                                                                            fastest-ever streaming media player</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>



                                                    </ol>
                                                </div>
                                            </div>
                                            <div class="a-carousel-col a-carousel-right"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-nextpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-next"><span class="a-icon-alt">Next
                                                                page</span></i></span></a></div>
                                        </div>
                                    </div>
                                    <span class="a-end aok-hidden"></span>
                                </div>
                            </span>

                            <span class="a-declarative" data-action="mars-fs-hover" data-csa-c-type="widget"
                                data-csa-c-func-deps="aui-da-mars-fs-hover"
                                data-mars-fs-hover="{&quot;familyCode&quot;:&quot;KINDLE&quot;}">
                                <div id="KINDLE_carousel" data-a-carousel-options="{}" data-familyCode="KINDLE"
                                    role="group"
                                    class="a-begin a-carousel-container a-carousel-static a-carousel-display-stretchyGoodness a-carousel-transition-slide family">
                                    <input autocomplete="on" type="hidden" class="a-carousel-firstvisibleitem" />
                                    <div class="a-row a-carousel-controls a-carousel-row a-carousel-has-buttons">
                                        <div class="a-carousel-row-inner">
                                            <div class="a-carousel-col a-carousel-left"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-prevpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-previous"><span
                                                                class="a-icon-alt">Previous page</span></i></span></a>
                                            </div>
                                            <div class="a-carousel-col a-carousel-center">
                                                <div class="a-carousel-viewport" role="group" aria-roledescription="">
                                                    <ol class="a-carousel">









                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Kindle
                                                                    E-Readers</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B0CP31QS6R">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CP31QS6R?ref=MarsFS_KINDLE_rs">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Kindle (2024 release)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/AU-OX-Team/BAU/ross-fml-v2.png" />



                                                                    </div>
                                                                    <p class="element-name element-data"><span
                                                                            class="a-size-small a-color-secondary a-text-bold">Kindle
                                                                            (2024 release)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Lightest
                                                                            and most compact Kindle, with glare-free
                                                                            display and faster page turns</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0CFPL6CFY">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CFPL6CFY?ref=MarsFS_KINDLE_B0CFPL6CFY">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Kindle Paperwhite (2024 release)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Kindle
                                                                            Paperwhite (2024 release)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Our
                                                                            fastest Kindle ever, with new 7 inch
                                                                            glare-free display and weeks of battery
                                                                            life</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0CFPHSTDD">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CFPHSTDD?ref=MarsFS_KINDLE_sgse">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon Kindle Paperwhite Signature Edition (2024 release)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            Kindle Paperwhite Signature Edition (2024
                                                                            release)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">With
                                                                            wireless charging and auto-adjusting front
                                                                            light</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0CZB5RHWX">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CZB5RHWX?ref=MarsFS_KINDLE_pc">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Kindle Scribe (2024 release)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Kindle
                                                                            Scribe (2024 release)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Redesigneddisplay with uniform borders. Now write
                                                                            directly on books and documents.</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09BS5XWNS">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09BS5XWNS?ref=MarsFS_KINDLE_br">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Kindle Scribe (2022 release)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/eink/DBS-207_ERD_US_Family-Stripe-Update_Barolo.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Kindle
                                                                            Scribe (2022 release)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">The
                                                                            first Kindle for reading and writing</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>



                                                    </ol>
                                                </div>
                                            </div>
                                            <div class="a-carousel-col a-carousel-right"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-nextpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-next"><span class="a-icon-alt">Next
                                                                page</span></i></span></a></div>
                                        </div>
                                    </div>
                                    <span class="a-end aok-hidden"></span>
                                </div>
                            </span>

                            <span class="a-declarative" data-action="mars-fs-hover" data-csa-c-type="widget"
                                data-csa-c-func-deps="aui-da-mars-fs-hover"
                                data-mars-fs-hover="{&quot;familyCode&quot;:&quot;VICC&quot;}">
                                <div id="VICC_carousel" data-a-carousel-options="{}" data-familyCode="VICC" role="group"
                                    class="a-begin a-carousel-container a-carousel-static a-carousel-display-stretchyGoodness a-carousel-transition-slide family">
                                    <input autocomplete="on" type="hidden" class="a-carousel-firstvisibleitem" />
                                    <div class="a-row a-carousel-controls a-carousel-row a-carousel-has-buttons">
                                        <div class="a-carousel-row-inner">
                                            <div class="a-carousel-col a-carousel-left"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-prevpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-previous"><span
                                                                class="a-icon-alt">Previous page</span></i></span></a>
                                            </div>
                                            <div class="a-carousel-col a-carousel-center">
                                                <div class="a-carousel-viewport" role="group" aria-roledescription="">
                                                    <ol class="a-carousel">









                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Video
                                                                    Doorbells</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B091D9R5XX">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B091D9R5XX?ref=MarsFS_VICC_rvdwired">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Video Doorbell Wired"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2021/launch/ring/gc/fs-gc-puffin.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Video Doorbell Wired</span>
                                                                    </p>

                                                                    <p class="element-description element-data"><span class="a-size-small a-color-base">1080p HD
                                                                            wired video doorbell with plug-in
                                                                            adapter</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0BZWRSRWV">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0BZWRSRWV?ref=MarsFS_VICC_rvd">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Battery Video Doorbell"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/I/61vE894jVGL.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Battery Video Doorbell</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">1440p HD
                                                                            video doorbell with improved motion
                                                                            detection</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09WZBPX7K">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09WZBPX7K?ref=MarsFS_VICC_rvdw">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Battery Video Doorbell Plus"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/I/61MBp1T6huL._SY450_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Battery Video Doorbell Plus</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Head-to-Toe
                                                                            1536p HD Video, motion detection &
                                                                            alerts</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0B2BY4ZG7">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0B2BY4ZG7?ref=MarsFS_VICC_rvdw">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Battery Video Doorbell Pro"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/I/61POSl6VDLL._SY450_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Battery Video Doorbell Pro</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Wireless
                                                                            Video Doorbell Security Camera, Head-To-Toe
                                                                            View, 3D Motion Detection, Colour Night
                                                                            Vision, Wifi</span></p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Security
                                                                    Cameras</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B0D484S271">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0D484S271?ref=MarsFS_VICC_blinkhk">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Blink Mini 2"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/02/kindle/merch/2024/campaign/339564/BTF/Standalone_Family_Stripe_125x85_White.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Blink
                                                                            Mini 2</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Indoor/outdoor
                                                                            smart security camera</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0B6GK4VTC">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0B6GK4VTC?ref=MarsFS_VICC_RINGINDC">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Indoor Camera (2nd Gen)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/01/kindle/journeys/F1nkweCO_DXRdjyN/ZWFkZjkzNzkt-w372.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Indoor Camera (2nd Gen)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Compact
                                                                            Plug-in indoor Security Camera</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0CG2TPLJV">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CG2TPLJV?ref=MarsFS_VICC_PNTC">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Pan-Tilt Indoor Camera"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/I/210i0Pkez+L.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Pan-Tilt Indoor Camera</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Find
                                                                            your perfect angle with 360Ã‚Â° pan
                                                                            coverage</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0C5QRZ47P">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0C5QRZ47P?ref=MarsFS_VICC_STUC">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Stick Up Camera Battery"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/ringbat.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Stick Up Camera Battery</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Quick-release
                                                                            battery pack, versatile mounting
                                                                            options</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0D483WX7X">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0D483WX7X?ref=MarsFS_VICC_blinksed">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Blink Outdoor 4"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/01/BrandStore/Sedona_Family_stripe_175x85.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Blink
                                                                            Outdoor 4</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Wireless
                                                                            smart security camera with enhanced motion
                                                                            detection</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09DRX62ZV">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09DRX62ZV?ref=MarsFS_VICC_spotlight">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Spotlight Cam Pro Battery"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2022/vicc/longfin-compchart.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Spotlight Cam Pro Battery</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Wireless
                                                                            outdoor Security Camera featuring 1080p HD
                                                                            Video with HDR</span></p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Accessories</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B0D47Z1SB9">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0D47Z1SB9?ref=MarsFS_VICC_blinkvin">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Blink Add-On Sync Module 2"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2024/vicc/blnk/fs-syncmodule2.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Blink
                                                                            Add-On Sync Module 2</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Control
                                                                            all of your Blink devices from the Blink
                                                                            Home Monitor app</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B08DJC1KMJ">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B08DJC1KMJ?ref=MarsFS_VICC_rvdpro2_faceplate">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Video Doorbell Pro 2 Faceplate"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2021/launch/ring/mr/faceplates_fs_300x300.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Video Doorbell Pro 2 Faceplate</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Customise
                                                                            your security with a coloured
                                                                            faceplate</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B08LZ3LTFV">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B08LZ3LTFV?ref=MarsFS_VICC_rvdwired_cornerkit">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Video Doorbell Wired Corner Kit"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2021/launch/ring/gc/B08LZ3LTFV_300x300.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Video Doorbell Wired Corner Kit</span>
                                                                    </p>

                                                                    <p class="element-description element-data"><span class="a-size-small a-color-base">Tilt
                                                                            your Doorbell Wired towards your walkway for
                                                                            improved motion</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B09L462YVZ">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B09L462YVZ?ref=MarsFS_VICC_CHIME">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Chime"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2020/vicc/an_chime.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Chime</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Hear
                                                                            alerts loud and clear</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B0D3RN5W37">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0D3RN5W37?ref=MarsFS_VICC_blinksqm">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Blink Weather Resistant 4m Power Adaptor"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2024/vicc/blnk/fs-squam.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="fs-new-product-tag a-text-italic">NEW</span>

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Blink
                                                                            Weather Resistant 4m Power Adaptor</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Weather
                                                                            Resistant Power Adaptor enables Blink Mini 2
                                                                            for outdoor use and provides nonstop plug-in
                                                                            power for Blink Outdoor 4.</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B076JKHDQT">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B076JKHDQT?ref=MarsFS_VICC_Ring+Rechargeable+Battery+Pack">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Ring Rechargeable Battery Pack"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2023/event/ringcam.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Ring
                                                                            Rechargeable Battery Pack</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Ring
                                                                            Rechargeable Battery Pack</span></p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>



                                                    </ol>
                                                </div>
                                            </div>
                                            <div class="a-carousel-col a-carousel-right"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-nextpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-next"><span class="a-icon-alt">Next
                                                                page</span></i></span></a></div>
                                        </div>
                                    </div>
                                    <span class="a-end aok-hidden"></span>
                                </div>
                            </span>

                            <span class="a-declarative" data-action="mars-fs-hover" data-csa-c-type="widget"
                                data-csa-c-func-deps="aui-da-mars-fs-hover"
                                data-mars-fs-hover="{&quot;familyCode&quot;:&quot;eero&quot;}">
                                <div id="eero_carousel" data-a-carousel-options="{}" data-familyCode="eero" role="group"
                                    class="a-begin a-carousel-container a-carousel-static a-carousel-display-stretchyGoodness a-carousel-transition-slide family">
                                    <input autocomplete="on" type="hidden" class="a-carousel-firstvisibleitem" />
                                    <div class="a-row a-carousel-controls a-carousel-row a-carousel-has-buttons">
                                        <div class="a-carousel-row-inner">
                                            <div class="a-carousel-col a-carousel-left"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-prevpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-previous"><span
                                                                class="a-icon-alt">Previous page</span></i></span></a>
                                            </div>
                                            <div class="a-carousel-col a-carousel-center">
                                                <div class="a-carousel-viewport" role="group" aria-roledescription="">
                                                    <ol class="a-carousel">









                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Wi-Fi
                                                                    5</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B085PVB5BP">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B085PVB5BP?ref=MarsFS_eero_c">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero mesh Wi-Fi router"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://images-eu.ssl-images-amazon.com/images/G/02/kindle/merch/2019/campaign/09079/merch/2460-FamilyStripe-uk-250x170.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero mesh Wi-Fi router</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Fast,
                                                                            stand-alone router or extender</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B085Q2ZF1X">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B085Q2ZF1X?ref=MarsFS_eero_ccc">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero mesh Wi-Fi router  (3-pack)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/02/kindle/merch/2019/VICC/eero/CCC_FS.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero mesh Wi-Fi router (3-pack)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Whole-home
                                                                            wifi coverage for all your devices</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Wi-Fi
                                                                    6</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B086PFKYVH">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B086PFKYVH?ref=MarsFS_eero_AG">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero 6 mesh wifi router"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2021/eero/fm_1.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero 6 mesh wifi router</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Fast,
                                                                            reliable Wi-Fi 6</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B086PGZRGK">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B086PGZRGK?ref=MarsFS_eero_AGALAL">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero 6 mesh wifi system (3-pack)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/kindle/merch/2021/eero/fm_3.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero 6 mesh wifi system (3-pack)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Wi-Fi 6
                                                                            router and 2 extenders</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B091G4D95D">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B091G4D95D?ref=MarsFS_eero_en">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero Pro 6E mesh Wi-Fi router"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/01/kindle/journeys/MzA4NWUwNTct/MzA4NWUwNTct-YTFiNTQwMjQt-w125._CB404658747_.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero Pro 6E mesh Wi-Fi router</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Get up
                                                                            to speed with Wi-Fi 6E</span>
                                                                    </p><p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B08ZJVVMT4">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B08ZJVVMT4?ref=MarsFS_eero_en">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero 6+ system (3-pack)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/01/kindle/journeys/YjJkZWQ0NTgt/2/FFF_ATF_02_D._CB625557728_.jpg" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero 6+ system (3-pack)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">eero's
                                                                            most affordable gigabit system</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>

                                                        <li class="a-carousel-card asin non-current fs-card">

                                                            <div class="fs-link-wrapper" id="fs-card-B091G668JP">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B091G668JP?ref=MarsFS_eero_en">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero Pro 6E mesh Wi-Fi router (3-pack)"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/01/kindle/journeys/MzA4NWUwNTct/MzA4NWUwNTct-NTFkOTZjMmMt-w125._CB404681392_.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero Pro 6E mesh Wi-Fi router
                                                                            (3-pack)</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span class="a-size-small a-color-base">Cover up
                                                                            to 560 sq. m., with support for gigabit+
                                                                            speeds</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>











                                                        <li
                                                            class="a-carousel-card asin non-current fs-card first-fs-card">

                                                            <div class="fs-group-wrapper">
                                                                <span
                                                                    class="a-size-base a-color-secondary fs-group-header a-text-bold">Wi-Fi
                                                                    7</span>
                                                            </div>

                                                            <div class="fs-link-wrapper" id="fs-card-B0CPKX85TD">
                                                                <a class="a-link-normal fs-links"
                                                                    href="/dp/B0CPKX85TD?ref=MarsFS_eero_JU">
                                                                    <div class="image-wrapper element-data">


                                                                        <img alt="Amazon eero Max 7"
                                                                            src="https://m.media-amazon.com/images/G/35/kindle/mako/features/mars-family-stripe/assets/lazy-load-placeholder._CB404760518_.png"
                                                                            class="fs-asin-images fs-images fs-image-lazy-loading"
                                                                            data-a-hires="https://m.media-amazon.com/images/G/35/AU-OX-Team/BAU/JU_UK_125x85_FamilyStripe-Desktop-125x85.png" />



                                                                    </div>
                                                                    <p class="element-name element-data">

                                                                        <span
                                                                            class="a-size-small a-color-secondary a-text-bold">Amazon
                                                                            eero Max 7</span>
                                                                    </p>

                                                                    <p class="element-description element-data">
                                                                        <span
                                                                            class="a-size-small a-color-base">Description-
                                                                            a whole new level of fast</span>
                                                                    </p>

                                                                    <p class="element-price element-data"></p>
                                                                </a>
                                                            </div>
                                                        </li>



                                                    </ol>
                                                </div>
                                            </div>
                                            <div class="a-carousel-col a-carousel-right"><a
                                                    class="a-button a-button-image a-carousel-button a-carousel-goto-nextpage"
                                                    tabindex="0" href="#"><span class="a-button-inner"><i
                                                            class="a-icon a-icon-next"><span class="a-icon-alt">Next
                                                                page</span></i></span></a></div>
                                        </div>
                                    </div>
                                    <span class="a-end aok-hidden"></span>
                                </div>
                            </span>

                        </div>









                        <div id="mars-fs-templates">
                            <script data-name="price" type="text/template">
        <div class="a-section a-spacing-none a-spacing-top-small a-text-center">
            {! if (isParent) { !}
                <span class="a-size-small a-color-secondary fs-price-prefix">From: </span>
            {! } !}
            <span class="a-size-base-plus a-color-price fs-buying-price">{{price}}</span>
        </div>
    </script>
                            <script data-name="basisPrice" type="text/template">
        <div class="a-section a-spacing-none a-text-center">
            <span class="a-size-small a-color-secondary fs-basis-price-label">{{label}}</span>
            <span class="a-size-small a-color-secondary fs-basis-price a-text-strike">{{price}}</span>
        </div>
    </script>
                        </div>

                        <script type="text/javascript">(function (f) { var _np = (window.P._namespace("MarsFamilyStripe")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                P.when("MarsFamilyStripe.Templates").execute(function (templates) {
                                    templates.loadTemplates("#mars-fs-templates");
                                });
                            }));</script>


                        <script type="text/javascript">(function (f) { var _np = (window.P._namespace("MarsFamilyStripe")); if (_np.guardFatal) { _np.guardFatal(f)(_np); } else { f(_np); } }(function (P) {
                                P.when("MarsFamilyStripe").execute(function (MarsFamilyStripe) {
                                    MarsFamilyStripe.init({
                                        "familyAsins": {
                                            "eero": [
                                                "B08ZJVVMT4",
                                                "B086PGZRGK",
                                                "B086PFKYVH",
                                                "B0CPKX85TD",
                                                "B091G4D95D",
                                                "B085PVB5BP",
                                                "B085Q2ZF1X",
                                                "B091G668JP"
                                            ],
                                            "SMP": [
                                                "B0CJKV1J9N",
                                                "B0BTG4S29L",
                                                "B09TDTJKF1",
                                                "B0CQMZ24LR"
                                            ],
                                            "KINDLE": [
                                                "B0CFPHSTDD",
                                                "B0CP31QS6R",
                                                "B09BS5XWNS",
                                                "B0CZB5RHWX",
                                                "B0CFPL6CFY"
                                            ],
                                            "AUCC": [
                                                "B09B8YP8KY",
                                                "B0C2RXN77R",
                                                "B09WXH9BH7",
                                                "B0BLS3H65Z",
                                                "B09Y1GZR7T",
                                                "B084NTF5ZY",
                                                "B09B2RL8CG",
                                                "B085G63QHT",
                                                "B0BCR4YW51",
                                                "B07NQ7HNHY",
                                                "B08MQNGX3W"
                                            ],
                                            "VICC": [
                                                "B0B2BY4ZG7",
                                                "B09L462YVZ",
                                                "B0D47Z1SB9",
                                                "B0D483WX7X",
                                                "B09WZBPX7K",
                                                "B08DJC1KMJ",
                                                "B076JKHDQT",
                                                "B0B6GK4VTC",
                                                "B091D9R5XX",
                                                "B08LZ3LTFV",
                                                "B0C5QRZ47P",
                                                "B0CG2TPLJV",
                                                "B0D484S271",
                                                "B09DRX62ZV",
                                                "B0D3RN5W37",
                                                "B0BZWRSRWV"
                                            ]
                                        },
                                        "marketplaceId": "A39IBJ37TRP1C6",
                                        "csrfToken": "1@g6wcpKFLtZBzlqViJ7pkTEV0Qyp8mD2pSv3pZZnSVJUcAAAAAQAAAABnKu6wcmF3AAAAAGfA1H5nd8xGEcC3ybgBQA\u003d\u003d@E6TAKA",
                                        "endpoint": "data.amazon.com.au",
                                        "language": "en-AU",
                                        "invalidImageAsins": [
                                            "B0CJKV1J9N",
                                            "B0CFPHSTDD",
                                            "B0BTG4S29L",
                                            "B0CZB5RHWX",
                                            "B09TDTJKF1",
                                            "B0BCR4YW51",
                                            "B0CFPL6CFY"
                                        ]
                                    });
                                });
                            }));</script>

                        <script>
                            (function () {
                                var performance = window.performance;
                                var isApiSupported = performance && performance.mark && performance.measure && performance.getEntriesByName;
                                if (!isApiSupported) {

                                    return;
                                }

                                var key = 'family-stripe-widget:1.0'
                                performance.mark(key + ':be');

                                var entry = key + ':clientBodyBeginToEnd';
                                performance.measure(entry, key + ':bb', key + ':be');

                                varentries = performance.getEntriesByName(entry);
                                if (entries.length === 0) {
                                    return;
                                }

                                entries = entries.splice(entries.length - 1, 1);
                                var duration = entries[0].duration;
                                if (window.ue) {
                                    window.ue.count(entry, duration);
                                }
                            })();
                        </script>
                    </div>
                </div>
                <div id="btfMVT3_feature_div" class="celwidget" data-feature-name="btfMVT3" data-csa-c-type="widget"
                    data-csa-c-content-id="btfMVT3" data-csa-c-slot-id="btfMVT3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-center-6_feature_div" class="celwidget" data-feature-name="btf-center-6"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-6"
                    data-csa-c-slot-id="btf-center-6_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-7_feature_div" class="celwidget" data-feature-name="btf-center-7"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-7"
                    data-csa-c-slot-id="btf-center-7_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-8_feature_div" class="celwidget" data-feature-name="btf-center-8"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-8"
                    data-csa-c-slot-id="btf-center-8_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-9_feature_div" class="celwidget" data-feature-name="btf-center-9"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-9"
                    data-csa-c-slot-id="btf-center-9_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-10_feature_div" class="celwidget" data-feature-name="btf-center-10"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-10"
                    data-csa-c-slot-id="btf-center-10_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent1_feature_div" class="celwidget" data-feature-name="btfContent1"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent1"
                    data-csa-c-slot-id="btfContent1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-1-m_feature_div" class="celwidget" data-feature-name="btf-content-1-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-1-m"
                    data-csa-c-slot-id="btf-content-1-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent2_feature_div" class="celwidget" data-feature-name="btfContent2"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent2"
                    data-csa-c-slot-id="btfContent2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-2-m_feature_div" class="celwidget" data-feature-name="btf-content-2-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-2-m"
                    data-csa-c-slot-id="btf-content-2-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent3_feature_div" class="celwidget" data-feature-name="btfContent3"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent3"
                    data-csa-c-slot-id="btfContent3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-3-m_feature_div" class="celwidget" data-feature-name="btf-content-3-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-3-m"
                    data-csa-c-slot-id="btf-content-3-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent4_feature_div" class="celwidget" data-feature-name="btfContent4"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent4"
                    data-csa-c-slot-id="btfContent4_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-4-m_feature_div" class="celwidget" data-feature-name="btf-content-4-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-4-m"
                    data-csa-c-slot-id="btf-content-4-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent5_feature_div" class="celwidget" data-feature-name="btfContent5"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent5"
                    data-csa-c-slot-id="btfContent5_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-5-m_feature_div" class="celwidget" data-feature-name="btf-content-5-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-5-m"
                    data-csa-c-slot-id="btf-content-5-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent6_feature_div" class="celwidget" data-feature-name="btfContent6"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent6"
                    data-csa-c-slot-id="btfContent6_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-6-m_feature_div" class="celwidget" data-feature-name="btf-content-6-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-6-m"
                    data-csa-c-slot-id="btf-content-6-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent7_feature_div" class="celwidget" data-feature-name="btfContent7"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent7"
                    data-csa-c-slot-id="btfContent7_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-7-m_feature_div" class="celwidget" data-feature-name="btf-content-7-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-7-m"
                    data-csa-c-slot-id="btf-content-7-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent8_feature_div" class="celwidget" data-feature-name="btfContent8"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent8"
                    data-csa-c-slot-id="btfContent8_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-8-m_feature_div" class="celwidget" data-feature-name="btf-content-8-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-8-m"
                    data-csa-c-slot-id="btf-content-8-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent9_feature_div" class="celwidget" data-feature-name="btfContent9"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent9"
                    data-csa-c-slot-id="btfContent9_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-9-m_feature_div" class="celwidget" data-feature-name="btf-content-9-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-9-m"
                    data-csa-c-slot-id="btf-content-9-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent10_feature_div" class="celwidget" data-feature-name="btfContent10"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent10"
                    data-csa-c-slot-id="btfContent10_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-10-m_feature_div" class="celwidget" data-feature-name="btf-content-10-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-10-m"
                    data-csa-c-slot-id="btf-content-10-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent11_feature_div" class="celwidget" data-feature-name="btfContent11"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent11"
                    data-csa-c-slot-id="btfContent11_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-11-m_feature_div" class="celwidget" data-feature-name="btf-content-11-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-11-m"
                    data-csa-c-slot-id="btf-content-11-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent12_feature_div" class="celwidget" data-feature-name="btfContent12"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent12"
                    data-csa-c-slot-id="btfContent12_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-12-m_feature_div" class="celwidget" data-feature-name="btf-content-12-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-12-m"
                    data-csa-c-slot-id="btf-content-12-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent13_feature_div" class="celwidget" data-feature-name="btfContent13"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent13"
                    data-csa-c-slot-id="btfContent13_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-13-m_feature_div" class="celwidget" data-feature-name="btf-content-13-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-13-m"
                    data-csa-c-slot-id="btf-content-13-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent14_feature_div" class="celwidget" data-feature-name="btfContent14"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent14"
                    data-csa-c-slot-id="btfContent14_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-14-m_feature_div" class="celwidget" data-feature-name="btf-content-14-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-14-m"
                    data-csa-c-slot-id="btf-content-14-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent15_feature_div" class="celwidget" data-feature-name="btfContent15"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent15"
                    data-csa-c-slot-id="btfContent15_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-15-m_feature_div" class="celwidget" data-feature-name="btf-content-15-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-15-m"
                    data-csa-c-slot-id="btf-content-15-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="red-regulation-content_feature_div" class="celwidget"
                    data-feature-name="red-regulation-content" data-csa-c-type="widget"
                    data-csa-c-content-id="red-regulation-content"
                    data-csa-c-slot-id="red-regulation-content_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent16_feature_div" class="celwidget" data-feature-name="btfContent16"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent16"
                    data-csa-c-slot-id="btfContent16_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-16-m_feature_div" class="celwidget" data-feature-name="btf-content-16-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-16-m"
                    data-csa-c-slot-id="btf-content-16-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent17_feature_div" class="celwidget" data-feature-name="btfContent17"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent17"
                    data-csa-c-slot-id="btfContent17_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-17-m_feature_div" class="celwidget" data-feature-name="btf-content-17-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-17-m"
                    data-csa-c-slot-id="btf-content-17-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent18_feature_div" class="celwidget" data-feature-name="btfContent18"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent18"
                    data-csa-c-slot-id="btfContent18_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-18-m_feature_div" class="celwidget" data-feature-name="btf-content-18-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-18-m"
                    data-csa-c-slot-id="btf-content-18-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent19_feature_div" class="celwidget" data-feature-name="btfContent19"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent19"
                    data-csa-c-slot-id="btfContent19_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-19-m_feature_div" class="celwidget" data-feature-name="btf-content-19-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-19-m"
                    data-csa-c-slot-id="btf-content-19-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent20_feature_div" class="celwidget" data-feature-name="btfContent20"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent20"
                    data-csa-c-slot-id="btfContent20_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-20-m_feature_div" class="celwidget" data-feature-name="btf-content-20-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-20-m"
                    data-csa-c-slot-id="btf-content-20-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent21_feature_div" class="celwidget" data-feature-name="btfContent21"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent21"
                    data-csa-c-slot-id="btfContent21_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-21-m_feature_div" class="celwidget" data-feature-name="btf-content-21-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-21-m"
                    data-csa-c-slot-id="btf-content-21-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent22_feature_div" class="celwidget" data-feature-name="btfContent22"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent22"
                    data-csa-c-slot-id="btfContent22_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-22-m_feature_div" class="celwidget" data-feature-name="btf-content-22-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-22-m"
                    data-csa-c-slot-id="btf-content-22-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent23_feature_div" class="celwidget" data-feature-name="btfContent23"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent23"
                    data-csa-c-slot-id="btfContent23_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-23-m_feature_div" class="celwidget" data-feature-name="btf-content-23-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-23-m"
                    data-csa-c-slot-id="btf-content-23-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent24_feature_div" class="celwidget" data-feature-name="btfContent24"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent24"
                    data-csa-c-slot-id="btfContent24_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-24-m_feature_div" class="celwidget" data-feature-name="btf-content-24-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-24-m"
                    data-csa-c-slot-id="btf-content-24-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent25_feature_div" class="celwidget" data-feature-name="btfContent25"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent25"
                    data-csa-c-slot-id="btfContent25_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-25-m_feature_div" class="celwidget" data-feature-name="btf-content-25-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-25-m"
                    data-csa-c-slot-id="btf-content-25-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfMVT4_feature_div" class="celwidget" data-feature-name="btfMVT4" data-csa-c-type="widget"
                    data-csa-c-content-id="btfMVT4" data-csa-c-slot-id="btfMVT4_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-center-11_feature_div" class="celwidget" data-feature-name="btf-center-11"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-11"
                    data-csa-c-slot-id="btf-center-11_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-12_feature_div" class="celwidget" data-feature-name="btf-center-12"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-12"
                    data-csa-c-slot-id="btf-center-12_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-13_feature_div" class="celwidget" data-feature-name="btf-center-13"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-13"
                    data-csa-c-slot-id="btf-center-13_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-14_feature_div" class="celwidget" data-feature-name="btf-center-14"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-14"
                    data-csa-c-slot-id="btf-center-14_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-15_feature_div" class="celwidget" data-feature-name="btf-center-15"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-15"
                    data-csa-c-slot-id="btf-center-15_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent26_feature_div" class="celwidget" data-feature-name="btfContent26"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent26"
                    data-csa-c-slot-id="btfContent26_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-26-m_feature_div" class="celwidget" data-feature-name="btf-content-26-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-26-m"
                    data-csa-c-slot-id="btf-content-26-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent27_feature_div" class="celwidget" data-feature-name="btfContent27"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent27"
                    data-csa-c-slot-id="btfContent27_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div><div id="btf-content-27-m_feature_div" class="celwidget" data-feature-name="btf-content-27-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-27-m"
                    data-csa-c-slot-id="btf-content-27-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent28_feature_div" class="celwidget" data-feature-name="btfContent28"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent28"
                    data-csa-c-slot-id="btfContent28_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-28-m_feature_div" class="celwidget" data-feature-name="btf-content-28-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-28-m"
                    data-csa-c-slot-id="btf-content-28-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent29_feature_div" class="celwidget" data-feature-name="btfContent29"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent29"
                    data-csa-c-slot-id="btfContent29_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-29-m_feature_div" class="celwidget" data-feature-name="btf-content-29-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-29-m"
                    data-csa-c-slot-id="btf-content-29-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent30_feature_div" class="celwidget" data-feature-name="btfContent30"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent30"
                    data-csa-c-slot-id="btfContent30_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-30-m_feature_div" class="celwidget" data-feature-name="btf-content-30-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-30-m"
                    data-csa-c-slot-id="btf-content-30-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent31_feature_div" class="celwidget" data-feature-name="btfContent31"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent31"
                    data-csa-c-slot-id="btfContent31_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-31-m_feature_div" class="celwidget" data-feature-name="btf-content-31-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-31-m"
                    data-csa-c-slot-id="btf-content-31-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent32_feature_div" class="celwidget" data-feature-name="btfContent32"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent32"
                    data-csa-c-slot-id="btfContent32_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-32-m_feature_div" class="celwidget" data-feature-name="btf-content-32-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-32-m"
                    data-csa-c-slot-id="btf-content-32-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent33_feature_div" class="celwidget" data-feature-name="btfContent33"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent33"
                    data-csa-c-slot-id="btfContent33_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-33-m_feature_div" class="celwidget" data-feature-name="btf-content-33-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-33-m"
                    data-csa-c-slot-id="btf-content-33-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent34_feature_div" class="celwidget" data-feature-name="btfContent34"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent34"
                    data-csa-c-slot-id="btfContent34_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-34-m_feature_div" class="celwidget" data-feature-name="btf-content-34-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-34-m"
                    data-csa-c-slot-id="btf-content-34-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent35_feature_div" class="celwidget" data-feature-name="btfContent35"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent35"
                    data-csa-c-slot-id="btfContent35_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-35-m_feature_div" class="celwidget" data-feature-name="btf-content-35-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-35-m"
                    data-csa-c-slot-id="btf-content-35-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent36_feature_div" class="celwidget" data-feature-name="btfContent36"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent36"
                    data-csa-c-slot-id="btfContent36_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-36-m_feature_div" class="celwidget" data-feature-name="btf-content-36-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-36-m"
                    data-csa-c-slot-id="btf-content-36-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent37_feature_div" class="celwidget" data-feature-name="btfContent37"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent37"
                    data-csa-c-slot-id="btfContent37_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-37-m_feature_div" class="celwidget" data-feature-name="btf-content-37-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-37-m"
                    data-csa-c-slot-id="btf-content-37-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent38_feature_div" class="celwidget" data-feature-name="btfContent38"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent38"
                    data-csa-c-slot-id="btfContent38_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-38-m_feature_div" class="celwidget" data-feature-name="btf-content-38-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-38-m"
                    data-csa-c-slot-id="btf-content-38-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent39_feature_div" class="celwidget" data-feature-name="btfContent39"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent39"
                    data-csa-c-slot-id="btfContent39_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-39-m_feature_div" class="celwidget" data-feature-name="btf-content-39-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-39-m"
                    data-csa-c-slot-id="btf-content-39-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent40_feature_div" class="celwidget" data-feature-name="btfContent40"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent40"
                    data-csa-c-slot-id="btfContent40_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-40-m_feature_div" class="celwidget" data-feature-name="btf-content-40-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-40-m"
                    data-csa-c-slot-id="btf-content-40-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent41_feature_div" class="celwidget" data-feature-name="btfContent41"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent41"
                    data-csa-c-slot-id="btfContent41_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-41-m_feature_div" class="celwidget" data-feature-name="btf-content-41-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-41-m"
                    data-csa-c-slot-id="btf-content-41-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent42_feature_div" class="celwidget" data-feature-name="btfContent42"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent42"
                    data-csa-c-slot-id="btfContent42_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-42-m_feature_div" class="celwidget" data-feature-name="btf-content-42-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-42-m"
                    data-csa-c-slot-id="btf-content-42-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent43_feature_div" class="celwidget" data-feature-name="btfContent43"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent43"
                    data-csa-c-slot-id="btfContent43_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-43-m_feature_div" class="celwidget" data-feature-name="btf-content-43-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-43-m"
                    data-csa-c-slot-id="btf-content-43-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent44_feature_div" class="celwidget" data-feature-name="btfContent44"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent44"
                    data-csa-c-slot-id="btfContent44_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-44-m_feature_div" class="celwidget" data-feature-name="btf-content-44-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-44-m"
                    data-csa-c-slot-id="btf-content-44-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent45_feature_div" class="celwidget" data-feature-name="btfContent45"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent45"
                    data-csa-c-slot-id="btfContent45_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-45-m_feature_div" class="celwidget" data-feature-name="btf-content-45-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-45-m"
                    data-csa-c-slot-id="btf-content-45-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent46_feature_div" class="celwidget" data-feature-name="btfContent46"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent46"
                    data-csa-c-slot-id="btfContent46_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-46-m_feature_div" class="celwidget" data-feature-name="btf-content-46-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-46-m"
                    data-csa-c-slot-id="btf-content-46-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btfContent47_feature_div" class="celwidget" data-feature-name="btfContent47"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent47"
                    data-csa-c-slot-id="btfContent47_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-47-m_feature_div" class="celwidget" data-feature-name="btf-content-47-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-47-m"
                    data-csa-c-slot-id="btf-content-47-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent48_feature_div" class="celwidget" data-feature-name="btfContent48"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent48"
                    data-csa-c-slot-id="btfContent48_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-48-m_feature_div" class="celwidget" data-feature-name="btf-content-48-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-48-m"
                    data-csa-c-slot-id="btf-content-48-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent49_feature_div" class="celwidget" data-feature-name="btfContent49"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent49"
                    data-csa-c-slot-id="btfContent49_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-49-m_feature_div" class="celwidget" data-feature-name="btf-content-49-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-49-m"
                    data-csa-c-slot-id="btf-content-49-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent50_feature_div" class="celwidget" data-feature-name="btfContent50"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent50"
                    data-csa-c-slot-id="btfContent50_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-50-m_feature_div" class="celwidget" data-feature-name="btf-content-50-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-50-m"
                    data-csa-c-slot-id="btf-content-50-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-16_feature_div" class="celwidget" data-feature-name="btf-center-16"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-16"
                    data-csa-c-slot-id="btf-center-16_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-17_feature_div" class="celwidget" data-feature-name="btf-center-17"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-17"
                    data-csa-c-slot-id="btf-center-17_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-18_feature_div" class="celwidget" data-feature-name="btf-center-18"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-18"
                    data-csa-c-slot-id="btf-center-18_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-19_feature_div" class="celwidget" data-feature-name="btf-center-19"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-19"
                    data-csa-c-slot-id="btf-center-19_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-20_feature_div" class="celwidget" data-feature-name="btf-center-20"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-20"
                    data-csa-c-slot-id="btf-center-20_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-21_feature_div" class="celwidget" data-feature-name="btf-center-21"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-21"
                    data-csa-c-slot-id="btf-center-21_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-22_feature_div" class="celwidget" data-feature-name="btf-center-22"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-22"
                    data-csa-c-slot-id="btf-center-22_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-23_feature_div" class="celwidget" data-feature-name="btf-center-23"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-23"
                    data-csa-c-slot-id="btf-center-23_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-24_feature_div" class="celwidget" data-feature-name="btf-center-24"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-24"
                    data-csa-c-slot-id="btf-center-24_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btf-center-25_feature_div" class="celwidget" data-feature-name="btf-center-25"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-center-25"
                    data-csa-c-slot-id="btf-center-25_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent51_feature_div" class="celwidget" data-feature-name="btfContent51"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent51"
                    data-csa-c-slot-id="btfContent51_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-51-m_feature_div" class="celwidget" data-feature-name="btf-content-51-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-51-m"
                    data-csa-c-slot-id="btf-content-51-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent52_feature_div" class="celwidget" data-feature-name="btfContent52"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent52"
                    data-csa-c-slot-id="btfContent52_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-52-m_feature_div" class="celwidget" data-feature-name="btf-content-52-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-52-m"
                    data-csa-c-slot-id="btf-content-52-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent53_feature_div" class="celwidget" data-feature-name="btfContent53"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent53"
                    data-csa-c-slot-id="btfContent53_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-53-m_feature_div" class="celwidget" data-feature-name="btf-content-53-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-53-m"
                    data-csa-c-slot-id="btf-content-53-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent54_feature_div" class="celwidget" data-feature-name="btfContent54"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent54"
                    data-csa-c-slot-id="btfContent54_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-54-m_feature_div" class="celwidget" data-feature-name="btf-content-54-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-54-m"
                    data-csa-c-slot-id="btf-content-54-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent55_feature_div" class="celwidget" data-feature-name="btfContent55"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent55"
                    data-csa-c-slot-id="btfContent55_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-55-m_feature_div" class="celwidget" data-feature-name="btf-content-55-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-55-m"
                    data-csa-c-slot-id="btf-content-55-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent56_feature_div" class="celwidget" data-feature-name="btfContent56"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent56"
                    data-csa-c-slot-id="btfContent56_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-56-m_feature_div" class="celwidget" data-feature-name="btf-content-56-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-56-m"
                    data-csa-c-slot-id="btf-content-56-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent57_feature_div" class="celwidget" data-feature-name="btfContent57"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent57"
                    data-csa-c-slot-id="btfContent57_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-57-m_feature_div" class="celwidget" data-feature-name="btf-content-57-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-57-m"
                    data-csa-c-slot-id="btf-content-57-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent58_feature_div" class="celwidget" data-feature-name="btfContent58"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent58"
                    data-csa-c-slot-id="btfContent58_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-58-m_feature_div" class="celwidget" data-feature-name="btf-content-58-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-58-m"
                    data-csa-c-slot-id="btf-content-58-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent59_feature_div" class="celwidget" data-feature-name="btfContent59"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent59"
                    data-csa-c-slot-id="btfContent59_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-59-m_feature_div" class="celwidget" data-feature-name="btf-content-59-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-59-m"
                    data-csa-c-slot-id="btf-content-59-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent60_feature_div" class="celwidget" data-feature-name="btfContent60"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent60"
                    data-csa-c-slot-id="btfContent60_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-60-m_feature_div" class="celwidget" data-feature-name="btf-content-60-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-60-m"
                    data-csa-c-slot-id="btf-content-60-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent61_feature_div" class="celwidget" data-feature-name="btfContent61"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent61"
                    data-csa-c-slot-id="btfContent61_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-61-m_feature_div" class="celwidget" data-feature-name="btf-content-61-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-61-m"
                    data-csa-c-slot-id="btf-content-61-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent62_feature_div" class="celwidget" data-feature-name="btfContent62"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent62"
                    data-csa-c-slot-id="btfContent62_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-62-m_feature_div" class="celwidget" data-feature-name="btf-content-62-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-62-m"
                    data-csa-c-slot-id="btf-content-62-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent63_feature_div" class="celwidget" data-feature-name="btfContent63"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent63"
                    data-csa-c-slot-id="btfContent63_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-63-m_feature_div" class="celwidget" data-feature-name="btf-content-63-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-63-m"
                    data-csa-c-slot-id="btf-content-63-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent64_feature_div" class="celwidget" data-feature-name="btfContent64"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent64"
                    data-csa-c-slot-id="btfContent64_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-64-m_feature_div" class="celwidget" data-feature-name="btf-content-64-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-64-m"
                    data-csa-c-slot-id="btf-content-64-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfContent65_feature_div" class="celwidget" data-feature-name="btfContent65"
                    data-csa-c-type="widget" data-csa-c-content-id="btfContent65"
                    data-csa-c-slot-id="btfContent65_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="btf-content-65-m_feature_div" class="celwidget" data-feature-name="btf-content-65-m"
                    data-csa-c-type="widget" data-csa-c-content-id="btf-content-65-m"
                    data-csa-c-slot-id="btf-content-65-m_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="btfMVT5_feature_div" class="celwidget" data-feature-name="btfMVT5" data-csa-c-type="widget"
                    data-csa-c-content-id="btfMVT5" data-csa-c-slot-id="btfMVT5_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-17_feature_div" class="celwidget" data-feature-name="center-17" data-csa-c-type="widget"
                    data-csa-c-content-id="center-17" data-csa-c-slot-id="center-17_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-17-0_feature_div" class="celwidget" data-feature-name="center-17-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-17-0"
                    data-csa-c-slot-id="center-17-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-17-1_feature_div" class="celwidget" data-feature-name="center-17-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-17-1"
                    data-csa-c-slot-id="center-17-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-17-2_feature_div" class="celwidget" data-feature-name="center-17-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-17-2"
                    data-csa-c-slot-id="center-17-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-17-3_feature_div" class="celwidget" data-feature-name="center-17-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-17-3"
                    data-csa-c-slot-id="center-17-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-18_feature_div" class="celwidget" data-feature-name="center-18" data-csa-c-type="widget"
                    data-csa-c-content-id="center-18" data-csa-c-slot-id="center-18_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-18-0_feature_div" class="celwidget" data-feature-name="center-18-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-18-0"
                    data-csa-c-slot-id="center-18-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-18-1_feature_div" class="celwidget" data-feature-name="center-18-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-18-1"
                    data-csa-c-slot-id="center-18-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-18-2_feature_div" class="celwidget" data-feature-name="center-18-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-18-2"
                    data-csa-c-slot-id="center-18-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-18-3_feature_div" class="celwidget" data-feature-name="center-18-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-18-3"
                    data-csa-c-slot-id="center-18-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-19_feature_div" class="celwidget" data-feature-name="center-19" data-csa-c-type="widget"
                    data-csa-c-content-id="center-19" data-csa-c-slot-id="center-19_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-19-0_feature_div" class="celwidget" data-feature-name="center-19-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-19-0"
                    data-csa-c-slot-id="center-19-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-19-1_feature_div" class="celwidget" data-feature-name="center-19-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-19-1"
                    data-csa-c-slot-id="center-19-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-19-2_feature_div" class="celwidget" data-feature-name="center-19-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-19-2"
                    data-csa-c-slot-id="center-19-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-19-3_feature_div" class="celwidget" data-feature-name="center-19-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-19-3"
                    data-csa-c-slot-id="center-19-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-20_feature_div" class="celwidget" data-feature-name="center-20" data-csa-c-type="widget"
                    data-csa-c-content-id="center-20" data-csa-c-slot-id="center-20_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-20-0_feature_div" class="celwidget" data-feature-name="center-20-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-20-0"
                    data-csa-c-slot-id="center-20-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-20-1_feature_div" class="celwidget" data-feature-name="center-20-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-20-1"
                    data-csa-c-slot-id="center-20-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-20-2_feature_div" class="celwidget" data-feature-name="center-20-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-20-2"
                    data-csa-c-slot-id="center-20-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-20-3_feature_div" class="celwidget" data-feature-name="center-20-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-20-3"
                    data-csa-c-slot-id="center-20-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-21_feature_div" class="celwidget" data-feature-name="center-21" data-csa-c-type="widget"
                    data-csa-c-content-id="center-21" data-csa-c-slot-id="center-21_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-21-0_feature_div" class="celwidget" data-feature-name="center-21-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-21-0"
                    data-csa-c-slot-id="center-21-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-21-1_feature_div" class="celwidget" data-feature-name="center-21-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-21-1"
                    data-csa-c-slot-id="center-21-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-21-2_feature_div" class="celwidget" data-feature-name="center-21-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-21-2"
                    data-csa-c-slot-id="center-21-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-21-3_feature_div" class="celwidget" data-feature-name="center-21-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-21-3"
                    data-csa-c-slot-id="center-21-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-22_feature_div" class="celwidget" data-feature-name="center-22" data-csa-c-type="widget"
                    data-csa-c-content-id="center-22" data-csa-c-slot-id="center-22_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-22-0_feature_div" class="celwidget" data-feature-name="center-22-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-22-0"
                    data-csa-c-slot-id="center-22-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-22-1_feature_div" class="celwidget" data-feature-name="center-22-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-22-1"
                    data-csa-c-slot-id="center-22-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-22-2_feature_div" class="celwidget" data-feature-name="center-22-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-22-2"
                    data-csa-c-slot-id="center-22-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-22-3_feature_div" class="celwidget" data-feature-name="center-22-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-22-3"
                    data-csa-c-slot-id="center-22-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-23_feature_div" class="celwidget" data-feature-name="center-23" data-csa-c-type="widget"
                    data-csa-c-content-id="center-23" data-csa-c-slot-id="center-23_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-23-0_feature_div" class="celwidget" data-feature-name="center-23-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-23-0"
                    data-csa-c-slot-id="center-23-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-23-1_feature_div" class="celwidget" data-feature-name="center-23-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-23-1"
                    data-csa-c-slot-id="center-23-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-23-2_feature_div" class="celwidget" data-feature-name="center-23-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-23-2"
                    data-csa-c-slot-id="center-23-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-23-3_feature_div" class="celwidget" data-feature-name="center-23-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-23-3"
                    data-csa-c-slot-id="center-23-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-24_feature_div" class="celwidget" data-feature-name="center-24" data-csa-c-type="widget"
                    data-csa-c-content-id="center-24" data-csa-c-slot-id="center-24_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-24-0_feature_div" class="celwidget" data-feature-name="center-24-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-24-0"
                    data-csa-c-slot-id="center-24-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-24-1_feature_div" class="celwidget" data-feature-name="center-24-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-24-1"
                    data-csa-c-slot-id="center-24-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-24-2_feature_div" class="celwidget" data-feature-name="center-24-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-24-2"
                    data-csa-c-slot-id="center-24-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-24-3_feature_div" class="celwidget" data-feature-name="center-24-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-24-3"
                    data-csa-c-slot-id="center-24-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-25_feature_div" class="celwidget" data-feature-name="center-25" data-csa-c-type="widget"
                    data-csa-c-content-id="center-25" data-csa-c-slot-id="center-25_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-25-0_feature_div" class="celwidget" data-feature-name="center-25-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-25-0"
                    data-csa-c-slot-id="center-25-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-25-1_feature_div" class="celwidget" data-feature-name="center-25-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-25-1"
                    data-csa-c-slot-id="center-25-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-25-2_feature_div" class="celwidget" data-feature-name="center-25-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-25-2"
                    data-csa-c-slot-id="center-25-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-25-3_feature_div" class="celwidget" data-feature-name="center-25-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-25-3"
                    data-csa-c-slot-id="center-25-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-26_feature_div" class="celwidget" data-feature-name="center-26" data-csa-c-type="widget"
                    data-csa-c-content-id="center-26" data-csa-c-slot-id="center-26_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-26-0_feature_div" class="celwidget" data-feature-name="center-26-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-26-0"
                    data-csa-c-slot-id="center-26-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-26-1_feature_div" class="celwidget" data-feature-name="center-26-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-26-1"
                    data-csa-c-slot-id="center-26-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-26-2_feature_div" class="celwidget" data-feature-name="center-26-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-26-2"
                    data-csa-c-slot-id="center-26-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-26-3_feature_div" class="celwidget" data-feature-name="center-26-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-26-3"
                    data-csa-c-slot-id="center-26-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-27_feature_div" class="celwidget" data-feature-name="center-27" data-csa-c-type="widget"
                    data-csa-c-content-id="center-27" data-csa-c-slot-id="center-27_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-27-0_feature_div" class="celwidget" data-feature-name="center-27-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-27-0"
                    data-csa-c-slot-id="center-27-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-27-1_feature_div" class="celwidget" data-feature-name="center-27-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-27-1"
                    data-csa-c-slot-id="center-27-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-27-2_feature_div" class="celwidget" data-feature-name="center-27-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-27-2"
                    data-csa-c-slot-id="center-27-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-27-3_feature_div" class="celwidget" data-feature-name="center-27-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-27-3"
                    data-csa-c-slot-id="center-27-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-28_feature_div" class="celwidget" data-feature-name="center-28" data-csa-c-type="widget"
                    data-csa-c-content-id="center-28" data-csa-c-slot-id="center-28_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-28-0_feature_div" class="celwidget" data-feature-name="center-28-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-28-0"
                    data-csa-c-slot-id="center-28-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-28-1_feature_div" class="celwidget" data-feature-name="center-28-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-28-1"
                    data-csa-c-slot-id="center-28-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-28-2_feature_div" class="celwidget" data-feature-name="center-28-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-28-2"
                    data-csa-c-slot-id="center-28-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-28-3_feature_div" class="celwidget" data-feature-name="center-28-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-28-3"
                    data-csa-c-slot-id="center-28-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-28-3_feature_div">


                        <div id="center-28-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-29_feature_div" class="celwidget" data-feature-name="center-29" data-csa-c-type="widget"
                    data-csa-c-content-id="center-29" data-csa-c-slot-id="center-29_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-29-0_feature_div" class="celwidget" data-feature-name="center-29-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-29-0"
                    data-csa-c-slot-id="center-29-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-29-1_feature_div" class="celwidget" data-feature-name="center-29-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-29-1"
                    data-csa-c-slot-id="center-29-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-29-1_feature_div">


                        <div id="center-29-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-29-2_feature_div" class="celwidget" data-feature-name="center-29-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-29-2"
                    data-csa-c-slot-id="center-29-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-29-3_feature_div" class="celwidget" data-feature-name="center-29-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-29-3"
                    data-csa-c-slot-id="center-29-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-30_feature_div" class="celwidget" data-feature-name="center-30" data-csa-c-type="widget"
                    data-csa-c-content-id="center-30" data-csa-c-slot-id="center-30_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-30-0_feature_div" class="celwidget" data-feature-name="center-30-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-30-0"
                    data-csa-c-slot-id="center-30-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-30-0_feature_div">


                        <div id="center-30-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-30-1_feature_div" class="celwidget" data-feature-name="center-30-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-30-1"
                    data-csa-c-slot-id="center-30-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-30-1_feature_div">


                        <div id="center-30-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-30-2_feature_div" class="celwidget" data-feature-name="center-30-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-30-2"
                    data-csa-c-slot-id="center-30-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-30-2_feature_div">


                        <div id="center-30-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-30-3_feature_div" class="celwidget" data-feature-name="center-30-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-30-3"
                    data-csa-c-slot-id="center-30-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-30-3_feature_div">


                        <div id="center-30-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-31_feature_div" class="celwidget" data-feature-name="center-31" data-csa-c-type="widget"
                    data-csa-c-content-id="center-31" data-csa-c-slot-id="center-31_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-31-0_feature_div" class="celwidget" data-feature-name="center-31-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-31-0"
                    data-csa-c-slot-id="center-31-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-31-1_feature_div" class="celwidget" data-feature-name="center-31-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-31-1"
                    data-csa-c-slot-id="center-31-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-31-1_feature_div">


                        <div id="center-31-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-31-2_feature_div" class="celwidget" data-feature-name="center-31-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-31-2"
                    data-csa-c-slot-id="center-31-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-31-2_feature_div">


                        <div id="center-31-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-31-3_feature_div" class="celwidget" data-feature-name="center-31-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-31-3"
                    data-csa-c-slot-id="center-31-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-31-3_feature_div">


                        <div id="center-31-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-32_feature_div" class="celwidget" data-feature-name="center-32" data-csa-c-type="widget"
                    data-csa-c-content-id="center-32" data-csa-c-slot-id="center-32_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-32-0_feature_div" class="celwidget" data-feature-name="center-32-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-32-0"
                    data-csa-c-slot-id="center-32-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-32-0_feature_div">


                        <div id="center-32-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-32-1_feature_div" class="celwidget" data-feature-name="center-32-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-32-1"
                    data-csa-c-slot-id="center-32-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-32-1_feature_div">


                        <div id="center-32-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-32-2_feature_div" class="celwidget" data-feature-name="center-32-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-32-2"
                    data-csa-c-slot-id="center-32-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-32-2_feature_div">


                        <div id="center-32-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-32-3_feature_div" class="celwidget" data-feature-name="center-32-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-32-3"
                    data-csa-c-slot-id="center-32-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-32-3_feature_div">


                        <div id="center-32-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-33_feature_div" class="celwidget" data-feature-name="center-33" data-csa-c-type="widget"
                    data-csa-c-content-id="center-33" data-csa-c-slot-id="center-33_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-33-0_feature_div" class="celwidget" data-feature-name="center-33-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-33-0"
                    data-csa-c-slot-id="center-33-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-33-1_feature_div" class="celwidget" data-feature-name="center-33-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-33-1"
                    data-csa-c-slot-id="center-33-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-33-2_feature_div" class="celwidget" data-feature-name="center-33-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-33-2"
                    data-csa-c-slot-id="center-33-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-33-2_feature_div">


                        <div id="center-33-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-33-3_feature_div" class="celwidget" data-feature-name="center-33-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-33-3"
                    data-csa-c-slot-id="center-33-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-33-3_feature_div">


                        <div id="center-33-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-34_feature_div" class="celwidget" data-feature-name="center-34" data-csa-c-type="widget"
                    data-csa-c-content-id="center-34" data-csa-c-slot-id="center-34_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-34-0_feature_div" class="celwidget" data-feature-name="center-34-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-34-0"
                    data-csa-c-slot-id="center-34-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-34-1_feature_div" class="celwidget" data-feature-name="center-34-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-34-1"
                    data-csa-c-slot-id="center-34-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-34-1_feature_div">


                        <div id="center-34-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-34-2_feature_div" class="celwidget" data-feature-name="center-34-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-34-2"
                    data-csa-c-slot-id="center-34-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-34-3_feature_div" class="celwidget" data-feature-name="center-34-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-34-3"
                    data-csa-c-slot-id="center-34-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-34-3_feature_div">


                        <div id="center-34-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-35_feature_div" class="celwidget" data-feature-name="center-35" data-csa-c-type="widget"
                    data-csa-c-content-id="center-35" data-csa-c-slot-id="center-35_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-35-0_feature_div" class="celwidget" data-feature-name="center-35-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-35-0"
                    data-csa-c-slot-id="center-35-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-35-0_feature_div">


                        <div id="center-35-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-35-1_feature_div" class="celwidget" data-feature-name="center-35-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-35-1"
                    data-csa-c-slot-id="center-35-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-35-1_feature_div">


                        <div id="center-35-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-35-2_feature_div" class="celwidget" data-feature-name="center-35-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-35-2"
                    data-csa-c-slot-id="center-35-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-35-3_feature_div" class="celwidget" data-feature-name="center-35-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-35-3"
                    data-csa-c-slot-id="center-35-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-36_feature_div" class="celwidget" data-feature-name="center-36" data-csa-c-type="widget"
                    data-csa-c-content-id="center-36" data-csa-c-slot-id="center-36_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-36-0_feature_div" class="celwidget" data-feature-name="center-36-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-36-0"
                    data-csa-c-slot-id="center-36-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-36-0_feature_div">


                        <div id="center-36-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-36-1_feature_div" class="celwidget" data-feature-name="center-36-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-36-1"
                    data-csa-c-slot-id="center-36-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-36-2_feature_div" class="celwidget" data-feature-name="center-36-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-36-2"
                    data-csa-c-slot-id="center-36-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-36-2_feature_div">


                        <div id="center-36-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-36-3_feature_div" class="celwidget" data-feature-name="center-36-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-36-3"
                    data-csa-c-slot-id="center-36-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-37_feature_div" class="celwidget" data-feature-name="center-37" data-csa-c-type="widget"
                    data-csa-c-content-id="center-37" data-csa-c-slot-id="center-37_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-37_feature_div">


                        <div id="center-37_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-37-0_feature_div" class="celwidget" data-feature-name="center-37-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-37-0"
                    data-csa-c-slot-id="center-37-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-37-1_feature_div" class="celwidget" data-feature-name="center-37-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-37-1"
                    data-csa-c-slot-id="center-37-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-37-1_feature_div">


                        <div id="center-37-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-37-2_feature_div" class="celwidget" data-feature-name="center-37-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-37-2"
                    data-csa-c-slot-id="center-37-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-37-2_feature_div">


                        <div id="center-37-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-37-3_feature_div" class="celwidget" data-feature-name="center-37-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-37-3"
                    data-csa-c-slot-id="center-37-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-38_feature_div" class="celwidget" data-feature-name="center-38" data-csa-c-type="widget"
                    data-csa-c-content-id="center-38" data-csa-c-slot-id="center-38_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-38-0_feature_div" class="celwidget" data-feature-name="center-38-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-38-0"
                    data-csa-c-slot-id="center-38-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-38-0_feature_div">


                        <div id="center-38-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-38-1_feature_div" class="celwidget" data-feature-name="center-38-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-38-1"
                    data-csa-c-slot-id="center-38-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-38-1_feature_div">


                        <div id="center-38-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-38-2_feature_div" class="celwidget" data-feature-name="center-38-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-38-2"
                    data-csa-c-slot-id="center-38-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-38-3_feature_div" class="celwidget" data-feature-name="center-38-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-38-3"
                    data-csa-c-slot-id="center-38-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-38-3_feature_div">


                        <div id="center-38-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-39_feature_div" class="celwidget" data-feature-name="center-39" data-csa-c-type="widget"
                    data-csa-c-content-id="center-39" data-csa-c-slot-id="center-39_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-39_feature_div">


                        <div id="center-39_feature_div">
                        </div>
                    </div>



                </div>
                <div id="center-39-0_feature_div" class="celwidget" data-feature-name="center-39-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-39-0"
                    data-csa-c-slot-id="center-39-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-39-0_feature_div">


                        <div id="center-39-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-39-1_feature_div" class="celwidget" data-feature-name="center-39-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-39-1"
                    data-csa-c-slot-id="center-39-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-39-1_feature_div">


                        <div id="center-39-1_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-39-2_feature_div" class="celwidget" data-feature-name="center-39-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-39-2"
                    data-csa-c-slot-id="center-39-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-39-2_feature_div">


                        <div id="center-39-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-39-3_feature_div" class="celwidget" data-feature-name="center-39-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-39-3"
                    data-csa-c-slot-id="center-39-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-39-3_feature_div">


                        <div id="center-39-3_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-40_feature_div" class="celwidget" data-feature-name="center-40" data-csa-c-type="widget"
                    data-csa-c-content-id="center-40" data-csa-c-slot-id="center-40_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-40-0_feature_div" class="celwidget" data-feature-name="center-40-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-40-0"
                    data-csa-c-slot-id="center-40-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-40-1_feature_div" class="celwidget" data-feature-name="center-40-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-40-1"
                    data-csa-c-slot-id="center-40-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-40-2_feature_div" class="celwidget" data-feature-name="center-40-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-40-2"
                    data-csa-c-slot-id="center-40-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-40-3_feature_div" class="celwidget" data-feature-name="center-40-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-40-3"
                    data-csa-c-slot-id="center-40-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-41_feature_div" class="celwidget" data-feature-name="center-41" data-csa-c-type="widget"
                    data-csa-c-content-id="center-41" data-csa-c-slot-id="center-41_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-41-0_feature_div" class="celwidget" data-feature-name="center-41-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-41-0"
                    data-csa-c-slot-id="center-41-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-41-0_feature_div">


                        <div id="center-41-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-41-1_feature_div" class="celwidget" data-feature-name="center-41-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-41-1"
                    data-csa-c-slot-id="center-41-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-41-2_feature_div" class="celwidget" data-feature-name="center-41-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-41-2"
                    data-csa-c-slot-id="center-41-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-41-2_feature_div">


                        <div id="center-41-2_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-41-3_feature_div" class="celwidget" data-feature-name="center-41-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-41-3"
                    data-csa-c-slot-id="center-41-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-42_feature_div" class="celwidget" data-feature-name="center-42" data-csa-c-type="widget"
                    data-csa-c-content-id="center-42" data-csa-c-slot-id="center-42_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-42-0_feature_div" class="celwidget" data-feature-name="center-42-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-42-0"
                    data-csa-c-slot-id="center-42-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-42-1_feature_div" class="celwidget" data-feature-name="center-42-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-42-1"
                    data-csa-c-slot-id="center-42-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-42-2_feature_div" class="celwidget" data-feature-name="center-42-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-42-2"
                    data-csa-c-slot-id="center-42-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-42-3_feature_div" class="celwidget" data-feature-name="center-42-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-42-3"
                    data-csa-c-slot-id="center-42-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                </div>
                <div id="center-43_feature_div" class="celwidget" data-feature-name="center-43" data-csa-c-type="widget"
                    data-csa-c-content-id="center-43" data-csa-c-slot-id="center-43_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-43-0_feature_div" class="celwidget" data-feature-name="center-43-0"
                    data-csa-c-type="widget" data-csa-c-content-id="center-43-0"
                    data-csa-c-slot-id="center-43-0_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="center-43-0_feature_div">


                        <div id="center-43-0_feature_div">
                        </div>
                    </div>


                </div>
                <div id="center-43-1_feature_div" class="celwidget" data-feature-name="center-43-1"
                    data-csa-c-type="widget" data-csa-c-content-id="center-43-1"
                    data-csa-c-slot-id="center-43-1_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-43-2_feature_div" class="celwidget" data-feature-name="center-43-2"
                    data-csa-c-type="widget" data-csa-c-content-id="center-43-2"
                    data-csa-c-slot-id="center-43-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="center-43-3_feature_div" class="celwidget" data-feature-name="center-43-3"
                    data-csa-c-type="widget" data-csa-c-content-id="center-43-3"
                    data-csa-c-slot-id="center-43-3_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="climatePledgeFriendlyBTF_feature_div" class="celwidget"
                    data-feature-name="climatePledgeFriendlyBTF" data-csa-c-type="widget"
                    data-csa-c-content-id="climatePledgeFriendlyBTF"
                    data-csa-c-slot-id="climatePledgeFriendlyBTF_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                </div>
                <div id="discovery-and-inspiration_feature_div" class="celwidget"
                    data-feature-name="discovery-and-inspiration" data-csa-c-type="widget"
                    data-csa-c-content-id="discovery-and-inspiration"
                    data-csa-c-slot-id="discovery-and-inspiration_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">
                    <div cel_widget_id='sims-consolidated-1_csm_instrumentation_wrapper' class='celwidget'>










                        <div class="celwidget pd_rd_w-SqgX2 content-id-amzn1.sym.03ddb1c8-6b89-434c-8b87-c7c9b21dc1db pf_rd_p-03ddb1c8-6b89-434c-8b87-c7c9b21dc1db pf_rd_r-90G9DFKSFRKCQZ4KHD88 pd_rd_wg-eYgLz pd_rd_r-e7396f09-7e89-4f5e-be61-f31730ebc79f c-f"
                            cel_widget_id="p13n-desktop-sims-fbt_DPSims_0" data-csa-op-log-render=""
                            data-csa-c-content-id="amzn1.sym.03ddb1c8-6b89-434c-8b87-c7c9b21dc1db"
                            data-csa-c-slot-id="product-bundle-1" data-csa-c-type="widget"
                            data-csa-c-painter="p13n-desktop-sims-fbt-cards">
                            <script>if (window.mix_csa) { window.mix_csa('[cel_widget_id="p13n-desktop-sims-fbt_DPSims_0"]', '#CardInstanceWpfE4f9TXCga3vVyq2h3Jg')('mark', 'bb') }</script>
                            <script>if (window.uet) { window.uet('bb', 'p13n-desktop-sims-fbt_DPSims_0', { wb: 1 }) }</script>
                            <style>
                                [class*=cards-widget-qs-widget-override] [class*=qs-widget-table],
                                [class*=cards-widget-qs-widget-override] [id^=qs-widget-button-],
                                [class*=cards-widget-qs-widget-override][class*=qs-widget-container],
                                [id^=qs-widget-atc-button-] {
                                    width: 100%
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-1__1Fn1y {
                                    -webkit-line-clamp: 1;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-2__EWgCb {
                                    -webkit-line-clamp: 2;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-3__g3dy1 {
                                    -webkit-line-clamp: 3;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-4__2q2cc {
                                    -webkit-line-clamp: 4;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-5__2l-dX {
                                    -webkit-line-clamp: 5;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-6__28daG {
                                    -webkit-line-clamp: 6;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-7__1k_Mc {
                                    -webkit-line-clamp: 7;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-8__1yvsR {
                                    -webkit-line-clamp: 8;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-9__3Pofd {
                                    -webkit-line-clamp: 9;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_truncationStyles_p13n-sc-css-line-clamp-10__mY8_7 {
                                    -webkit-line-clamp: 10;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_price_p13n-sc-price__3mJ9Z {
                                    word-wrap: normal;
                                    overflow-x: hidden
                                }

                                ._p13n-desktop-sims-fbt_price_p13n-sc-price-animation-wrapper__3PzN2 {
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_prime_p13n-prime-badge__GVM4h {
                                    position: relative;
                                    top: 2px
                                }

                                ._p13n-desktop-sims-fbt_prime_afoPrimeBadge__2hU1d {
                                    position: relative;
                                    top: 1px
                                }

                                ._p13n-desktop-sims-fbt_prime_afoBadgeFlex__1qF-9 {
                                    display: -webkit-inline-box;
                                    display: -ms-inline-flexbox;
                                    display: inline-flex
                                }

                                ._p13n-desktop-sims-fbt_prime_afoBadgeRowWrapper__2ssMY {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column
                                }

                                ._p13n-desktop-sims-fbt_imageComponent_p13nImageComponent__2h-XX:-moz-loading {
                                    visibility: hidden
                                }

                                ._p13n-desktop-sims-fbt_imageComponent_autoScale__3FVNQ {
                                    height: 100%;
                                    -o-object-fit: contain;
                                    object-fit: contain
                                }

                                ._p13n-desktop-sims-fbt_style_inlineErrorDetails__1NBx- {
                                    margin-right: -2px;
                                    vertical-align: text-top
                                }

                                ._p13n-desktop-sims-fbt_style_spCSRFTreatment__-hwVO {
                                    display: none;
                                    visibility: hidden
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_sims-fbt-containter__2Cffh {
                                    margin: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_flex-fbt-container__3fI_9 {
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    left: -20px;
                                    margin: 0;
                                    padding: 4px 0 0;
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_fbt-card__1_smM {
                                    overflow: auto;
                                    position: relative
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_flex-fbt-container__3fI_9 {
                                    left: auto;
                                    right: -20px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_image-link__17L3C:focus {
                                    z-index: auto !important
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_detail-image-section__1Bw2r {
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_image-background__DVFnZ {
                                    -ms-flex-item-align: center;
                                    align-self: center;
                                    background-color: #f7f8f8;
                                    border-radius: .8rem;
                                    min-height: 0;
                                    padding: 8px 28px;
                                    position: relative;
                                    width: 100%
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_image-background__DVFnZ,
                                ._p13n-desktop-sims-fbt_fbt-desktop_image-display__2oZhY {
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_image-display__2oZhY {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    align-items: center;
                                    height: 100%;
                                    min-width: 0;
                                    mix-blend-mode: multiply;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_link-area__1VLAZ {
                                    -webkit-box-flex: 1;
                                    -ms-flex: 1 1;
                                    flex: 1 1;
                                    max-width: 140px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_image-display__2oZhY>:first-child {
                                    height: auto;
                                    -o-object-fit: contain;
                                    object-fit: contain;
                                    width: 100%}

                                ._p13n-desktop-sims-fbt_fbt-desktop_thumbnail-box__4jnIT {
                                    float: left;
                                    line-height: 116px;
                                    margin: 0 25px 0 0;
                                    padding-left: 10px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_thumbnail-box__4jnIT {
                                    float: right;
                                    line-height: 116px;
                                    margin: 0 0 0 25px;
                                    padding-right: 10px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_new-thumbnail-box__36bD3 {
                                    -webkit-box-flex: 1;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex: 1 1;
                                    flex: 1 1;
                                    margin: 0;
                                    max-width: 720px;
                                    min-width: 450px;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_two-item-thumbnail-box__jV2am {
                                    max-width: 480px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_new-detail-faceout-box___WyNy {
                                    -webkit-box-flex: 0;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex: 0 1 240px;
                                    flex: 0 1 240px;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin: 0;
                                    overflow: hidden;
                                    padding: 0;
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_fbt-checkbox__GSgEz {
                                    padding: 0;
                                    position: absolute;
                                    right: 0;
                                    top: 6px;
                                    z-index: 1
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_fbt-checkbox__GSgEz {
                                    left: 0;
                                    right: auto
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_title-component-overflow3__26ly1 {
                                    -webkit-line-clamp: 3;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: normal
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_title-section__16zUG {
                                    -webkit-box-pack: end;
                                    -ms-flex-pack: end;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    justify-content: flex-end
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_display-flex__1gorZ {
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-wrap: wrap;
                                    flex-wrap: wrap
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_price-section__1Wo6p {
                                    margin-right: 10px;
                                    overflow: visible;
                                    white-space: nowrap
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_price-section__1Wo6p {
                                    margin-left: 10px;
                                    margin-right: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_thumbnail-plus__zdWox {
                                    margin: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_thumbnail-plus-new__2nZz1 {
                                    float: left;
                                    margin: auto 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_plus-padding__21zgg {
                                    padding-left: 24.4px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_plus-padding__21zgg {
                                    padding-left: 0;
                                    padding-right: 24.4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_product-box__3PBxY {
                                    border-radius: 0 0 0 0;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    margin: 0 2px -1px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_item-details-per-asin__3DtF1 {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: row;
                                    flex-direction: row
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_item-delivery-message-per-asin__WQ7q7 {
                                    position: relative;
                                    top: -4px;
                                    white-space: nowrap
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_fbt-item-check__pUIoy {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center;
                                    margin-right: 2px;
                                    padding-left: 10px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_fbt-item-check__pUIoy {border-right: initial;
                                    margin-right: 2px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_add-all-button__1TRXG {
                                    height: 20px;
                                    line-height: 20px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_total-label__dI983 {
                                    text-align: left
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_label-center__L5TW- {
                                    text-align: center !important
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_total-points-label__3r09H {
                                    text-align: left
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_add-items__16weX {
                                    display: none
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_choose-items__15UQx {
                                    display: none;
                                    padding-left: 10px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_updated-choose-items__3BN67 {
                                    -webkit-box-flex: 0;
                                    -ms-flex: 0 1 280px;
                                    flex: 0 1 280px;
                                    margin-left: 50px;
                                    margin-top: 60px;
                                    padding-left: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_updated-choose-items__3BN67 {
                                    margin-left: 0;
                                    margin-right: 50px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_total-amount__wLVdU {
                                    padding-left: 3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_points-amount__1SNdT {
                                    margin-right: 3px;
                                    padding-left: 3px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_total-amount__wLVdU {
                                    padding-left: 0;
                                    padding-right: 3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_price-add-to-cart-box__3OUdK {
                                    display: inline-block;
                                    padding-bottom: 10px;
                                    padding-right: 10px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_price-points-box__1xGfe {
                                    -webkit-box-pack: end;
                                    -ms-flex-pack: end;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 0;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex: 0 0 60px;
                                    flex: 0 0 60px;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    justify-content: flex-end;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_ship-message-box__t-OOr {
                                    clear: left;
                                    padding-left: 10px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_ship-message-box__t-OOr,
                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_ship-message-box__t-OOr {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    padding-bottom: 10px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_ship-message-box__t-OOr {
                                    clear: right;
                                    padding-right: 10px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_shipping-info-show-box__17yWM {
                                    display: none;
                                    overflow: hidden
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_show-details-box__-R3Xb {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: row;
                                    flex-direction: row
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_show-details__3GnPL {
                                    display: inline;
                                    display: initial;
                                    padding-left: 4px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_show-details__3GnPL {
                                    display: inline;
                                    display: initial;
                                    padding-left: 0;
                                    padding-right: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_shift-details__gffZp {
                                    margin-left: 28px;
                                    padding: 0 !important
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_shift-details__gffZp {
                                    margin-left: 0;
                                    margin-right: 28px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_hide-details__28l17 {
                                    display: none;
                                    padding-left: 4px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_hide-details__28l17 {
                                    display: none;
                                    padding-left: 0;
                                    padding-right: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_sims-fbt-unselected-item__VQmZx {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    filter: alpha(opacity=20);
                                    justify-content: center;
                                    margin-right: 2px;
                                    opacity: .2
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_sims-fbt-rows__2LJXs {
                                    clear: left
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_sims-fbt-rows__2LJXs {
                                    border-right: initial;
                                    clear: right
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_bucket-divider__25poP {
                                    clear: left
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_title-truncate__1pPAM {
                                    display: inline-block;
                                    margin-right: 4px;
                                    max-width: 750px;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: nowrap
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_detail-row-element__2WDgq {
                                    line-height: 20px !important;
                                    margin-right: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_detail-row-element-left-margin__UkZ8O {
                                    line-height: 20px !important;
                                    margin-left: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_action-details__18ZiI {
                                    visibility: visible
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_action-section__mpQSG {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -ms-flex-item-align: center;
                                    align-self: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    padding: 0;
                                    width: 220px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_side-panel__23vsu {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 0;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex: 0 1 280px;
                                    flex: 0 1 280px;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin-left: 12px;
                                    margin-top: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-desktop_side-panel__23vsu {
                                    margin-left: 0;
                                    margin-right: 12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_item-title__2fMKO {
                                    display: none
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_energy-label__23Bpn {
                                    -webkit-box-flex: 1;
                                    -ms-flex: 1 0 200px;
                                    flex: 1 0 200px;
                                    margin-left: 8px;
                                    margin-right: 8px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_sponsored-label__2Ap87 {
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center;
                                    line-height: 14px;
                                    margin-top: 8px
                                }

                                ._p13n-desktop-sims-fbt_fbt-desktop_visually-hidden__ZFtYQ {
                                    clip: rect(0, 0, 0, 0);
                                    height: 0;
                                    left: 0;
                                    overflow: hidden;
                                    position: absolute;
                                    top: 0;
                                    white-space: nowrap;
                                    width: 0
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-container__1Pkva {
                                    position: relative;
                                    text-align: left
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-standard__28gp8 {
                                    cursor: pointer;
                                    display: inline-block;
                                    height: 24px
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-shape__1IcJY {
                                    display: inline-block;
                                    height: 24px
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-rating__3_0eN {
                                    fill: #fff;
                                    font-size: 20px;
                                    vertical-align: middle
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-rating-sign__1ronK {
                                    fill: #fff;
                                    font-size: 14px;
                                    vertical-align: middle
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-rating-2021__2Q_3P {
                                    left: 24px * .6;
                                    text-shadow: -.5px -.5px 0 #000, .5px -.5px 0 #000, -.5px .5px 0 #000, .5px .5px 0 #000
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-data-sheet-label-container__2iEi2 {
                                    display: inline-block;
                                    padding-left: 5px;
                                    padding-top: 0;
                                    position: absolute;
                                    vertical-align: middle
                                }

                                ._p13n-desktop-sims-fbt_energy-efficiency_energy-efficiency-badge-data-sheet-label__3b6X3 {
                                    cursor: pointer;
                                    word-break: break-word
                                }

                                .sims-grid-card-deck {
                                    clear: both
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_image-link__1g9TG:focus {
                                    z-index: auto !important
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-h3__1ygkk {
                                    margin-top: 0;
                                    padding-bottom: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-bottomsheet-title__1AB7_ {
                                    -ms-flex-item-align: start;
                                    -webkit-box-flex: 0;
                                    align-self: flex-start;
                                    -ms-flex: 0 0 auto;
                                    flex: 0 0 auto;
                                    margin-left: 20px;
                                    margin-right: 16px;
                                    padding: 0;
                                    position: sticky;
                                    top: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-bottomsheet-title__1AB7_ {
                                    -ms-flex-item-align: start;
                                    -webkit-box-flex: 0;
                                    align-self: flex-start;
                                    -ms-flex: 0 0 50px;
                                    flex: 0 0 50px;
                                    margin-left: 16px;
                                    margin-right: 20px;
                                    padding: 0;
                                    position: sticky;
                                    top: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_bottom-sheet-container__1bC6l {
                                    display: inline;
                                    display: initial
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-flex-box-expanded-top__3S9G9 {
                                    -webkit-box-flex: 1;
                                    -ms-flex: 1 1 auto;
                                    flex: 1 1 auto;
                                    overflow-y: scroll;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-flex-box-expanded-top__3S9G9::-webkit-scrollbar {
                                    background: transparent;
                                    width: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-flex-box-expanded-bottom__3_9wG {
                                    -webkit-box-flex: 0;
                                    -ms-flex: 0 0 auto;
                                    flex: 0 0 auto;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-flex-box-expanded__1EQ2R {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-flex-box-divider__xOudh {
                                    border-top: 1px solid #d1d3d4;
                                    box-shadow: 0 -2px 4px rgba(0, 0, 0, .251);
                                    margin-left: -16px;
                                    width: 2000px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-thumbnail-box__1hmv5 {
                                    border: .1rem solid #d5d9d9;
                                    border-radius: .8rem .8rem 0 0;
                                    margin: 0 2px -1px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-thumbnail-box__1hmv5,
                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-thumbnail-box__jh3sF {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-thumbnail-box__jh3sF {
                                    margin: 16px 8px;
                                    padding-bottom: 0;
                                    padding-top: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_thumbnail-box__3IfTY {
                                    -webkit-box-align: top;
                                    -ms-flex-align: top;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: top;
                                    border: .1rem solid #d5d9d9;
                                    border-radius: .8rem .8rem 0 0;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center;
                                    margin: 0 2px -1px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_thumbnail-background__nz6TA {
                                    -webkit-box-flex: 0;
                                    background-color: #f7f8f8;
                                    border-radius: .8rem;
                                    -ms-flex: 0 1 auto;
                                    flex: 0 1 auto;
                                    margin: 0 5px;
                                    padding: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-thumbnail-background__1d1hW {
                                    -webkit-box-flex: 0;
                                    background-color: #f7f8f8;
                                    border-radius: .8rem;
                                    -ms-flex: 0 1 auto;
                                    flex: 0 1 auto;
                                    height: 87px;
                                    margin: 0;
                                    width: 100px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_image-display__2ggEV {
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    align-items: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    height: 100%;
                                    justify-content: center;
                                    mix-blend-mode: multiply;
                                    opacity: 1;
                                    padding: 0;
                                    width: auto
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_image-display__2ggEV>:first-child {height: auto;
                                    -o-object-fit: contain;
                                    object-fit: contain;
                                    width: 100%
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_total-box-collapsed__YfG8B {
                                    border: .1rem solid #d5d9d9;
                                    border-radius: 0 0 .8rem .8rem;
                                    margin: auto 2px;
                                    padding: 13px 17px 12px;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-box-collapsed__2kwwJ {
                                    border: 1px solid #d5d9d9;
                                    border-radius: .8rem .8rem .8rem .8rem;
                                    height: 46px;
                                    padding-top: 0;
                                    width: 100%
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_total-box-expanded__347IH {
                                    border: .1rem solid #d5d9d9;
                                    border-radius: 0 0 .8rem .8rem;
                                    margin: auto 2px;
                                    padding: 13px 17px 17px;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-price-sum-text__4-6Vd {
                                    display: inline;
                                    display: initial
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_button-section__13pwD {
                                    margin: auto;
                                    padding: 20px 0 10px;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_button-section-state__FCLc_ {
                                    pointer-events: fill
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-message__3zDca {
                                    margin: 8px 4px 12px;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_prime-badge__2I1vq {
                                    position: relative;
                                    top: 1px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_point-component__2oDiQ {
                                    display: inline;
                                    display: initial
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_price-component__29CQA {
                                    padding-top: 2px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_prime-component__1EYQ_ {
                                    padding-top: 3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_prime-message__3eFI9 {
                                    margin-top: -3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_product-box___00qE {
                                    border: .1rem solid #d5d9d9;
                                    border-radius: 0 0 0 0;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    margin: 0 2px -1px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_overall__zCYib {
                                    background-color: #fff
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_thumbnail-plus__3oOKD {
                                    margin-left: 10px;
                                    margin-right: 10px;
                                    margin-top: 24px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-thumbnail-plus__11IHy {
                                    margin-top: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_fbt-checkbox__2hT3q {
                                    padding: 0;
                                    position: absolute;
                                    right: -10px;
                                    top: 15px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_fbt-checkbox__2hT3q {
                                    left: -10px;
                                    padding: 0;
                                    position: absolute;
                                    right: auto;
                                    top: 15px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-detail-section__7eFwU {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin: 0;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-detail-section__7eFwU>:first-child {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    -ms-flex-preferred-size: auto;
                                    flex-basis: auto;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    flex-grow: 1;
                                    margin-left: 0;
                                    margin-right: 0;
                                    margin-top: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-section__1iomt {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    flex-grow: 1;
                                    margin: 0 16px;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-section__1iomt>:first-child {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    flex-grow: 1;
                                    margin-left: 0;margin-right: 0;
                                    margin-top: 16px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-section__1iomt {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    flex-grow: 1;
                                    margin: 0 16px;
                                    padding: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-section__1iomt>:first-child {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    flex-grow: 1;
                                    margin-left: 0;
                                    margin-right: 0;
                                    margin-top: 16px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-recommendation-section__p2hr0 {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin: 0;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-recommendation-section__p2hr0>:nth-child(-n+2) {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    margin-left: 0;
                                    margin-right: 0;
                                    margin-top: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-recommendation-section__p2hr0 {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin: 0;
                                    padding: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-recommendation-section__p2hr0>:nth-child(-n+2) {
                                    -webkit-box-orient: horizontal;
                                    -webkit-box-direction: normal;
                                    -ms-flex-direction: row;
                                    flex-direction: row;
                                    margin-left: 0;
                                    margin-right: 0;
                                    margin-top: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_recommendation-section__3xFpL {
                                    -webkit-box-flex: 3;
                                    -ms-flex-positive: 3;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    flex-grow: 3;
                                    margin: 0;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_recommendation-section__3xFpL>:first-child {
                                    margin-bottom: 0;
                                    margin-left: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_recommendation-section__3xFpL>:last-child {
                                    margin-bottom: 0;
                                    margin-right: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_recommendation-section__3xFpL>:first-child {
                                    margin-bottom: 0;
                                    margin-left: 4px;
                                    margin-right: 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_recommendation-section__3xFpL>:last-child {
                                    margin-bottom: 0;
                                    margin-left: 0;
                                    margin-right: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_expanded-section__3DycJ {
                                    display: none;
                                    margin: 0;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_fbt-bottom-sheet-open__2E5ZE {
                                    margin-bottom: 0 !important
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-expanded-section__3tmz5 {
                                    margin: 0;
                                    padding: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-detail-faceout-box__3eRqb {
                                    -webkit-box-flex: 1;
                                    -ms-flex: 1;
                                    flex: 1
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-detail-faceout-box__2T7Om {
                                    background-color: #f7f8f8;
                                    border-radius: .8rem;
                                    -ms-flex: 1 1;
                                    flex: 1 1;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_new-detail-faceout-box__2T7Om,
                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-faceout-box__1gBeQ {
                                    -webkit-box-flex: 1;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    overflow-x: hidden;
                                    padding: 0;
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-new-detail-faceout-box__1gBeQ {
                                    background-color: none;
                                    -ms-flex: 1;
                                    flex: 1;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    margin-bottom: 12px;
                                    margin-left: 12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-detail-selection__1Sesj {
                                    margin-left: -12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-detail-selection__1Sesj,
                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-detail-selection__1Sesj {
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -webkit-box-flex: 1;
                                    -ms-flex-positive: 1;
                                    background-color: #fff;
                                    border: 3px solid transparent;
                                    border-radius: .5rem;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: horizontal;
                                    flex-direction: horizontal;
                                    flex-grow: 1
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-detail-selection__1Sesj {
                                    margin-left: 0;
                                    margin-right: -12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_detail-image-section__1b6sO {
                                    -ms-flex-item-align: center;
                                    align-self: center;
                                    max-height: 250px;
                                    max-width: 250px;
                                    min-height: 0;
                                    padding: 40px 10px 10px;
                                    width: 90%
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_base-image__3zk4r {
                                    -webkit-box-flex: 3;
                                    -ms-flex-item-align: center;
                                    align-self: center;
                                    -ms-flex: 3 1 0px;
                                    flex: 3 1 0;
                                    height: 100%;
                                    max-width: 250px;
                                    min-height: 0;
                                    padding: 6px 15px 6px 11px;
                                    width: -webkit-fit-content;
                                    width: -moz-fit-content;
                                    width: fit-content
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-base-image__1JUaP {
                                    -webkit-box-flex: 0;
                                    background-color: #f7f8f8;
                                    border-radius: .3rem;
                                    -ms-flex: 0 1 auto;
                                    flex: 0 1 auto;
                                    height: auto;
                                    margin: 0;
                                    width: 100px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_detail-info-section__37837 {
                                    -webkit-box-flex: 0;
                                    -ms-flex: 0 1 auto;
                                    flex: 0 1 auto;
                                    padding: 0 8px 9px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-base-info-section__2vg7L {
                                    -webkit-box-flex: 8;
                                    -ms-flex: 8 1 0px;
                                    flex: 8 1 0;
                                    margin: auto 0;
                                    padding: 0 0 0 4px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-base-info-section__2vg7L {
                                    -webkit-box-flex: 8;
                                    -ms-flex: 8 1 0px;
                                    flex: 8 1 0;
                                    margin: auto 0;
                                    padding: 0 4px 0 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_base-info-section__bT3og {
                                    -webkit-box-flex: 8;
                                    -ms-flex: 8 1 0px;
                                    flex: 8 1 0;
                                    margin: auto 0;
                                    padding: 7px 40px 7px 0
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_base-info-section__bT3og {
                                    -webkit-box-flex: 8;
                                    -ms-flex: 8 1 0px;
                                    flex: 8 1 0;
                                    margin: auto 0;
                                    padding: 7px 0 7px 40px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_title-component-overflow3__3p-Qn {
                                    -webkit-line-clamp: 3;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: normal
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_title-component-overflow2__3FcFF {
                                    -webkit-line-clamp: 2;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: normal
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_title-component-overflow1__2mw4S {
                                    -webkit-line-clamp: 1;
                                    -webkit-box-orient: vertical;
                                    display: -webkit-box;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: normal
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_title-section__At9yc,
                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-title-section__3hEHR {
                                    -webkit-box-pack: end;
                                    -ms-flex-pack: end;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    justify-content: flex-end
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_title-section__At9yc {
                                    height: 60.75px}

                                ._p13n-desktop-sims-fbt_fbt-mobile_fbt-item-details__3fpLA {
                                    border-left: .1rem solid #d5d9d9;
                                    cursor: auto;
                                    display: table-cell;
                                    height: 100%;
                                    padding: 9px 25px 9px 17px;
                                    position: relative;
                                    width: 100%
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_fbt-item-details__3fpLA {
                                    border-left: initial;
                                    border-right: .1rem solid #d5d9d9;
                                    padding: 9px 17px 9px 25px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_fbt-item-check__3NTHo {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: center;
                                    border-right: .1rem solid #d5d9d9;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center;
                                    margin-right: -1px;
                                    max-height: 98px;
                                    min-height: 40px;
                                    min-width: 48px;
                                    padding-left: 12px;
                                    padding-top: 9px;
                                    width: 48px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_fbt-item-check__3NTHo {
                                    border-left: .1rem solid #d5d9d9;
                                    border-right: initial;
                                    margin-left: -1px;
                                    margin-right: 0;
                                    padding-left: 0;
                                    padding-right: 12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-fbt-item-check__2Udj7 {
                                    margin-left: -4px;
                                    margin-right: 12px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-fbt-item-check__2Udj7,
                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-fbt-item-check__2Udj7 {
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    align-items: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-fbt-item-check__2Udj7 {
                                    margin-left: 12px;
                                    margin-right: -4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-checkbox__1t9WZ {
                                    margin-left: 4px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_add-all-button__29O5J {
                                    min-width: 260px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_go-to-detail-page-arrow__M0Mb1 {
                                    margin-top: -.7rem;
                                    position: absolute;
                                    right: 1.7rem;
                                    top: 50%
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_go-to-detail-page-arrow__M0Mb1 {
                                    left: 1.7rem;
                                    right: auto
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_expand-arrow__2TOSD {
                                    margin-top: -.7rem;
                                    position: absolute;
                                    right: 1.7rem;
                                    top: 50%
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_expand-arrow__2TOSD {
                                    left: 1.7rem;
                                    right: auto
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_relative-container__32KZm,
                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-relative-container__2KCBe {
                                    position: relative
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_add-items__c-ME8,
                                ._p13n-desktop-sims-fbt_fbt-mobile_choose-items__3lEe_ {
                                    display: none
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_total-label__1oVuL {
                                    display: block;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-label__2jkYj {
                                    display: block;
                                    margin-bottom: 8px;
                                    margin-top: 0;
                                    padding-top: 0;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-label-button__17kds {
                                    display: inline;
                                    display: initial
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-button-section__31zjc {
                                    -webkit-box-flex: 1;
                                    -ms-flex: auto;
                                    flex: auto;
                                    margin: 0 4px 4px;
                                    padding: 0;
                                    text-align: center
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-button-section__31zjc {
                                    margin: 0 4px;
                                    padding: 0;
                                    text-align: center
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-see-details__2cC3f,
                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-price__-W2hm {
                                    display: inline;
                                    display: initial
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_total-amount__2wxzF {
                                    padding-left: 3px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_total-amount__2wxzF {
                                    padding-left: 0;
                                    padding-right: 3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-amount__Tgvsu {padding-left: 3px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_v3-total-amount__Tgvsu {
                                    padding-left: 0;
                                    padding-right: 3px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_ship-message-box__1SBLP {
                                    border: .1rem solid #d5d9d9;
                                    border-radius: 0 0 0 0;
                                    margin: 0 2px -1px;
                                    padding: 13px 41px 17px 17px;
                                    position: relative
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_ship-message-box__1SBLP {
                                    padding-left: 41px;
                                    padding-right: 17px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-header__W0w92 {
                                    border-bottom: .1rem solid #d5d9d9;
                                    padding-bottom: 7px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-product-box__k_y4Q {
                                    border-bottom: .1rem solid #d5d9d9;
                                    padding-bottom: 7px;
                                    padding-top: 8px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-image__w-TXG {
                                    float: left;
                                    margin-right: 10px;
                                    width: 70px
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_shipping-image__w-TXG {
                                    float: right;
                                    margin-left: 10px;
                                    margin-right: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-title__dXudD {
                                    display: inline
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_shipping-title-row__v7anR {
                                    padding-right: 35px;
                                    position: relative
                                }

                                [dir=rtl] ._p13n-desktop-sims-fbt_fbt-mobile_shipping-title-row__v7anR {
                                    padding-left: 35px;
                                    padding-right: 0
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_item-title__1fMVP {
                                    display: none
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_sponsored-label__3fskN {
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    justify-content: center;
                                    line-height: 18px
                                }

                                ._p13n-desktop-sims-fbt_fbt-mobile_diver-link__A4awV {
                                    color: #0f1111 !important;
                                    margin: 12px 0
                                }
                            </style>
                            <!--CardsClient-->
                            <div id="CardInstanceWpfE4f9TXCga3vVyq2h3Jg"
                                data-card-metrics-id="p13n-desktop-sims-fbt_DPSims_0">
                                <div class="cardRoot bucket" data-count="3"
                                    data-components="{&quot;1&quot;:{&quot;checked&quot;:true,&quot;minQuantity&quot;:1,&quot;showPrice&quot;:false,&quot;suppressed&quot;:false},&quot;2&quot;:{&quot;checked&quot;:true,&quot;minQuantity&quot;:1,&quot;showPrice&quot;:false,&quot;suppressed&quot;:false},&quot;3&quot;:{&quot;checked&quot;:true,&quot;minQuantity&quot;:1,&quot;showPrice&quot;:false,&quot;suppressed&quot;:false}}"
                                    data-add-to-cart="[&quot;Add to Cart&quot;,&quot;Add both to Cart&quot;,&quot;Add all three to Cart&quot;,&quot;Add all three to cart&quot;,&quot;Add both to Cart&quot;,&quot;Choose items to buy together.&quot;]"
                                    data-price-totals="{}" data-points-total="{}" data-punt="true"></div>
                            </div>
                            <script>if (window.mix_csa) { window.mix_csa('[cel_widget_id="p13n-desktop-sims-fbt_DPSims_0"]', '#CardInstanceWpfE4f9TXCga3vVyq2h3Jg')('mark', 'be') }</script>
                            <script>if (window.uet) { window.uet('be', 'p13n-desktop-sims-fbt_DPSims_0', { wb: 1 }) }</script>
                            <script>P.when('mix:@amzn/mix.client-runtime', 'mix:p13n-desktop-sims-fbt__KAHWqHe_').execute(function (runtime, cardModule) { runtime.registerCardFactory('CardInstanceWpfE4f9TXCga3vVyq2h3Jg', cardModule).then(function () { if (window.mix_csa) { window.mix_csa('[cel_widget_id="p13n-desktop-sims-fbt_DPSims_0"]', '#CardInstanceWpfE4f9TXCga3vVyq2h3Jg')('mark', 'functional') } if (window.uex) { window.uex('ld', 'p13n-desktop-sims-fbt_DPSims_0', { wb: 1 }) } }); });
                            </script>
                            <script>P.load.js('https://images-fe.ssl-images-amazon.com/images/I/41rRbrTuBFL.js?xcp');
                            </script>
                        </div>


                    </div>

                </div>
                <div id="ask-btf_feature_div" class="celwidget" data-feature-name="ask-btf" data-csa-c-type="widget"
                    data-csa-c-content-id="ask-btf" data-csa-c-slot-id="ask-btf_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">


                    <div id="ask-btf_feature_div">


                        <div id="ask-btf_feature_div">











                            <link rel="stylesheet"
                                href="https://images-fe.ssl-images-amazon.com/images/I/41vgxbAJq3L.css?AUIClients/AskAuiAssets#968550-T1" />
                            <script>
                                (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-fe.ssl-images-amazon.com/images/I/61PvIVKMYAL.js?AUIClients/AskAuiAssets#968550-T1');
                            </script>







                        </div>
                    </div>


                </div>
                <div id="sims-themis-sponsored-products-2_feature_div" class="celwidget"
                    data-feature-name="sims-themis-sponsored-products-2" data-csa-c-type="widget"
                    data-csa-c-content-id="sims-themis-sponsored-products-2"
                    data-csa-c-slot-id="sims-themis-sponsored-products-2_feature_div" data-csa-c-asin=""
                    data-csa-c-is-in-initial-active-row="false">






                </div>
              
<span class="cr-widget-DesktopGlobalReviews" data-hook="cr-widget-DesktopGlobalReviews"></span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
<div id="detail-page-cf-marker_feature_div" class="celwidget" data-feature-name="detail-page-cf-marker"
data-csa-c-type="widget" data-csa-c-content-id="detail-page-cf-marker"
data-csa-c-slot-id="detail-page-cf-marker_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<script type="text/javascript">
var isAUI = typeof P === 'object' && typeof P.when === 'function';
if (typeof setCSMReq == 'function') {
setCSMReq('cf');
} else {
if (typeof uet == 'function') {
uet('cf');
}
if (isAUI) {
P.trigger("cf");
} else {
amznJQ.completedStage('amznJQ.criticalFeature');
}
}
</script>


</div>
<div id="jquery-available_feature_div" class="celwidget" data-feature-name="jquery-available"
data-csa-c-type="widget" data-csa-c-content-id="jquery-available"
data-csa-c-slot-id="jquery-available_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">







<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/21q6fNgsQrL._RC|211TVD3Y9fL.js,11OyIHCq0lL.js_.js?AUIClients/HardlinesFeatureDetailPageMetaAsset" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('cf').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/21q6fNgsQrL._RC|211TVD3Y9fL.js,11OyIHCq0lL.js_.js?AUIClients/HardlinesFeatureDetailPageMetaAsset');
});
</script>



<script type="text/javascript">
if (typeof P !== "undefined" && typeof P.when === "function") {
P.when('cf').execute(function () {
P.when('navbarJS-jQuery').execute(function () { });
P.when('finderFitsJS').execute(function () { });
P.when('twister').execute(function () { });
P.when('swfjs').execute(function () { });
P.when('search-js-jq').execute(function () { });
P.when('amazonShoveler').execute(function () { });
P.when('simsJS').execute(function () { });
P.when('cmuAnnotations').execute(function () { });
P.when('externalJS.tagging').execute(function () { });
P.when('amzn-ratings-bar').execute(function () { });
P.when('accessoriesJS').execute(function () { });
P.when('priceformatterJS').execute(function () { });
P.when('CustomerPopover').execute(function () { });

});
}
</script>



</div>
<div id="cloudfront-web-bug_feature_div" class="celwidget" data-feature-name="cloudfront-web-bug"
data-csa-c-type="widget" data-csa-c-content-id="cloudfront-web-bug"
data-csa-c-slot-id="cloudfront-web-bug_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">





<script type="text/javascript">
// This will fetch the resource in a low impact way from the experiment server.
// executeOnload will prevent fetching the resource until everything else on the page has loaded.
var cloudfrontImg = new Image();
var shouldExecuteOnload = ("1" == "1");
if (shouldExecuteOnload) {
if (window.addEventListener) {
window.addEventListener("load", function () {
setTimeout(function () { cloudfrontImg.src = "//cloudfront-labs.amazonaws.com/x.png"; }, 400);
}, false);
} else if (window.attachEvent) {
window.attachEvent("onload", function () {
setTimeout(function () { cloudfrontImg.src = "//cloudfront-labs.amazonaws.com/x.png"; }, 400);
});
}
} else {
setTimeout(function () { cloudfrontImg.src = "//cloudfront-labs.amazonaws.com/x.png"; }, 400);
}
</script>








</div>
<div id="center-80_feature_div" class="celwidget" data-feature-name="center-80" data-csa-c-type="widget"
data-csa-c-content-id="center-80" data-csa-c-slot-id="center-80_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-81_feature_div" class="celwidget" data-feature-name="center-81" data-csa-c-type="widget"
data-csa-c-content-id="center-81" data-csa-c-slot-id="center-81_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-82_feature_div" class="celwidget" data-feature-name="center-82" data-csa-c-type="widget"
data-csa-c-content-id="center-82" data-csa-c-slot-id="center-82_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-83_feature_div" class="celwidget" data-feature-name="center-83" data-csa-c-type="widget"
data-csa-c-content-id="center-83" data-csa-c-slot-id="center-83_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-84_feature_div" class="celwidget" data-feature-name="center-84" data-csa-c-type="widget"
data-csa-c-content-id="center-84" data-csa-c-slot-id="center-84_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="center-84_feature_div">


<div id="center-84_feature_div">
</div>
</div>


</div>
<div id="center-85_feature_div" class="celwidget" data-feature-name="center-85" data-csa-c-type="widget"
data-csa-c-content-id="center-85" data-csa-c-slot-id="center-85_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="center-85_feature_div">


<div id="center-85_feature_div">
</div>
</div>


</div>
<div id="center-86_feature_div" class="celwidget" data-feature-name="center-86" data-csa-c-type="widget"
data-csa-c-content-id="center-86" data-csa-c-slot-id="center-86_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="center-86_feature_div">


<div id="center-86_feature_div">
</div>
</div>


</div>
<div id="center-87_feature_div" class="celwidget" data-feature-name="center-87" data-csa-c-type="widget"
data-csa-c-content-id="center-87" data-csa-c-slot-id="center-87_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="center-87_feature_div">


<div id="center-87_feature_div">
</div>
</div>


</div>
<div id="giveaway_feature_div" class="celwidget" data-feature-name="giveaway" data-csa-c-type="widget"
data-csa-c-content-id="giveaway" data-csa-c-slot-id="giveaway_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="center-88_feature_div" class="celwidget" data-feature-name="center-88" data-csa-c-type="widget"
data-csa-c-content-id="center-88" data-csa-c-slot-id="center-88_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-89_feature_div" class="celwidget" data-feature-name="center-89" data-csa-c-type="widget"
data-csa-c-content-id="center-89" data-csa-c-slot-id="center-89_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-90_feature_div" class="celwidget" data-feature-name="center-90" data-csa-c-type="widget"
data-csa-c-content-id="center-90" data-csa-c-slot-id="center-90_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-91_feature_div" class="celwidget" data-feature-name="center-91" data-csa-c-type="widget"
data-csa-c-content-id="center-91" data-csa-c-slot-id="center-91_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-92_feature_div" class="celwidget" data-feature-name="center-92" data-csa-c-type="widget"
data-csa-c-content-id="center-92" data-csa-c-slot-id="center-92_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-93_feature_div" class="celwidget" data-feature-name="center-93" data-csa-c-type="widget"
data-csa-c-content-id="center-93" data-csa-c-slot-id="center-93_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-94_feature_div" class="celwidget" data-feature-name="center-94" data-csa-c-type="widget"
data-csa-c-content-id="center-94" data-csa-c-slot-id="center-94_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-95_feature_div" class="celwidget" data-feature-name="center-95" data-csa-c-type="widget"
data-csa-c-content-id="center-95" data-csa-c-slot-id="center-95_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-96_feature_div" class="celwidget" data-feature-name="center-96" data-csa-c-type="widget"
data-csa-c-content-id="center-96" data-csa-c-slot-id="center-96_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-97_feature_div" class="celwidget" data-feature-name="center-97" data-csa-c-type="widget"
data-csa-c-content-id="center-97" data-csa-c-slot-id="center-97_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-98_feature_div" class="celwidget" data-feature-name="center-98" data-csa-c-type="widget"
data-csa-c-content-id="center-98" data-csa-c-slot-id="center-98_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-99_feature_div" class="celwidget" data-feature-name="center-99" data-csa-c-type="widget"
data-csa-c-content-id="center-99" data-csa-c-slot-id="center-99_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="center-100_feature_div" class="celwidget" data-feature-name="center-100"
data-csa-c-type="widget" data-csa-c-content-id="center-100"
data-csa-c-slot-id="center-100_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-1_feature_div" class="celwidget" data-feature-name="accessory-popover-1"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-1"
data-csa-c-slot-id="accessory-popover-1_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-2_feature_div" class="celwidget" data-feature-name="accessory-popover-2"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-2"
data-csa-c-slot-id="accessory-popover-2_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-3_feature_div" class="celwidget" data-feature-name="accessory-popover-3"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-3"
data-csa-c-slot-id="accessory-popover-3_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-4_feature_div" class="celwidget" data-feature-name="accessory-popover-4"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-4"
data-csa-c-slot-id="accessory-popover-4_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-5_feature_div" class="celwidget" data-feature-name="accessory-popover-5"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-5"
data-csa-c-slot-id="accessory-popover-5_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-6_feature_div" class="celwidget" data-feature-name="accessory-popover-6"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-6"
data-csa-c-slot-id="accessory-popover-6_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-7_feature_div" class="celwidget" data-feature-name="accessory-popover-7"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-7"
data-csa-c-slot-id="accessory-popover-7_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-8_feature_div" class="celwidget" data-feature-name="accessory-popover-8"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-8"
data-csa-c-slot-id="accessory-popover-8_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-9_feature_div" class="celwidget" data-feature-name="accessory-popover-9"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-9"
data-csa-c-slot-id="accessory-popover-9_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="accessory-popover-10_feature_div" class="celwidget" data-feature-name="accessory-popover-10"
data-csa-c-type="widget" data-csa-c-content-id="accessory-popover-10"
data-csa-c-slot-id="accessory-popover-10_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


</div>
<div id="listmania-center_feature_div" class="celwidget" data-feature-name="listmania-center"
data-csa-c-type="widget" data-csa-c-content-id="listmania-center"
data-csa-c-slot-id="listmania-center_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="listmania-center_feature_div">


<div id="listmania-center_feature_div">
</div>
</div>


</div>
<div id="sylt-center_feature_div" class="celwidget" data-feature-name="sylt-center"
data-csa-c-type="widget" data-csa-c-content-id="sylt-center"
data-csa-c-slot-id="sylt-center_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">


<div id="sylt-center_feature_div">


<div id="sylt-center_feature_div">
</div>
</div>


</div>
<div id="detail-page-cf-marker_feature_div" class="celwidget" data-feature-name="detail-page-cf-marker"
data-csa-c-type="widget" data-csa-c-content-id="detail-page-cf-marker"
data-csa-c-slot-id="detail-page-cf-marker_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<script type="text/javascript">
var isAUI = typeof P === 'object' && typeof P.when === 'function';
if (typeof setCSMReq == 'function') {
setCSMReq('cf');
} else {
if (typeof uet == 'function') {
uet('cf');
}
if (isAUI) {
P.trigger("cf");
} else {
amznJQ.completedStage('amznJQ.criticalFeature');
}
}
</script>


</div>
<div id="page-refresh-js-initializer_feature_div" class="celwidget"
data-feature-name="page-refresh-js-initializer" data-csa-c-type="widget"
data-csa-c-content-id="page-refresh-js-initializer"
data-csa-c-slot-id="page-refresh-js-initializer_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">







<script type='text/javascript'>
P.when('atf').execute(function () {
P.now('usePageRefreshAsset').execute(function (dataObj) {
if (!dataObj) {
P.declare('usePageRefreshAsset', {});
}
});
});
</script>



<script type="a-state"
data-a-state="{&quot;key&quot;:&quot;page-refresh-data-mason&quot;}">{"pageRefreshUrlParams":{"sid":"356-1077062-4831846","ptd":"DIGITAL_DEVICE_3","json":"1","dpxAjaxFlag":"1","sCac":"1","isUDPFlag":"1","twisterView":"glance","ee":"2","pgid":"amazon_home_display_on_website","rid":"90G9DFKSFRKCQZ4KHD88","parentAsin":"B0BF75VM4T","enPre":"1","dcm":"1","numericGLProductGroupID":"451","asinList":"B0DG4WZZPV","storeID":"amazon-home","auiAjax":"1"}}</script>




</div>
<div id="twister-js-initializer_feature_div" class="celwidget"
data-feature-name="twister-js-initializer" data-csa-c-type="widget"
data-csa-c-content-id="twister-js-initializer"
data-csa-c-slot-id="twister-js-initializer_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">












</div>
<div id="legal_feature_div" class="celwidget" data-feature-name="legal" data-csa-c-type="widget"
data-csa-c-content-id="legal" data-csa-c-slot-id="legal_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="buffetServiceCard_feature_div" class="celwidget" data-feature-name="buffetServiceCard"
data-csa-c-type="widget" data-csa-c-content-id="buffetServiceCard"
data-csa-c-slot-id="buffetServiceCard_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">

</div>

<div id="ajaxBlockComponents_feature_div" class="celwidget" data-feature-name="ajaxBlockComponents"
data-csa-c-type="widget" data-csa-c-content-id="ajaxBlockComponents"
data-csa-c-slot-id="ajaxBlockComponents_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
<script type="text/javascript">
P.when('A').execute('triggerVideoAjax', function (A) {
var obj = A.$.parseJSON('{"dataInJson":null,"colorImages":{},"videos":[],"enableS2WithoutS1":false,"notShowVideoCount":false,"lazyLoadExperienceDisabled":true,"lazyLoadExperienceOnHoverDisabled":false,"refactorEnabled":false,"mainImageSizes":[["355","355"],["450","450"],["425","550"],["466","606"],["522","679"],["569","741"],["679","879"]],"colorImage":null}');
A.trigger('enableS2WithoutS1Ajax', obj.enableS2WithoutS1);
A.trigger('triggerVideoAjax', obj.videos);
A.trigger('notShowVideoCountAjax', obj.notShowVideoCount);
});
</script>
</div>
<div id="CN_footer_features" class="celwidget" data-feature-name="CN_footer_features"
data-csa-c-type="widget" data-csa-c-content-id="CN_footer_features"
data-csa-c-slot-id="CN_footer_features" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="storeDisclaimer_feature_div" class="celwidget" data-feature-name="storeDisclaimer"
data-csa-c-type="widget" data-csa-c-content-id="storeDisclaimer"
data-csa-c-slot-id="storeDisclaimer_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="CN_footer_features_2" class="celwidget" data-feature-name="CN_footer_features_2"
data-csa-c-type="widget" data-csa-c-content-id="CN_footer_features_2"
data-csa-c-slot-id="CN_footer_features_2" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="btfSubNavDesktop_feature_div" class="celwidget" data-feature-name="btfSubNavDesktop"
data-csa-c-type="widget" data-csa-c-content-id="btfSubNavDesktop"
data-csa-c-slot-id="btfSubNavDesktop_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="emit-js_feature_div" class="celwidget" data-feature-name="emit-js" data-csa-c-type="widget"
data-csa-c-content-id="emit-js" data-csa-c-slot-id="emit-js_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<div id="log-detail-page-metrics_feature_div" class="celwidget"
data-feature-name="log-detail-page-metrics" data-csa-c-type="widget"
data-csa-c-content-id="log-detail-page-metrics"
data-csa-c-slot-id="log-detail-page-metrics_feature_div" data-csa-c-asin=""
data-csa-c-is-in-initial-active-row="false">
</div>
<script type="text/javascript">
// Only execute if performance object is defined in JS
if (typeof performance != "undefined" && typeof performance.getEntries != "undefined") {
var metaAssetNames = [];
metaAssetNames.push("DetailPageMetaAssetFixed");
metaAssetNames.push("AXFClientPluginAsset");
metaAssetNames.push("DetailPageEverywhereMetaAsset");
metaAssetNames.push("DetailPagePriceTrackerAssets");
metaAssetNames.push("DetailPageProductSpecDepthAsset");
metaAssetNames.push("DetailPagePQVAssets");
metaAssetNames.push("DetailPageTwisterPlusSubAssets");
metaAssetNames.push("AmazonDevicesDetailPageCriticalAssets");
metaAssetNames.push("InstallmentPaymentDetailPageMetaAsset");
metaAssetNames.push("DetailPagePostPurchaseAssets");
metaAssetNames.push("DetailPageTurboCheckoutDesktopAssets");
metaAssetNames.push("DetailPageNostosAssets");
if (metaAssetNames.length > 0) {
for (assetIndex = 0; assetIndex < metaAssetNames.length; assetIndex++) {
var metaAssetName = metaAssetNames[assetIndex];
var re = new RegExp("\\.css\\?AUIClients/" + metaAssetName);
for (i = 0; i < performance.getEntries().length; i++) {
var dpEntry = performance.getEntries()[i];
var res = dpEntry.name.match(re);
if (res && dpEntry.initiatorType && dpEntry.initiatorType == "link") {
var dpmaDuration = dpEntry.duration;
ue.count(metaAssetName + ".duration", dpmaDuration);
if (dpmaDuration < 50) {
ue.tag(metaAssetName + "Cached");
} else {
ue.tag(metaAssetName + "NotCached");
}
ue.count(metaAssetName + ".startTime", dpEntry.startTime);
}
}
}
}
else {
ue.count("DPMANoMetaAsset", 1);
}

for (i = 0; i < performance.getEntries().length; i++) {
var name = performance.getEntries()[i].name;
var res = name.match(/\.css\?AUIClients\/AmazonUI/);
var initiatorType = performance.getEntries()[i].initiatorType;
if (res && initiatorType && initiatorType == "link") {
var duration = performance.getEntries()[i].duration;
ue.count("aui.duration", duration);
ue.count("aui.startTime", performance.getEntries()[i].startTime);
if (duration < 50) {
csmTag = "auiCached";
}
else {
csmTag = "auiNotCached";
}

if (window.ue && ue.tag) {
ue.tag(csmTag);
}
break;
}
}
}
</script>











<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('A').execute(function (A) {
if (A.preload) {
A.preload('https://m.media-amazon.com/images/I/11zuylp74DL._RC|61xJcNKKLXL.js,11Y+5x+kkTL.js,51cR93oXsVL.js,11yKORv-GTL.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01VRMV3FBdL.js,21u+kGQyRqL.js,012FVc3131L.js,11aD5q6kNBL.js,11rRjDLdAVL.js,51LgVZTDoFL.js,11nAhXzgUmL.js,119kvzYmMJL.js,1110g-SvlBL.js,11npBNHo-jL.js,21eKR4hvwNL.js,0190vxtlzcL.js,51P8J4TsllL.js,01JYHc2oIlL.js,31nfKXylf6L.js,01ktRCtOqKL.js,01ASnt2lbqL.js,11bEz2VIYrL.js,31o2NGTXThL.js,01rpauTep4L.js,31lTOzOlAqL.js,01tvglXfQOL.js,11Rf82oewsL.js,014gnDeJDsL.js,01A2fK8tgRL.js_.js?AUIClients/AmazonUI');
A.preload('https://m.media-amazon.com/images/I/11EIQ5IGqaL._RC|01e5ncglxyL.css,01lF2n-pPaL.css,519YvOBDG8L.css,31uBZQYbDJL.css,11hEAfyy4tL.css,01qPl4hxayL.css,01pOTCa2wPL.css,413Vvv3GONL.css,11TIuySqr6L.css,01Rw4F+QU6L.css,11JJsNcqOIL.css,01J3raiFJrL.css,01IdKcBuAdL.css,01dRHIoUjnL.css,21lFcV0hmCL.css,01W0RNXC6mL.css,51nYRMITMLL.css,01XPHJk60-L.css,11wvSzGn6tL.css,01ANX9Vx1mL.css,01cvE3JoRWL.css,21qiQ1rOUAL.css,11wazUu-8nL.css,21RWaJb6t+L.css,11yLJpkAxFL.css,216LjtW6ADL.css,01CFUgsA-YL.css,313tC6rl1gL.css,116t+WD27UL.css,11yEzLYDg2L.css,113QjYEJj-L.css,11BdrZWOJpL.css,01r-hR9jMmL.css,01X+Gu6WK9L.css,21ZVss5T32L.css,114W6O7j2oL.css,01LzHhtXxxL.css,21zi3R-XjNL.css,115pt6oW+ZL.css,11hvENnYNUL.css,11Qek6G6pNL.css,01890+Vwk8L.css,01bDiPuBD6L.css,01cbS3UK11L.css,21F85am0yFL.css,016mfgi+D2L.css,01WslS8q5ML.css,21zhgeMzYSL.css,016Sx2kF1+L.css_.css?AUIClients/AmazonUI&Mae8yxFM#not-trident.940763-T1');
A.preload('https://m.media-amazon.com/images/I/01I3s4SlPiL._RC|21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01Gujc1zuyL.js,617GSrKlU5L.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageMetaAssetFixed&iODFtMTi#desktop.au.819223-T2');
A.preload('https://m.media-amazon.com/images/I/01Qew71Yx0L._RC|11eEUYY2YJL.css,01UqkjH7qOL.css,01NuAxux7eL.css,01bTUA+3s-L.css,019L5P4oPhL.css_.css?AUIClients/DetailPageMetaAssetFixed&w9HItqlK#desktop.au.564914-C.792614-C');
A.preload('https://m.media-amazon.com/images/I/31vB5DAPhsL.js?AUIClients/AmazonUICalendar');
A.preload('https://m.media-amazon.com/images/I/11%2BBsbU2mSL._RC|21ac9LlTPiL.css_.css?AUIClients/AmazonUICalendar#not-trident');
A.preload('https://m.media-amazon.com/images/I/01rg6Ce9FhL._RC|01EfL1GvN7L.js,01hcvL3758L.js,21JPvQvwWNL.js_.js?AUIClients/DetailPageEverywhereMetaAsset#desktop');
A.preload('https://m.media-amazon.com/images/I/01FZqefKpEL.css?AUIClients/DetailPageEverywhereMetaAsset');
A.preload('https://m.media-amazon.com/images/I/21J1hhP1B-L._RC|316nVZ1c+gL.js,31SdJaj48BL.js,01S4a+TTNzL.js,21cezxqCFCL.js,318rs4piGPL.js,01TQyo0bnIL.js,21otRNR-CUL.js,01jEqq6I0UL.js,013NxCyC-FL.js,61JVR3HQg9L.js,21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,514Cltr0aKL.js,11p0nLfNCcL.js,01s9HEfbt3L.js,11CGomdzAuL.js,015TRQC5i+L.js,61uALA3NV5L.js,01L9nn2zMmL.js,6181fgtPhlL.js,01pqohuf3qL.js,01c9e82cOLL.js,21kLNnswYkL.js,413fAUrzdFL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,31vI2qZfDdL.js,11LSI8IU0NL.js,11K5qCK19CL.js,21gSOcPzXNL.js,61LeY14vUoL.js,21eqxbXzvyL.js,21kn81I80-L.js,01EfL1GvN7L.js,01hcvL3758L.js,01Z3OBC-FbL.js,21uyGp88snL.js,21m+1oRN24L.js_.js?AUIClients/HardlinesDetailPageMetaAssetFixed&morGv3Ni#desktop.au.819223-T2.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.790980-C.195406-T1.755654-T1.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1032661-T1');
A.preload('https://m.media-amazon.com/images/I/51e%2Blg8bllL._RC|11bRdV2t20L.css,518KmQy9QVL.css,01ZpHhtNc4L.css,21TugutLpHL.css,01Y+rQYR1fL.css,0121zKjk26L.css,31wJJNCoGkL.css,11xRy3bSkOL.css,21sMn3zVEmL.css,41vOQb1k0LL.css,11eEUYY2YJL.css,01UqkjH7qOL.css,01NuAxux7eL.css,31DVygeZycL.css,31TJtSmBkXL.css,11X8K4AolpL.css,21PjfsP9YvL.css,21W5fiSj06L.css,21AcZ0BarRL.css,11tXw5UsxML.css,31cE7qTuwaL.css,019FsjFtXXL.css,01vuFvYd+pL.css,21wJ9sXr8kL.css,21RZgaOpsqL.css,01LNhrqAZmL.css,11mqgJVSK9L.css,01P0iSwDaIL.css,01Ie8mDBSFL.css,01pi1oDEPFL.css,11wQIGy3uGL.css,311nNbUtvUL.css,01jl+PNk5sL.css,11mgAfMzmHL.css_.css?AUIClients/HardlinesDetailPageMetaAssetFixed&ITTVDORw#desktop.language-en.au.564914-C.1001679-T1.284294-C.755654-T1.129737-C.835930-T3.835929-T1.682739-T1.94145-T1.421521-T1.610492-T1.941471-T1.792614-C');
A.preload('https://m.media-amazon.com/images/I/11e6YKvz8HL._RC|61dvI6FY6DL.js,51ZC-YOwyHL.js,11QPSzcZzFL.js,21Tlkr4uAnL.js,31e-8pJy4aL.js,01c9e82cOLL.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageDesktopImageBlockMetaAsset&xcZvtG8l#desktop.1015328-T2.974257-T1.987339-T1.1016016-T1.790980-C.1040299-T1.342971-T1.585425-T1');
A.preload('https://m.media-amazon.com/images/I/016esLn3t8L._RC|111DfP5LzLL.css,11Q2UEVwwYL.css_.css?AUIClients/DetailPageDesktopImageBlockMetaAsset&XsCkSwQ+#1015328-T2.953587-T1');
A.preload('https://m.media-amazon.com/images/I/31EFtqFUPbL._RC|21YblE14ZTL.js,01+oIQ0jY7L.js,11a+lhxkUrL.js,31Woe0xBtCL.js,31RdjkYMc0L.js,01g2etah0NL.js,21KBCItCElL.js,21w+41KyyFL.js,31oAl8dJC2L.js,41TVCJWzmfL.js,41q36Jp+JRL.js,01xGyUiM+9L.js,41uokUsXQdL.js,312+Y3195kL.js,41jw+MLBYxL.js,51Dk5hfW7hL.js,4123BTTtUrL.js,11LSI8IU0NL.js,413fAUrzdFL.js,111zW1Nhl9L.js,21nBcYFuyhL.js,01OtvpwikQL.js,41aT8jJQVvL.js,61KuzBlqVrL.js,21v7Os12mhL.js,21F+2VGtGTL.js,11PUEGgF9FL.js,31UaW8zx0bL.js,01lcH4zcTaL.js,013eoEBTVUL.js,016QFWAAdML.js,61LeY14vUoL.js,61fc2pZo-cL.js,51C7pxaRBkL.js,51+RQAfanbL.js,01pEpg0ouXL.js,21rCp4n3EgL.js,61uALA3NV5L.js,01L9nn2zMmL.js,11DbyV7EqEL.js,015o6sfRHyL.js,014kCoIHgIL.js,019W6kk1gjL.js,31DwCDV0WwL.js,413ORk1fNJL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,01mjV3L7d0L.js,01cyf4FMJWL.js,61GYq6xQlWL.js,41mexBCNCmL.js,210qgen2dJL.js,01c9e82cOLL.js,01WQALympXL.js,21OE0Cpw7-L.js,41kJwg9GluL.js,11uacn9D5ZL.js,41Debmz01QL.js,01YJaiySPtL.js,01GCLtg-iyL.js,31YT4iYOlWL.js,31236-TZUgL.js,31CoszE6RRL.js,41878Hwie5L.js,41URVeWP1BL.js,0126YIoj+oL.js,11K5qCK19CL.js,01LBPfQ0IdL.js,013YkX6C2QL.js,21IQl4blS4L.js,01HPCJZdF6L.js,31jdfgcsPAL.js,31kjc9S7VkL.js,019MkidFEWL.js,01T2iqPIK-L.js,01lb9cuSpfL.js,21SWk05+6qL.js,11sjHLvE-aL.js,21eqxbXzvyL.js,21kn81I80-L.js,01EfL1GvN7L.js,01hcvL3758L.js,01sWkjQEFNL.js,21uyGp88snL.js,21m+1oRN24L.js,01uyz9BO3mL.js,01o4XBrre-L.js,010ghrVeGXL.js,01UGySNmsCL.js,010-kx8pFzL.js,01PG4SvsQ8L.js,01ikzOA7NuL.js,31pApnBGYrL.js,01j2lSa3E+L.js,01Vh-RQZAKL.js,61tO7g6w7GL.js,21Ct71OiKjL.js,21bGTSoJQRL.js_.js?AUIClients/HardlinesDetailPageMetaAssetVariable_TURBO_DESKTOP_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&2k1lOsh4#desktop.au.792084-C.1077871-T1.729113-T1.1005989-T1.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.533504-T1.651909-T1.1028468-T1.790980-C.188581-T1.368370-C.1025785-T1.1041430-T1.972327-T1.640514-T1.679600-T2.680355-T1.628223-T1.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1030915-T1.958666-T1.958825-T1.943986-T1.184219-T1.447372-T1.109378-T1.1072254-T1.1032661-T1');
A.preload('https://m.media-amazon.com/images/I/21UZhQX3Y2L._RC|31TcFnRur-L.css,11-cL60xzwL.css,01f45Q7Pl8L.css,01KvCqKMBgL.css,11fgqh6KBgL.css,51l1evL20eL.css,01sd0YVrBlL.css,01ctKio6TqL.css,21ix86FkfXL.css,21Oc5IYIz8L.css,21HpY-6TKaL.css,41KQpcRKbaL.css,01Ie8mDBSFL.css,21wJ9sXr8kL.css,11kmwdXfY5L.css,01NW8VTUeVL.css,31EZ-WcK1PL.css,011uHgmxBfL.css,41ZLKK+TfUL.css,31Xq0DzIe3L.css,114HJAY+ShL.css,01wkbZw3FtL.css,21bT8BmCRSL.css,311nNbUtvUL.css,41qRC-gouAL.css,51B1r-7AweL.css,71vkbpX3TFL.css,01WdJkFf2xL.css,21AcZ0BarRL.css,11tXw5UsxML.css,11ikU6MX1JL.css,21FyYnb2G7L.css,01ZcdNKBOIL.css,014odsh6+QL.css,21RZgaOpsqL.css,01LNhrqAZmL.css,11mqgJVSK9L.css,31YRQb-ZBTL.css,11zSkLx7WwL.css,31TOpn8AorL.css,01adN84djtL.css,01+KRP2j52L.css,01muB6xKhLL.css,013Su4ILzBL.css,010kW5Xhu3L.css,01pi1oDEPFL.css,01FL7JU2DtL.css,21GVjoDBdZL.css,01jl+PNk5sL.css,11mgAfMzmHL.css,01goIIPoVxL.css_.css?AUIClients/HardlinesDetailPageMetaAssetVariable_TURBO_DESKTOP_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&K/Hj78Ta#desktop.113788-C.1001679-T1.651909-T1.673252-C.188581-T1.1025785-T1.972326-T1.956125-T1.956121-T2.682739-T1.859053-T1.859048-T1');
A.preload('https://m.media-amazon.com/images/I/51Fu2vYzlJL._RC|61uALA3NV5L.js,01L9nn2zMmL.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageDesktopConfiguratorMetaAsset&hZIkuCrB#desktop.384314-T1');
A.preload('https://m.media-amazon.com/images/I/41GR4r13VlL._RC|21AcZ0BarRL.css,11tXw5UsxML.css_.css?AUIClients/DetailPageDesktopConfiguratorMetaAsset');
A.preload('https://m.media-amazon.com/images/I/51AjX08cr2L._RC|31yP6n5A+XL.js,31gVA5+cVBL.js,712ce1xhKRL.js,31qx-Gr7LfL.js,61uALA3NV5L.js,01L9nn2zMmL.js,01EfL1GvN7L.js,01hcvL3758L.js_.js?AUIClients/DetailPageNewDesktopTwisterMetaAsset&zVmUmgdR#desktop.742915-T1.1025165-T1.949872-T1.1080388-T1.976626-T1.354354-T1.384314-T1.565192-T1');
A.preload('https://m.media-amazon.com/images/I/31xio9NvR3L._RC|01r8lpNJhRL.css,012Fi5I-rKL.css,21AcZ0BarRL.css,11tXw5UsxML.css_.css?AUIClients/DetailPageNewDesktopTwisterMetaAsset&kfeUK+HP#desktop.1042911-T1.976626-T1');
A.preload('https://m.media-amazon.com/images/I/11XQDILn5QL._RC|31EFtqFUPbL.js,21YblE14ZTL.js,01+oIQ0jY7L.js,11a+lhxkUrL.js,31Woe0xBtCL.js,31RdjkYMc0L.js,01g2etah0NL.js,21KBCItCElL.js,21w+41KyyFL.js,31oAl8dJC2L.js,41TVCJWzmfL.js,41q36Jp+JRL.js,31SdJaj48BL.js,41e6i3fL7yL.js,316nVZ1c+gL.js,11FRPBZUGyL.js,01S4a+TTNzL.js,312+Y3195kL.js,41jw+MLBYxL.js,01TQyo0bnIL.js,21otRNR-CUL.js,51Dk5hfW7hL.js,01xGyUiM+9L.js,41uokUsXQdL.js,21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01HmcbFsnFL.js,111zW1Nhl9L.js,11DGcrZsUwL.js,01OtvpwikQL.js,41aT8jJQVvL.js,11PUEGgF9FL.js,01hIJ77ksGL.js,21E2zdI0rTL.js,61+HW0qmAXL.js,013eoEBTVUL.js,016QFWAAdML.js,61uALA3NV5L.js,01L9nn2zMmL.js,019W6kk1gjL.js,01lcH4zcTaL.js,31DwCDV0WwL.js,413ORk1fNJL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,01mjV3L7d0L.js,01cyf4FMJWL.js,61GYq6xQlWL.js,413fAUrzdFL.js,01c9e82cOLL.js,21OE0Cpw7-L.js,21J1hhP1B-L.js,01YJaiySPtL.js,21kLNnswYkL.js,31vI2qZfDdL.js,11LSI8IU0NL.js,01GCLtg-iyL.js,31YT4iYOlWL.js,31236-TZUgL.js,31CoszE6RRL.js,41878Hwie5L.js,41URVeWP1BL.js,0126YIoj+oL.js,11K5qCK19CL.js,21IQl4blS4L.js,01HPCJZdF6L.js,51C7pxaRBkL.js,51+RQAfanbL.js,01pEpg0ouXL.js,31jdfgcsPAL.js,31kjc9S7VkL.js,019MkidFEWL.js,21eqxbXzvyL.js,21kn81I80-L.js,01I3I7dzTsL.js,01EfL1GvN7L.js,01hcvL3758L.js,01sWkjQEFNL.js,01Z3OBC-FbL.js,01lb9cuSpfL.js,21uyGp88snL.js,21m+1oRN24L.js_.js?AUIClients/SoftlinesDetailPageMetaAsset_TURBO_DESKTOP_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&aVW2gDEB#desktop.au.819223-T2.792084-C.1005989-T1.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.533504-T1.651909-T1.1028468-T1.964607-T1.790980-C.195406-T1.368370-C.882977-T1.972327-T1.640514-T1.679600-T2.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1032661-T1');
A.preload('https://m.media-amazon.com/images/I/01uyz9BO3mL._RC|01o4XBrre-L.js,010ghrVeGXL.js,01UGySNmsCL.js,010-kx8pFzL.js,01PG4SvsQ8L.js,01ikzOA7NuL.js,31pApnBGYrL.js,01j2lSa3E+L.js,01Vh-RQZAKL.js,61tO7g6w7GL.js,21Ct71OiKjL.js,21bGTSoJQRL.js_.js?AUIClients/SoftlinesDetailPageMetaAsset_TURBO_DESKTOP_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&n2GxvjPH#desktop.680355-T1.628223-T1.1030915-T1.958666-T1.958825-T1.943986-T1.184219-T1.447372-T1');
A.preload('https://m.media-amazon.com/images/I/51e%2Blg8bllL._RC|11bRdV2t20L.css,41j52RQ1GmL.css,21UZhQX3Y2L.css,31TcFnRur-L.css,11-cL60xzwL.css,01f45Q7Pl8L.css,01KvCqKMBgL.css,11fgqh6KBgL.css,51l1evL20eL.css,01Y+rQYR1fL.css,21RGmbkVgFL.css,21TugutLpHL.css,013PQoQBxwL.css,0121zKjk26L.css,01d6NGlDXwL.css,21ix86FkfXL.css,21Oc5IYIz8L.css,21sMn3zVEmL.css,21HpY-6TKaL.css,01sd0YVrBlL.css,01ctKio6TqL.css,11eEUYY2YJL.css,01UqkjH7qOL.css,01NuAxux7eL.css,01QLwk8mu6L.css,11kmwdXfY5L.css,018mGORJ7tL.css,01NW8VTUeVL.css,31EZ-WcK1PL.css,011uHgmxBfL.css,114HJAY+ShL.css,01IWLLAAyHL.css,31muBBBfzLL.css,21bT8BmCRSL.css,21AcZ0BarRL.css,11tXw5UsxML.css,01wkbZw3FtL.css,014odsh6+QL.css,21RZgaOpsqL.css,01LNhrqAZmL.css,11mqgJVSK9L.css,31YRQb-ZBTL.css,21wJ9sXr8kL.css,01ZpHhtNc4L.css,01vuFvYd+pL.css,01P0iSwDaIL.css,01Ie8mDBSFL.css,01muB6xKhLL.css,013Su4ILzBL.css,010kW5Xhu3L.css,01pi1oDEPFL.css,51B1r-7AweL.css,71vkbpX3TFL.css,01jl+PNk5sL.css,11mgAfMzmHL.css,01goIIPoVxL.css_.css?AUIClients/SoftlinesDetailPageMetaAsset_TURBO_DESKTOP_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&MycUw8YH#desktop.language-en.au.564914-C.113788-C.1001679-T1.651909-T1.972326-T1.956125-T1.956121-T2.835930-T3.835929-T1.682739-T1.94145-T1.610492-T1.941471-T1.792614-C');
A.preload('https://m.media-amazon.com/images/I/51C7pxaRBkL._RC|51+RQAfanbL.js,01pEpg0ouXL.js_.js?AUIClients/DetailPageMiraiAssets');
A.preload('https://m.media-amazon.com/images/I/51B1r-7AweL._RC|71vkbpX3TFL.css_.css?AUIClients/DetailPageMiraiAssets&xQ1DfDvs#956125-T1.956121-T2');
A.preload('https://m.media-amazon.com/images/I/21rCp4n3EgL.js?AUIClients/DetailPageValuePickDesktopAssets&4pIshe2F#1077871-T1.729113-T1');
A.preload('https://m.media-amazon.com/images/I/01WdJkFf2xL.css?AUIClients/DetailPageValuePickDesktopAssets');
A.preload('https://m.media-amazon.com/images/I/11a%2BlhxkUrL._RC|31Woe0xBtCL.js,31RdjkYMc0L.js,01g2etah0NL.js,21KBCItCElL.js,21w+41KyyFL.js,31oAl8dJC2L.js,41TVCJWzmfL.js,41q36Jp+JRL.js,01NBuHsGkGL.js,31SNSZ8d9HL.js,01TQyo0bnIL.js,21otRNR-CUL.js,51Dk5hfW7hL.js,01xGyUiM+9L.js,41uokUsXQdL.js,21Awk0AtTML.js,211sUPEIzRL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,111zW1Nhl9L.js,01OtvpwikQL.js,41aT8jJQVvL.js,11LSI8IU0NL.js,413fAUrzdFL.js,11p0nLfNCcL.js,11CGomdzAuL.js,11PUEGgF9FL.js,31EFtqFUPbL.js,21YblE14ZTL.js,01+oIQ0jY7L.js,61+HW0qmAXL.js,013eoEBTVUL.js,016QFWAAdML.js,61uALA3NV5L.js,01L9nn2zMmL.js,019W6kk1gjL.js,31DwCDV0WwL.js,413ORk1fNJL.js,51L2MB-rgtL.js,31Jh0Dg4diL.js,51Cp9DuZSoL.js,01mjV3L7d0L.js,01cyf4FMJWL.js,61GYq6xQlWL.js,01c9e82cOLL.js,21OE0Cpw7-L.js,21kLNnswYkL.js,31vI2qZfDdL.js,01GCLtg-iyL.js,31YT4iYOlWL.js,31236-TZUgL.js,31CoszE6RRL.js,41878Hwie5L.js,41URVeWP1BL.js,0126YIoj+oL.js,11K5qCK19CL.js,21IQl4blS4L.js,01HPCJZdF6L.js,51C7pxaRBkL.js,51+RQAfanbL.js,01pEpg0ouXL.js,31jdfgcsPAL.js,31kjc9S7VkL.js,019MkidFEWL.js,21eqxbXzvyL.js,21kn81I80-L.js,01EfL1GvN7L.js,01hcvL3758L.js,21uyGp88snL.js,21m+1oRN24L.js,01uyz9BO3mL.js,01o4XBrre-L.js,010ghrVeGXL.js,01UGySNmsCL.js,010-kx8pFzL.js,01PG4SvsQ8L.js,01ikzOA7NuL.js,31pApnBGYrL.js,01j2lSa3E+L.js,01Vh-RQZAKL.js,61tO7g6w7GL.js,21Ct71OiKjL.js,21bGTSoJQRL.js_.js?AUIClients/MediaDetailPageMetaAsset_TURBO_DESKTOP_SWFOBJECT_REMOVAL_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&hsEiIIm6#desktop.au.819223-T2.792084-C.977084-T1.1005989-T1.1001679-T1.979843-C.1036961-T1.1035932-T1.1006812-T1.651909-T1.1028468-T1.964607-T1.790980-C.195406-T1.368370-C.972327-T1.640514-T1.679600-T2.680355-T1.628223-T1.682739-T1.551362-T1.551170-T2.819051-T1.762074-T1.1030915-T1.958666-T1.958825-T1.943986-T1.184219-T1.447372-T1.1032661-T1');
A.preload('https://m.media-amazon.com/images/I/51e%2Blg8bllL._RC|41CbB++ZuuL.css,31TcFnRur-L.css,11-cL60xzwL.css,01f45Q7Pl8L.css,01KvCqKMBgL.css,11fgqh6KBgL.css,51l1evL20eL.css,31ViY6ArFBL.css,21Q8s4XG+xL.css,21sMn3zVEmL.css,21HpY-6TKaL.css,01sd0YVrBlL.css,01ctKio6TqL.css,11eEUYY2YJL.css,01UqkjH7qOL.css,01NuAxux7eL.css,11kmwdXfY5L.css,01NW8VTUeVL.css,31EZ-WcK1PL.css,011uHgmxBfL.css,01Ie8mDBSFL.css,21wJ9sXr8kL.css,31TJtSmBkXL.css,21PjfsP9YvL.css,114HJAY+ShL.css,21UZhQX3Y2L.css,31muBBBfzLL.css,21bT8BmCRSL.css,21AcZ0BarRL.css,11tXw5UsxML.css,014odsh6+QL.css,21RZgaOpsqL.css,01LNhrqAZmL.css,11mqgJVSK9L.css,31YRQb-ZBTL.css,01vuFvYd+pL.css,01P0iSwDaIL.css,01muB6xKhLL.css,013Su4ILzBL.css,010kW5Xhu3L.css,01pi1oDEPFL.css,51B1r-7AweL.css,71vkbpX3TFL.css,01jl+PNk5sL.css,11mgAfMzmHL.css,01goIIPoVxL.css_.css?AUIClients/MediaDetailPageMetaAsset_TURBO_DESKTOP_SWFOBJECT_REMOVAL_BUYX_DP_RPCX_TPLUS_SUBASSETING_897079&HbkAYv6B#desktop.au.564914-C.113788-C.977084-T1.1001679-T1.651909-T1.972326-T1.956125-T1.956121-T2.835930-T3.835929-T1.682739-T1.94145-T1.792614-C');
A.preload('https://m.media-amazon.com/images/I/11obTMtbIdL.js?AUIClients/MorpheusPopularityRankSidesheetAssets');
A.preload('https://m.media-amazon.com/images/I/01VgaL6UIvL.css?AUIClients/MorpheusPopularityRankSidesheetAssets');
A.preload('https://m.media-amazon.com/images/I/21T5HeBxb2L.js?AUIClients/AXFClientPluginAsset');
A.preload('https://m.media-amazon.com/images/I/71PGeFSJQRL.js?AUIClients/DetailPagePriceTrackerAssets#desktop');
A.preload('https://m.media-amazon.com/images/I/11s24T9CZ0L.css?AUIClients/DetailPagePriceTrackerAssets');
A.preload('https://m.media-amazon.com/images/I/31FE2k3SYqL.js?AUIClients/DetailPageOffersDebugAssets');
A.preload('https://m.media-amazon.com/images/I/01wwZTjeU%2BL.css?AUIClients/DetailPageOffersDebugAssets');
A.preload('https://m.media-amazon.com/images/I/51S5AyTWYbL._RC|01gKh-6uxaL.js_.js?AUIClients/InContextDetailPageAssets');
A.preload('https://m.media-amazon.com/images/I/11CKXHwFQgL.css?AUIClients/InContextDetailPageAssets');
A.preload('https://m.media-amazon.com/images/I/21SWk05%2B6qL.js?AUIClients/DetailPageProductSpecDepthAsset&m52tM9b7#1025785-T1.1041430-T1');
A.preload('https://m.media-amazon.com/images/I/01FL7JU2DtL.css?AUIClients/DetailPageProductSpecDepthAsset&6MjQ7uH9#1025785-T1');
A.preload('https://m.media-amazon.com/images/I/31g9ZHgCEBL.js?AUIClients/DetailPagePQVAssets&XoCM3fgj#1053376-T1');
A.preload('https://m.media-amazon.com/images/I/01OMFSv8nnL.css?AUIClients/DetailPagePQVAssets&XoCM3fgj#not-trident.1053376-T1');
A.preload('https://m.media-amazon.com/images/I/61Zv28mcCIL.js?AUIClients/DetailPageAllOffersDisplayAssets&P3Wo0o2z#language-en.403176-C');
A.preload('https://m.media-amazon.com/images/I/31fNEss5igL.css?AUIClients/DetailPageAllOffersDisplayAssets');
A.preload('https://m.media-amazon.com/images/I/91N9kPxZ4QL.js?AUIClients/GestaltDetailPageDesktopMetaAsset');
A.preload('https://m.media-amazon.com/images/I/61%2BHW0qmAXL.js?AUIClients/DetailPageSnSAssets&vjk3Xaf2#964607-T1');
A.preload('https://m.media-amazon.com/images/I/31muBBBfzLL.css?AUIClients/DetailPageSnSAssets');
A.preload('https://m.media-amazon.com/images/I/313sHJh1gZL.js?AUIClients/DetailPagePostPurchaseAssets');
A.preload('https://m.media-amazon.com/images/I/01Io73Ll09L.css?AUIClients/DetailPagePostPurchaseAssets#desktop');
A.preload('https://m.media-amazon.com/images/I/31diH2HLe8L.js?AUIClients/DetailPageBTFSubNavDesktopAsset');
A.preload('https://m.media-amazon.com/images/I/01%2B9c%2BwQR6L.css?AUIClients/DetailPageBTFSubNavDesktopAsset');
A.preload('https://m.media-amazon.com/images/I/21%2B3NfuRrDL.js?AUIClients/DetailPageNostosAssets');
A.preload('https://m.media-amazon.com/images/I/01EkAI936sL.css?AUIClients/DetailPageNostosAssets&tI8lBs8w#686022-C.638734-T3');
A.preload('https://m.media-amazon.com/images/I/61e6i91%2BI6L._RC|71LVgqy2ckL.js,31jsB13JlVL.js_.js?AUIClients/BuyingRulesDetailPageAssets');
A.preload('https://m.media-amazon.com/images/I/31F9SzdeJLL.css?AUIClients/BuyingRulesDetailPageAssets');
}
});
</script>
















<script type="text/javascript">

function prefetchTYPAssets() {
var imageAssets = new Array();
var jsCssAssets = new Array();
imageAssets.push("https://m.media-amazon.com/images/G/35/x-locale/common/buy-buttons/review-1-click-order._CB485945728_.gif");
imageAssets.push("https://m.media-amazon.com/images/G/35/x-locale/common/buttons/continue-shopping._CB485936092_.gif");
imageAssets.push("https://m.media-amazon.com/images/G/35/x-locale/common/buy-buttons/thank-you-elbow._CB485935877_.gif");
imageAssets.push("https://m.media-amazon.com/images/G/35/x-locale/communities/social/snwicons_v2._CB478838660_.png");
imageAssets.push("https://m.media-amazon.com/images/G/35/checkout/assets/carrot._CB485936866_.gif");

// pre-fetching image assets
for (var i = 0; i < imageAssets.length; i++) {
new Image().src = imageAssets[i];
}
// pre-fetching css and js assets based on different browser types
var isIE = /*@cc_on!@*/0;
var isFireFox = /Firefox/.test(navigator.userAgent);
if (isIE) {
for (var i = 0; i < jsCssAssets.length; i++) {
new Image().src = jsCssAssets[i];
}
}
else if (isFireFox) {
for (var i = 0; i < jsCssAssets.length; i++) {
var o = document.createElement("object");
o.data = jsCssAssets[i];
o.width = o.height = 0;
document.body.appendChild(o);
}
}
}

var onload = function () {
setTimeout(prefetchTYPAssets, 2000);
};
if (window.addEventListener) {
window.addEventListener("load", onload);
} else if (window.attachEvent) { /* for <= IE 8 */
window.attachEvent("onload", onload);
}
</script>

<input type="hidden" name="1click-tsdelta" id="1click-tsdelta">
<script type="text/javascript">
var ocInitTimestamp = 1730866866;
</script>








<!--&&&Portal&Delimite-->
<script>
window.P && P.now('sp.load.js').execute(function (jsObj) {
if (!jsObj) {
P.declare('sp.load.js', {});
}
});  
</script>

<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-atf -->
<!-- sp:feature:nav-btf -->
<!-- NAVYAAN BTF START -->







<script type="text/javascript">
window.$Nav && $Nav.when("data").run(function (data) {
data({
"accountListContent": { "html": "<div id='nav-al-container'><div id='nav-al-signin'><div id='nav-flyout-ya-signin' class='nav-flyout-content nav-flyout-accessibility'><a href='https://www.amazon.com.au/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com.au%2Fdp%2FB0BF75VM4T%2F%3F_encoding%3DUTF8%26_encoding%3DUTF8%26content-id%3Damzn1.sym.dc467fb9-460f-44a9-978e-31ef8ab5d01b%26pd_rd_r%3D93b1be2d-16a4-4233-b6ac-030dcacef9b0%26pd_rd_w%3D9eoTE%26pd_rd_wg%3DSkOy9%26pf_rd_p%3Ddc467fb9-460f-44a9-978e-31ef8ab5d01b%26pf_rd_r%3DAKTF0M190GGQFMHZZWX0%26ref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=auflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' rel='nofollow' class='nav-action-signin-button' data-nav-role='signin' data-nav-ref='nav_signin'><span class='nav-action-inner'>Sign in</span></a><div id='nav-flyout-ya-newCust' class='nav_pop_new_cust nav-flyout-content nav-flyout-accessibility'>New customer? <a href='https://www.amazon.com.au/ap/register?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com.au%2Fdp%2FB0BF75VM4T%2F%3F_encoding%3DUTF8%26_encoding%3DUTF8%26content-id%3Damzn1.sym.dc467fb9-460f-44a9-978e-31ef8ab5d01b%26pd_rd_r%3D93b1be2d-16a4-4233-b6ac-030dcacef9b0%26pd_rd_w%3D9eoTE%26pd_rd_wg%3DSkOy9%26pf_rd_p%3Ddc467fb9-460f-44a9-978e-31ef8ab5d01b%26pf_rd_r%3DAKTF0M190GGQFMHZZWX0%26ref_%3Dnav_newcust&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=auflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' rel='nofollow' class='nav-a' aria-label='New to Amazon? Create an account'>Start here.</a></div></div></div><div id='nav-al-wishlist' class='nav-al-column nav-tpl-itemList nav-flyout-content nav-flyout-accessibility'><div class='nav-title' id='nav-al-title' role='heading' aria-level='6'>Your Lists</div><a href='/hz/wishlist/ls?triggerElementID=createList&ref_=nav_ListFlyout_navFlyout_createList_lv_redirect' class='nav-link nav-item'><span class='nav-text'>Create a List</span></a> <a href='/baby-reg?ref_=nav_ListFlyout_gno_bw' class='nav-link nav-item'><span class='nav-text'>Baby Wish List</span></a></div><div id='nav-al-your-account' class='nav-al-column nav-template nav-flyout-content nav-tpl-itemList nav-flyout-accessibility'><div class='nav-title' role='heading' aria-level='6'>Your Account</div><a href='/gp/css/homepage.html?ref_=nav_AccountFlyout_ya' class='nav-link nav-item'><span class='nav-text'>Your Account</span></a> <a id='nav_prefetch_yourorders' href='/gp/css/order-history?ref_=nav_AccountFlyout_orders' class='nav-link nav-item'><span class='nav-text'>Your Orders</span></a> <a href='/gp/yourstore?ref_=nav_AccountFlyout_recs' class='nav-link nav-item'><span class='nav-text'>Your Recommendations</span></a> <a href='/gp/subs/primeclub/account/homepage.html?ref_=nav_youraccount_prime' class='nav-link nav-item'><span class='nav-text'>Your Prime Membership</span></a> <a href='/hz5/yourmembershipsandsubscriptions?ref_=nav_AccountFlyout_digital_subscriptions' class='nav-link nav-item'><span class='nav-text'>Your Memberships & Subscriptions</span></a> <a href='/auto-deliveries?ref_=nav_AccountFlyout_sns' class='nav-link nav-item'><span class='nav-text'>Your Subscribe & Save items</span></a> <a href='https://sell.amazon.com.au/?refTag=sell&ld=AZAUSOAYA' class='nav-link nav-item'><span class='nav-text'>Your Seller Account</span></a> <a href='/yourpets?ref_=nav_AccountFlyout_petprofiles' class='nav-link nav-item'><span class='nav-text'>Your Pets</span></a> <a href='/hz/mycd/myx?pageType=content&ref_=nav_AccountFlyout_myk' class='nav-link nav-item'><span class='nav-text'>Manage Your Content and Devices</span></a> <a href='https://music.amazon.com.au?ref=nav_youraccount_cldplyr' class='nav-link nav-item'><span class='nav-text'>Your Music</span></a> <a href='/gp/mas/your-account/myapps?ref_=nav_AccountFlyout_aad' class='nav-link nav-item'><span class='nav-text'>Your Apps & Devices</span></a> <a href='/gp/video/ssoredirect?pvp=/ref%3D_apv&ref_=nav_AccountFlyout__apv' class='nav-link nav-item'><span class='nav-text'>Your Prime Video</span></a> <a href='/photos?ref_=nav_AccountFlyout_photos' class='nav-link nav-item'><span class='nav-text'>Your Amazon Photos</span></a> <a href='/kindle-dbs/ku/ku-central?ref_=nav_AccountFlyout_ku' class='nav-link nav-item'><span class='nav-text'>Your Kindle Unlimited</span></a></div></div>" },
"tooltipContent": { "html": "" },
"signinContent": { "html": "<div id='nav-signin-tooltip'><a href='https://www.amazon.com.au/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com.au%2Fdp%2FB0BF75VM4T%2F%3F_encoding%3DUTF8%26_encoding%3DUTF8%26content-id%3Damzn1.sym.dc467fb9-460f-44a9-978e-31ef8ab5d01b%26pd_rd_r%3D93b1be2d-16a4-4233-b6ac-030dcacef9b0%26pd_rd_w%3D9eoTE%26pd_rd_wg%3DSkOy9%26pf_rd_p%3Ddc467fb9-460f-44a9-978e-31ef8ab5d01b%26pf_rd_r%3DAKTF0M190GGQFMHZZWX0%26ref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=auflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' class='nav-action-signin-button' data-nav-role='signin' data-nav-ref='nav_custrec_signin'><span class='nav-action-inner'>Sign in</span></a><div class='nav-signin-tooltip-footer'>New customer? <a href='https://www.amazon.com.au/ap/register?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com.au%2Fdp%2FB0BF75VM4T%2F%3F_encoding%3DUTF8%26_encoding%3DUTF8%26content-id%3Damzn1.sym.dc467fb9-460f-44a9-978e-31ef8ab5d01b%26pd_rd_r%3D93b1be2d-16a4-4233-b6ac-030dcacef9b0%26pd_rd_w%3D9eoTE%26pd_rd_wg%3DSkOy9%26pf_rd_p%3Ddc467fb9-460f-44a9-978e-31ef8ab5d01b%26pf_rd_r%3DAKTF0M190GGQFMHZZWX0%26ref_%3Dnav_custrec_newcust&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=auflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' class='nav-a' aria-label='New to Amazon? Create an account'>Start here.</a></div></div>" },
"templates": { "itemList": "<# var hasColumns = (function () {  var checkColumns = function (_items) {    if (!_items) {      return false;    }    for (var i=0; i<_items.length; i++) {      if (_items[i].columnBreak || (_items[i].items && checkColumns(_items[i].items))) {        return true;      }    }    return false;  };  return checkColumns(items);}()); #><# if(hasColumns) { #>  <# if(items[0].image && items[0].image.src) { #>    <div class='nav-column nav-column-first nav-column-image'>  <# } else if (items[0].greeting) { #>    <div class='nav-column nav-column-first nav-column-greeting'>  <# } else { #>    <div class='nav-column nav-column-first'>  <# } #><# } #><# var renderItems = function(items) { #>  <# jQuery.each(items, function (i, item) { #>    <# if(hasColumns && item.columnBreak) { #>      <# if(item.image && item.image.src) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-image'>      <# } else if (item.greeting) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-greeting'>      <# } else { #>        </div><div class='nav-column nav-column-notfirst nav-column-break'>      <# } #>    <# } #>    <# if(item.dividerBefore) { #>      <div class='nav-divider'></div>    <# } #>    <# if(item.text || item.content) { #>      <# if(item.url) { #>        <a href='<#=item.url #>' class='nav-link      <# } else {#>        <span class='      <# } #>      <# if(item.panelKey) { #>        nav-hasPanel      <# } #>      <# if(item.items) { #>        nav-title      <# } #>      <# if(item.decorate == 'carat') { #>        nav-carat      <# } #>      <# if(item.decorate == 'nav-action-button') { #>        nav-action-button      <# } #>      nav-item'      <# if(item.extra) { #>        <#=item.extra #>      <# } #>      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      <# if(item.dataNavRole) { #>        data-nav-role='<#=item.dataNavRole #>'      <# } #>      <# if(item.dataNavRef) { #>        data-nav-ref='<#=item.dataNavRef #>'      <# } #>      <# if(item.panelKey) { #>        data-nav-panelkey='<#=item.panelKey #>'        role='navigation'        aria-label='<#=item.text#>'      <# } #>      <# if(item.subtextKey) { #>        data-nav-subtextkey='<#=item.subtextKey #>'      <# } #>      <# if(item.image && item.image.height >16) { #>        style='line-height:<#=item.image.height #>px;'      <# } #>      >      <# if(item.decorate == 'carat') { #>        <i class='nav-icon'></i>      <# } #>      <# if(item.image && item.image.src) { #>        <img class='nav-image' src='<#=item.image.src #>' style='height:<#=item.image.height #>px; width:<#=item.image.width #>px;' />      <# } #>      <# if(item.text) { #>        <span class='nav-text<# if(item.classname) { #> <#=item.classname #><# } #>'><#=item.text#><# if(item.badgeText) { #>          <span class='nav-badge'><#=item.badgeText#></span>        <# } #></span>      <# } else if (item.content) { #>        <span class='nav-content'><# jQuery.each(item.content, function (j, cItem) { #><# if(cItem.url && cItem.text) { #><a href='<#=cItem.url #>' class='nav-a'><#=cItem.text #></a><# } else if (cItem.text) { #><#=cItem.text#><# } #><# }); #></span>      <# } #>      <# if(item.subtext) { #>        <span class='nav-subtext'><#=item.subtext #></span>      <# } #>      <# if(item.url) { #>        </a>      <# } else {#>        </span>      <# } #>    <# } #>    <# if(item.image && item.image.src) { #>      <# if(item.url) { #>        <a href='<#=item.url #>'>       <# } #>      <img class='nav-image'      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      src='<#=item.image.src #>' <# if (item.alt) { #> alt='<#= item.alt #>'<# } #>/>      <# if(item.url) { #>        </a>       <# } #>    <# } #>    <# if(item.items) { #>      <div class='nav-panel'> <# renderItems(item.items); #> </div>    <# } #>  <# }); #><# }; #><# renderItems(items); #><# if(hasColumns) { #>  </div><# } #>", "subnav": "<# if (obj && obj.type === 'vertical') { #>  <# jQuery.each(obj.rows, function (i, row) { #>    <# if (row.flyoutElement === 'button') { #>      <div class='nav_sv_fo_v_button'        <# if (row.elementStyle) { #>          style='<#= row.elementStyle #>'        <# } #>      >        <a href='<#=row.url #>' class='nav-action-button nav-sprite'>          <#=row.text #>        </a>      </div>    <# } else if (row.flyoutElement === 'list' && row.list) { #>      <# jQuery.each(row.list, function (j, list) { #>        <div class='nav_sv_fo_v_column <#=(j === 0) ? 'nav_sv_fo_v_first' : '' #>'>          <ul class='<#=list.elementClass #>'>          <# jQuery.each(list.linkList, function (k, link) { #>            <# if (k === 0) { link.elementClass += ' nav_sv_fo_v_first'; } #>            <li class='<#=link.elementClass #>'>              <# if (link.url) { #>                <a href='<#=link.url #>' class='nav_a'><#=link.text #></a>              <# } else { #>                <span class='nav_sv_fo_v_span'><#=link.text #></span>              <# } #>            </li>          <# }); #>          </ul>        </div>      <# }); #>    <# } else if (row.flyoutElement === 'link') { #>      <# if (row.topSpacer) { #>        <div class='nav_sv_fo_v_clear'></div>      <# } #>      <div class='<#=row.elementClass #>'>        <a href='<#=row.url #>' class='nav_sv_fo_v_lmargin nav_a'>          <#=row.text #>        </a>      </div>    <# } #>  <# }); #><# } else if (obj) { #>  <div class='nav_sv_fo_scheduled'>    <#= obj #>  </div><# } #>", "htmlList": "<# jQuery.each(items, function (i, item) { #>  <div class='nav-item'>    <#=item #>  </div><# }); #>" }
})
})
</script>

<script type="text/javascript">
window.$Nav && $Nav.declare('config.flyoutURL', null);
window.$Nav && $Nav.declare('btf.lite');
window.$Nav && $Nav.declare('btf.full');
window.$Nav && $Nav.declare('btf.exists');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).register('navCF');
</script>

<!-- NAVYAAN BTF END -->
<!-- sp:end-feature:nav-btf -->
<!-- sp:feature:host-btf -->


















<link rel="stylesheet"
href="https://m.media-amazon.com/images/I/01FL7JU2DtL.css?AUIClients/DetailPageProductSpecDepthAsset&6MjQ7uH9#1025785-T1" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/21T5HeBxb2L.js?AUIClients/AXFClientPluginAsset" />
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/21SWk05%2B6qL.js?AUIClients/DetailPageProductSpecDepthAsset&m52tM9b7#1025785-T1.1041430-T1" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/21T5HeBxb2L.js?AUIClients/AXFClientPluginAsset');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/21SWk05%2B6qL.js?AUIClients/DetailPageProductSpecDepthAsset&m52tM9b7#1025785-T1.1041430-T1');
</script>

</div>

</div>
</div>

<!-- htmlEndMarker -->














<!-- sp:end-feature:host-btf -->
<!-- sp:feature:aui-preload -->
<!-- sp:end-feature:aui-preload -->
<!-- sp:feature:nav-footer -->

<!-- NAVYAAN FOOTER START -->
<!-- WITH MOZART -->


<div id="sis_pixel_r2" aria-hidden="true"
style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"></div>
<script>(function (a, b) { a.attachEvent ? a.attachEvent("onload", b) : a.addEventListener && a.addEventListener("load", b, !1) })(window, function () { setTimeout(function () { var el = document.getElementById("sis_pixel_r2"); el && (el.innerHTML = '<iframe id="DAsis" src="//aax-fe.amazon-adsystem.com/s/iu3?d=amazon.com.au&slot=navFooter&a2=0101da447ed30541315ac1ddcc0dc6bf71ce642da004ac68f7ec27ad6b4a673ef842&old_oo=0&ts=1730866866201&s=ARbzZk7Py7gZ9qoIquXpChQ4mbWF8wREPUv4YMT-pjTj&gdpr_consent=&gdpr_consent_avl=&cb=1730866866201" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" tabindex="-1" sandbox></iframe>'); var event = new Event("SISPixelCardLoaded"); document.dispatchEvent(event); }, 300) });</script>

<!-- NAVYAAN FOOTER END -->

<!-- sp:end-feature:nav-footer -->
<!-- sp:feature:configured-sitewide-assets -->
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/41enQvbo0+L.js?AUIClients/AmazonLightsaberPageAssets#1061544-T1" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/41enQvbo0+L.js?AUIClients/AmazonLightsaberPageAssets#1061544-T1');
});
</script>
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/11+zeBoqC-L.js?AUIClients/WebFlowIngressJs" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11+zeBoqC-L.js?AUIClients/WebFlowIngressJs');
});
</script>
<!-- sp:end-feature:configured-sitewide-assets -->
<!-- sp:feature:customer-behavior-js -->
<script type="text/javascript">if (window.ue && ue.tag) { ue.tag('FWCIMEnabled'); }</script>
<link rel="preload" as="script" crossorigin="anonymous"
href="https://m.media-amazon.com/images/I/81LmaXL9x7L.js?AUIClients/FWCIMAssets" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function () {
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/81LmaXL9x7L.js?AUIClients/FWCIMAssets');
});
</script>
<!-- sp:end-feature:customer-behavior-js -->
<!-- sp:feature:csm:body-close -->
<div id='be' style="display:none;visibility:hidden;">
<form name='ue_backdetect' action="get"><input type="hidden" name='ue_back' value='1' /></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {
(function (e, c) { function h(b, a) { f.push([b, a]) } function g(b, a) { if (b) { var c = e.head || e.getElementsByTagName("head")[0] || e.documentElement, d = e.createElement("script"); d.async = "async"; d.src = b; d.setAttribute("crossorigin", "anonymous"); a && a.onerror && (d.onerror = a.onerror); a && a.onload && (d.onload = a.onload); c.insertBefore(d, c.firstChild) } } function k() { ue.uels = g; for (var b = 0; b < f.length; b++) { var a = f[b]; g(a[0], a[1]) } ue.deffered = 1 } var f = []; c.ue && (ue.uels = h, c.ue.attach && c.ue.attach("load", k)) })(document, window);


if (window.ue && window.ue.uels) {
var cel_widgets = [{ "c": "celwidget" }, { "s": "#nav-swmslot > div", "id_gen": function (elem, index) { return 'nav_sitewide_msg'; } }, { "c": "feature" }, { "id": "detail-ilm_div" }];

ue.uels("https://images-fe.ssl-images-amazon.com/images/I/31bJewCvY-L.js");
}
var ue_mbl = ue_csm.ue.exec(function (h, a) {
function s(c) {
b = c || {}; a.AMZNPerformance = b; b.transition = b.transition || {}; b.timing = b.timing || {}; if (a.csa) { var d; b.timing.transitionStart && (d = b.timing.transitionStart); b.timing.processStart && (d = b.timing.processStart); d && (csa("PageTiming")("mark", "nativeTransitionStart", d), csa("PageTiming")("mark", "transitionStart", d)) } h.ue.exec(t, "csm-android-check")() && b.tags instanceof Array && (c = -1 != b.tags.indexOf("usesAppStartTime") || b.transition.type ? !b.transition.type && -1 <
b.tags.indexOf("usesAppStartTime") ? "warm-start" : void 0 : "view-transition", c && (b.transition.type = c)); n = null; "reload" === e._nt && h.ue_orct || "intrapage-transition" === e._nt ? u(b) : "undefined" === typeof e._nt && f && f.timing && f.timing.navigationStart && a.history && "function" === typeof a.History && "object" === typeof a.history && a.history.length && 1 != a.history.length && (b.timing.transitionStart = f.timing.navigationStart); p && e.ssw(q, "" + (b.timing.transitionStart || n || "")); c = b.transition; d = e._nt ? e._nt : void 0; c.subType = d; a.ue &&
a.ue.tag && a.ue.tag("has-AMZNPerformance"); e.isl && a.uex && a.uex("at", "csm-timing"); v()
} function w(c) { a.ue && a.ue.count && a.ue.count("csm-cordova-plugin-failed", 1) } function t() { return a.cordova && a.cordova.platformId && "android" == a.cordova.platformId } function u() {
if (p) { var c = e.ssw(q), a = function () { }, x = e.count || a, a = e.tag || a, k = b.timing.transitionStart, g = c && !c.e && c.val; n = c = g ? +c.val : null; k && g && k > c ? (x("csm.jumpStart.mtsDiff", k - c || 0), a("csm-rld-mts-gt")) : k && g ? a("csm-rld-mts-leq") : g ? k || a("csm-rld-mts-no-new") : a("csm-rld-mts-no-old") } f &&
f.timing && f.timing.navigationStart ? b.timing.transitionStart = f.timing.navigationStart : delete b.timing.transitionStart
} function v() { try { a.P.register("AMZNPerformance", function () { return b }) } catch (c) { } } function r() {
if (!b) return ""; ue_mbl.cnt = null; var c = b.timing, d = b.transition, d = ["mts", l(c.transitionStart), "mps", l(c.processStart), "mtt", d.type, "mtst", d.subType, "mtlt", d.launchType]; a.ue && a.ue.tag && (c.fr_ovr && a.ue.tag("fr_ovr"), c.fcp_ovr && a.ue.tag("fcp_ovr"), d.push("fr_ovr", l(c.fr_ovr), "fcp_ovr", l(c.fcp_ovr)));
for (var c = "", e = 0; e < d.length; e += 2) { var f = d[e], g = d[e + 1]; "undefined" !== typeof g && (c += "&" + f + "=" + g) } return c
} function l(a) { if ("undefined" !== typeof a && "undefined" !== typeof m) return a - m } function y(a, d) { b && (m = d, b.timing.transitionStart = a, b.transition.type = "view-transition", b.transition.subType = "ajax-transition", b.transition.launchType = "normal", ue_mbl.cnt = r) } var e = h.ue || {}, m = h.ue_t0, q = "csm-last-mts", p = 1 === h.ue_sswmts, n, f = a.performance, b; if (a.P && a.P.when && a.P.register) return 1 === a.ue_fnt && (m = a.aPageStart ||
h.ue_t0), a.P.when("CSMPlugin").execute(function (a) { a.buildAMZNPerformance && a.buildAMZNPerformance({ successCallback: s, failCallback: w }) }), { cnt: r, ajax: y }
}, "mobile-timing")(ue_csm, ue_csm.window);

(function (d) { d._uess = function () { var a = ""; screen && screen.width && screen.height && (a += "&sw=" + screen.width + "&sh=" + screen.height); var b = function (a) { var b = document.documentElement["client" + a]; return "CSS1Compat" === document.compatMode && b || document.body["client" + a] || b }, c = b("Width"), b = b("Height"); c && b && (a += "&vw=" + c + "&vh=" + b); return a } })(ue_csm);

(function (a) {
function d(a) { c && c("log", a) } var b = document.ue_backdetect, c = a.csa && a.csa("Errors", { producerId: "csa", logOptions: { ent: "all" } }); a.ue_err.buffer && c && (a.ue_err.buffer.forEach(d), a.ue_err.buffer.push = d); b && b.ue_back && a.ue && (a.ue.bfini = b.ue_back.value); a.uet && a.uet("be"); a.onLdEnd && (window.addEventListener ? window.addEventListener("load", a.onLdEnd, !1) : window.attachEvent && window.attachEvent("onload", a.onLdEnd)); a.ueh && a.ueh(0, window, "load", a.onLd, 1); a.ue && a.ue.tag && (a.ue_furl ? (b = a.ue_furl.replace(/\./g,
"-"), a.ue.tag(b)) : a.ue.tag("nofls"))
})(ue_csm);

(function (g, h) { function d(a, d) { var b = {}; if (!e || !f) try { var c = h.sessionStorage; c ? a && ("undefined" !== typeof d ? c.setItem(a, d) : b.val = c.getItem(a)) : f = 1 } catch (g) { e = 1 } e && (b.e = 1); return b } var b = g.ue || {}, a = "", f, e, c, a = d("csmtid"); f ? a = "NA" : a.e ? a = "ET" : (a = a.val, a || (a = b.oid || "NI", d("csmtid", a)), c = d(b.oid), c.e || (c.val = c.val || 0, d(b.oid, c.val + 1)), b.ssw = d); b.tabid = a })(ue_csm, ue_csm.window);

(function (a) {
var e = { rc: 1, hob: 1, hoe: 1, ntd: 1, rd_: 1, _rd: 1 }; "function" === typeof window.addEventListener && window.addEventListener("pageshow", function (b) {
if (b && b.persisted && (b = +new Date, b = { clickTime: b - 1, pageVisible: b }, "object" === typeof b && "object" === typeof a.ue.markers && "object" === typeof a.ue && "function" === typeof a.uex)) {
if ("function" === typeof a.uet) {
for (var c in a.ue.markers) !a.ue.markers.hasOwnProperty(c) || c in e || a.uet(c, void 0, void 0, b.pageVisible); a.uet("tc", void 0, void 0, b.clickTime); a.uet("ty", void 0,
void 0, b.clickTime + 2)
} (c = document.ue_backdetect) && c.ue_back && (a.ue.bfini = +c.ue_back.value + 1); a.ue.isBFonMshop = !0; a.ue.isBFCache = !0; a.ue.t0 = b.clickTime; a.ue.viz = ["visible:0"]; "function" === typeof a.ue.tag && (a.ue.tag("cacheSourceMemory"), a.ue.tag("history-navigation-page-cache")); c = ue_csm.csa && ue_csm.csa("SPA"); var d = ue_csm.csa && ue_csm.csa("PageTiming"); c && d && (c("newPage", { transitionType: "history-navigation-page-cache" }, { keepPageAttributes: !0 }), d("mark", "transitionStart", b.clickTime)); "function" === typeof a.uex &&
a.uex("ld", void 0, void 0, a.ue.t.ld); delete a.ue.isBFonMshop; delete a.ue.isBFCache
}
})
})(ue_csm);

ue_csm.ue.exec(function (e, f) { var a = e.ue || {}, b = a._wlo, d; if (a.ssw) { d = a.ssw("CSM_previousURL").val; var c = f.location, b = b ? b : c && c.href ? c.href.split("#")[0] : void 0; c = (b || "") === a.ssw("CSM_previousURL").val; !c && b && a.ssw("CSM_previousURL", b); d = c ? "reload" : d ? "intrapage-transition" : "first-view" } else d = "unknown"; a._nt = d }, "NavTypeModule")(ue_csm, window);
ue_csm.ue.exec(function (c, a) { function g(a) { a.run(function (e) { d.tag("csm-feature-" + a.name + ":" + e); d.isl && c.uex("at") }) } if (a.addEventListener) for (var d = c.ue || {}, f = [{ name: "touch-enabled", run: function (b) { var e = function () { a.removeEventListener("touchstart", c, !0); a.removeEventListener("mousemove", d, !0) }, c = function () { b("true"); e() }, d = function () { b("false"); e() }; a.addEventListener("touchstart", c, !0); a.addEventListener("mousemove", d, !0) } }], b = 0; b < f.length; b++)g(f[b]) }, "csm-features")(ue_csm, window);


(function (a, e) { function d(a) { b && b("recordCounter", a.c, a.v) } var c = e.images, b = a.csa && a.csa("Metrics", { producerId: "csa" }); c && c.length && a.ue.count("totalImages", c.length); a.ue.cv.buffer && b && (a.ue.cv.buffer.forEach(d), a.ue.cv.buffer.push = d) })(ue_csm, document);
(function (b) {
function c() { var d = []; a.log && a.log.isStub && a.log.replay(function (a) { e(d, a) }); a.clog && a.clog.isStub && a.clog.replay(function (a) { e(d, a) }); d.length && (a._flhs += 1, n(d), p(d)) } function g() { a.log && a.log.isStub && (a.onflush && a.onflush.replay && a.onflush.replay(function (a) { a[0]() }), a.onunload && a.onunload.replay && a.onunload.replay(function (a) { a[0]() }), c()) } function e(d, b) { var c = b[1], f = b[0], e = {}; a._lpn[c] = (a._lpn[c] || 0) + 1; e[c] = f; d.push(e) } function n(b) {
q && (a._lpn.csm = (a._lpn.csm || 0) + 1, b.push({
csm: {
k: "chk",
f: a._flhs, l: a._lpn, s: "inln"
}
}))
} function p(a) { if (h) a = k(a), b.navigator.sendBeacon(l, a);else { a = k(a); var c = new b[f]; c.open("POST", l, !0); c.setRequestHeader && c.setRequestHeader("Content-type", "text/plain"); c.send(a) } } function k(a) { return JSON.stringify({ rid: b.ue_id, sid: b.ue_sid, mid: b.ue_mid, mkt: b.ue_mkt, sn: b.ue_sn, reqs: a }) } var f = "XMLHttpRequest", q = 1 === b.ue_ddq, a = b.ue, r = b[f] && "withCredentials" in new b[f], h = b.navigator && b.navigator.sendBeacon, l = "//" + b.ue_furl + "/1/batch/1/OE/", m = b.ue_fci_ft || 5E3; a && (r || h) &&
(a._flhs = a._flhs || 0, a._lpn = a._lpn || {}, a.attach && (a.attach("beforeunload", a.exec(g, "fcli-bfu")), a.attach("pagehide", a.exec(g, "fcli-ph"))), m && b.setTimeout(a.exec(c, "fcli-t"), m), a._ffci = a.exec(c))
})(window);


(function (k, c) {
function l(a, b) { return a.filter(function (a) { return a.initiatorType == b }) } function f(a, c) { if (b.t[a]) { var g = b.t[a] - b._t0, e = c.filter(function (a) { return 0 !== a.responseEnd && m(a) < g }), f = l(e, "script"), h = l(e, "link"), k = l(e, "img"), n = e.map(function (a) { return a.name.split("/")[2] }).filter(function (a, b, c) { return a && c.lastIndexOf(a) == b }), q = e.filter(function (a) { return a.duration < p }), s = g - Math.max.apply(null, e.map(m)) < r | 0; "af" == a && (b._afjs = f.length); return a + ":" + [e[d], f[d], h[d], k[d], n[d], q[d], s].join("-") } }
function m(a) { return a.responseEnd - (b._t0 - c.timing.navigationStart) } function n() { var a = c[h]("resource"), d = f("cf", a), g = f("af", a), a = f("ld", a); delete b._rt; b._ld = b.t.ld - b._t0; b._art && b._art(); return [d, g, a].join("_") } var p = 20, r = 50, d = "length", b = k.ue, h = "getEntriesByType"; b._rre = m; b._rt = c && c.timing && c[h] && n
})(ue_csm, window.performance);


(function (c, d) { var b = c.ue, a = d.navigator; b && b.tag && a && (a = a.connection || a.mozConnection || a.webkitConnection) && a.type && b.tag("netInfo:" + a.type) })(ue_csm, window);


(function (c, d) {
function h(a, b) { for (var c = [], d = 0; d < a.length; d++) { var e = a[d], f = b.encode(e); if (e[k]) { var g = b.metaSep, e = e[k], l = b.metaPairSep, h = [], m = void 0; for (m in e) e.hasOwnProperty(m) && h.push(m + "=" + e[m]); e = h.join(l); f += g + e } c.push(f) } return c.join(b.resourceSep) } function s(a) {
var b = a[k] = a[k] || {}; b[t] || (b[t] = c.ue_mid); b[u] || (b[u] = c.ue_sid); b[f] || (b[f] = c.ue_id); b.csm = 1; a = "//" + c.ue_furl + "/1/" + a[v] + "/1/OP/" + a[w] + "/" + a[x] + "/" + h([a], y); if (n) try { n.call(d[p], a) } catch (g) { c.ue.sbf = 1, (new Image).src = a } else (new Image).src =
a
} function q() { g && g.isStub && g.replay(function (a, b, c) { a = a[0]; b = a[k] = a[k] || {}; b[f] = b[f] || c; s(a) }); l.impression = s; g = null } if (!(1 < c.ueinit)) {
var k = "metadata", x = "impressionType", v = "foresterChannel", w = "programGroup", t = "marketplaceId", u = "session", f = "requestId", p = "navigator", l = c.ue || {}, n = d[p] && d[p].sendBeacon, r = function (a, b, c, d) { return { encode: d, resourceSep: a, metaSep: b, metaPairSep: c } }, y = r("", "?", "&", function (a) { return h(a.impressionData, z) }), z = r("/", ":", ",", function (a) {
return a.featureName + ":" + h(a.resources,
A)
}), A = r(",", "@", "|", function (a) { return a.id }), g = l.impression; n ? q() : (l.attach("load", q), l.attach("beforeunload", q)); try { d.P && d.P.register && d.P.register("impression-client", function () { }) } catch (B) { c.ueLogError(B, { logLevel: "WARN" }) }
}
})(ue_csm, window);



var ue_pty = "Detail";

var ue_spty = "Kindle_HW";

var ue_pti = "B0BF75VM4T";


var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function (y, a) {
function t() { if (d && f) { var a; a: { try { a = d.getItem(g); break a } catch (c) { } a = void 0 } if (a) return b = a, !0 } return !1 } function u() { if (a.fetch) fetch(m).then(function (a) { if (!a.ok) throw Error(a.statusText); return a.text ? a.text() : null }).then(function (b) { b ? (-1 < b.indexOf("window.ue_adb_chk = 1") && (a.ue_adb_chk = 1), n()) : h() })["catch"](h); else e.uels(m, { onerror: h, onload: n }) } function h() { b = k; l(); if (f) try { d.setItem(g, b) } catch (a) { } } function n() {
b = 1 === a.ue_adb_chk ? p : k; l(); if (f) try {
d.setItem(g,
b)
} catch (c) { }
} function q() { a.ue_adb_rtla && c && 0 < c.ec && !1 === r && (c.elh = null, ueLogError({ m: "Hit Info", fromOnError: 1 }, { logLevel: "INFO", adb: b }), r = !0) } function l() { e.tag(b); e.isl && a.uex && uex("at", b); s && s.updateCsmHit("adb", b); c && 0 < c.ec ? q() : a.ue_adb_rtla && c && (c.elh = q) } function v() { return b } if (a.ue_adb) {
a.ue_fadb = a.ue_fadb || 10; var e = a.ue, k = "adblk_yes", p = "adblk_no", m = "https://m.media-amazon.com/images/G/01/csm/showads.v2.js?category=ad&adstype=-ad-column-&ad_size=-housead-", b = "adblk_unk", d; a: {
try {
d = a.localStorage;
break a
} catch (z) { } d = void 0
} var g = "csm:adb", c = a.ue_err, s = e.cookie, f = void 0 !== a.localStorage, w = Math.random() > 1 - 1 / a.ue_fadb, r = !1, x = t(); w || !x ? u() : l(); a.ue_isAdb = v; a.ue_isAdb.unk = "adblk_unk"; a.ue_isAdb.no = p; a.ue_isAdb.yes = k
}
}, "adb")(document, window);




(function (c, l, m) {
function h(a) { if (a) try { if (a.id) return "//*[@id='" + a.id + "']"; var b, d = 1, e; for (e = a.previousSibling; e; e = e.previousSibling)e.nodeName === a.nodeName && (d += 1); b = d; var c = a.nodeName; 1 !== b && (c += "[" + b + "]"); a.parentNode && (c = h(a.parentNode) + "/" + c); return c } catch (f) { return "DETACHED" } } function f(a) { if (a && a.getAttribute) return a.getAttribute(k) ? a.getAttribute(k) : f(a.parentElement) } var k = "data-cel-widget", g = !1, d = []; (c.ue || {}).isBF = function () {
try {
var a = JSON.parse(localStorage["csm-bf"] || "[]"), b = 0 <= a.indexOf(c.ue_id);
a.unshift(c.ue_id); a = a.slice(0, 20); localStorage["csm-bf"] = JSON.stringify(a); return b
} catch (d) { return !1 }
}(); c.ue_utils = {
getXPath: h, getFirstAscendingWidget: function (a, b) { c.ue_cel && c.ue_fem ? !0 === g ? b(f(a)) : d.push({ element: a, callback: b }) : b() }, notifyWidgetsLabeled: function () { if (!1 === g) { g = !0; for (var a = f, b = 0; b < d.length; b++)if (d[b].hasOwnProperty("callback") && d[b].hasOwnProperty("element")) { var c = d[b].callback, e = d[b].element; "function" === typeof c && "function" === typeof a && c(a(e)) } d = null } }, extractStringValue: function (a) {
if ("string" ===
typeof a) return a
}
}
})(ue_csm, window, document);


(function (a) {
a.ue_cel || (a.ue_cel = function () {
function m(a, r) { r ? r.r = u : r = { r: u, c: 1 }; D || (!ue_csm.ue_sclog && r.clog && b.clog ? b.clog(a, r.ns || s, r) : r.glog && b.glog ? b.glog(a, r.ns || s, r) : b.log(a, r.ns || s, r)) } function n(a, b) { "function" === typeof p && p("log", { schemaId: t + ".RdCSI.1", eventType: a, clientData: b }, { ent: { page: ["requestId"] } }) } function c() { var a = q.length; if (0 < a) { for (var r = [], c = 0; c < a; c++) { var d = q[c].api; d.ready() ? (d.on({ ts: b.d, ns: s }), g.push(q[c]), m({ k: "mso", n: q[c].name, t: b.d() })) : r.push(q[c]) } q = r } } function f() {
if (!f.executed) {
for (var a =
0; a < g.length; a++)g[a].api.off && g[a].api.off({ ts: b.d, ns: s }); B(); m({ k: "eod", t0: b.t0, t: b.d() }, { c: 1, il: 1 }); f.executed = 1; for (a = 0; a < g.length; a++)q.push(g[a]); g = []; d(v); d(A)
}
} function B(a) { m({ k: "hrt", t: b.d() }, { c: 1, il: 1, n: a }); y = Math.min(w, e * y); z() } function z() { d(A); A = k(function () { B(!0) }, y) } function x() { f.executed || B() } var l = a.window, k = l.setTimeout, d = l.clearTimeout, e = 1.5, w = l.ue_cel_max_hrt || 3E4, t = "robotdetection", q = [], g = [], s = a.ue_cel_ns || "cel", v, A, b = a.ue, F = a.uet, C = a.uex, u = b.rid, D = a.ue_dsbl_cel, h = l.csa, p, y =
l.ue_cel_hrt_int || 3E3, E = l.requestAnimationFrame || function (a) { a() }; h && (p = h("Events", { producerId: t })); if (b.isBF) m({ k: "bft", t: b.d() }); else {
"function" == typeof F && F("bb", "csmCELLSframework", { wb: 1 }); k(c, 0); b.onunload(f); if (b.onflush) b.onflush(x); v = k(f, 6E5); z(); "function" == typeof C && C("ld", "csmCELLSframework", { wb: 1 }); return {
registerModule: function(a, r) { q.push({ name: a, api: r }); m({ k: "mrg", n: a, t: b.d() }); c() }, reset: function (a) {
m({ k: "rst", t0: b.t0, t: b.d() }); q = q.concat(g); g = []; for (var r = q.length, e = 0; e < r; e++)q[e].api.off(),
q[e].api.reset(); u = a || b.rid; c(); d(v); v = k(f, 6E5); f.executed = 0
}, timeout: function (a, b) { return k(function () { E(function () { f.executed || a() }) }, b) }, log: m, csaEventLog: n, off: f
}
}
}())
})(ue_csm);
(function (a) {
a.ue_pdm || !a.ue_cel || a.ue.isBF || (a.ue_pdm = function () {
function m() {
try {
var b = d.screen; if (b) { var c = { w: b.width, aw: b.availWidth, h: b.height, ah: b.availHeight, cd: b.colorDepth, pd: b.pixelDepth }; g && g.w === c.w && g.h === c.h && g.aw === c.aw && g.ah === c.ah && g.pd === c.pd && g.cd === c.cd || (g = c, g.t = t(), g.k = "sci", F(g), D && h("sci", { h: (g.h || "0") + "" })) } var k = e.body || {}, f = e.documentElement || {}, n = {
w: Math.max(k.scrollWidth || 0, k.offsetWidth || 0, f.clientWidth || 0, f.scrollWidth || 0, f.offsetWidth || 0), h: Math.max(k.scrollHeight ||
0, k.offsetHeight || 0, f.clientHeight || 0, f.scrollHeight || 0, f.offsetHeight || 0)
}; s && s.w === n.w && s.h === n.h || (s = n, s.t = t(), s.k = "doi", F(s)); w = a.ue_cel.timeout(m, q); A += 1
} catch (p) { d.ueLogError && ueLogError(p, { attribution: "csm-cel-page-module", logLevel: "WARN" }) }
} function n() { x("ebl", "default", !1) } function c() { x("efo", "default", !0) } function f() { x("ebl", "app", !1) } function B() { x("efo", "app", !0) } function z() { d.setTimeout(function () { e[E] ? x("ebl", "pageviz", !1) : x("efo", "pageviz", !0) }, 0) } function x(a, b, c) {
v !== c && (F({
k: a,
t: t(), s: b
}, { ff: !0 === c ? 0 : 1 }), D && h(a, { t: (t() || "0") + "", s: b })); v = c
} function l() { b.attach && (p && b.attach(y, z, e), G && P.when("mash").execute(function (a) { a && a.addEventListener && (a.addEventListener("appPause", f), a.addEventListener("appResume", B)) }), b.attach("blur", n, d), b.attach("focus", c, d)) } function k() {
b.detach && (p && b.detach(y, z, e), G && P.when("mash").execute(function (a) { a && a.removeEventListener && (a.removeEventListener("appPause", f), a.removeEventListener("appResume", B)) }), b.detach("blur", n, d), b.detach("focus",
c, d))
} var d = a.window, e = a.document, w, t, q, g, s, v = null, A = 0, b = a.ue, F = a.ue_cel.log, C = a.uet, u = a.uex, D = d.csa, h = a.ue_cel.csaEventLog, p = !!b.pageViz, y = p && b.pageViz.event, E = p && b.pageViz.propHid, G = d.P && d.P.when; "function" == typeof C && C("bb", "csmCELLSpdm", { wb: 1 }); return {
on: function (a) { q = a.timespan || 500; t = a.ts; l(); a = d.location; F({ k: "pmd", o: a.origin, p: a.pathname, t: t() }); m(); "function" == typeof u && u("ld", "csmCELLSpdm", { wb: 1 }) }, off: function (a) { clearTimeout(w); k(); b.count && b.count("cel.PDM.TotalExecutions", A) }, ready: function () {
return e.body &&
a.ue_cel && a.ue_cel.log
}, reset: function () { g = s = null }
}
}(), a.ue_cel && a.ue_cel.registerModule("page module", a.ue_pdm))
})(ue_csm);
(function (a) {
a.ue_vpm || !a.ue_cel || a.ue.isBF || (a.ue_vpm = function () {
function m() { var a = z(), b = { w: k.innerWidth, h: k.innerHeight, x: k.pageXOffset, y: k.pageYOffset }; c && c.w == b.w && c.h == b.h && c.x == b.x && c.y == b.y || (b.t = a, b.k = "vpi", c = b, e(c, { clog: 1 }), s && v("vpi", { t: (c.t || "0") + "", h: (c.h || "0") + "", y: (c.y || "0") + "", w: (c.w || "0") + "", x: (c.x || "0") + "" })); f = 0; x = z() - a; l += 1 } function n() { f || (f = a.ue_cel.timeout(m, B)) } var c, f, B, z, x = 0, l = 0, k = a.window, d = a.ue, e = a.ue_cel.log, w = a.uet, t = a.uex, q = d.attach, g = d.detach, s = k.csa, v = a.ue_cel.csaEventLog;
"function" == typeof w && w("bb", "csmCELLSvpm", { wb: 1 }); return { on: function (a) { z = a.ts; B = a.timespan || 100; m(); q && (q("scroll", n), q("resize", n)); "function" == typeof t && t("ld", "csmCELLSvpm", { wb: 1 }) }, off: function (a) { clearTimeout(f); g && (g("scroll", n), g("resize", n)); d.count && (d.count("cel.VPI.TotalExecutions", l), d.count("cel.VPI.TotalExecutionTime", x), d.count("cel.VPI.AverageExecutionTime", x / l)) }, ready: function () { return a.ue_cel && a.ue_cel.log }, reset: function () { c = void 0 }, getVpi: function () { return c } }
}(), a.ue_cel &&
a.ue_cel.registerModule("viewport module", a.ue_vpm))
})(ue_csm);
(function (a) {
if (!a.ue_fem && a.ue_cel && a.ue_utils) {
var m = a.ue || {}, n = a.window, c = n.document; !m.isBF && !a.ue_fem && c.querySelector && n.getComputedStyle && [].forEach && (a.ue_fem = function () {
function f(a, b) { return a > b ? 3 > a - b : 3 > b - a } function B(a, b) {
var c = n.pageXOffset, d = n.pageYOffset, k; a: {
try {
if (a) {
var e = a.getBoundingClientRect(), g, m = 0 === a.offsetWidth && 0 === a.offsetHeight; c: {
for (var h = a.parentNode, p = e.left || 0, w = e.top || 0, q = e.width || 0, s = e.height || 0; h && h !== document.body;) {
var l; d: {
try {
var r = void 0; if (h) var t = h.getBoundingClientRect(),
r = { x: t.left || 0, y: t.top || 0, w: t.width || 0, h: t.height || 0 }; else r = void 0; l = r; break d
} catch (I) { } l = void 0
} var u = window.getComputedStyle(h), v = "hidden" === u.overflow, x = v || "hidden" === u.overflowX, y = v || "hidden" === u.overflowY, z = w + s - 1 < l.y + 1 || w + 1 > l.y + l.h - 1; if ((p + q - 1 < l.x + 1 || p + 1 > l.x + l.w - 1) && x || z && y) { g = !0; break c } h = h.parentNode
} g = !1
} k = { x: e.left + c || 0, y: e.top + d || 0, w: e.width || 0, h: e.height || 0, d: (m || g) | 0 }
} else k = void 0; break a
} catch (J) { } k = void 0
} if (k && !a.cel_b) a.cel_b = k, D({
n: a.getAttribute(A), w: a.cel_b.w, h: a.cel_b.h, d: a.cel_b.d,
x: a.cel_b.x, y: a.cel_b.y, t: b, k: "ewi", cl: a.className
}, { clog: 1 }); else { if (c = k) c = a.cel_b, d = k, c = d.d === c.d && 1 === d.d ? !1 : !(f(c.x, d.x) && f(c.y, d.y) && f(c.w, d.w) && f(c.h, d.h) && c.d === d.d); c && (a.cel_b = k, D({ n: a.getAttribute(A), w: a.cel_b.w, h: a.cel_b.h, d: a.cel_b.d, x: a.cel_b.x, y: a.cel_b.y, t: b, k: "ewi" }, { clog: 1 })) }
} function z(d, e) {
var f; f = d.c ? c.getElementsByClassName(d.c) : d.id ? [c.getElementById(d.id)] : c.querySelectorAll(d.s); d.w = []; for (var g = 0; g < f.length; g++) {
var h = f[g]; if (h) {
if (!h.getAttribute(A)) {
var l = h.getAttribute("cel_widget_id") ||
(d.id_gen || u)(h, g) || h.id; h.setAttribute(A, l)
} d.w.push(h); k(Q, h, e)
}
} !1 === C && (F++, F === b.length && (C = !0, a.ue_utils.notifyWidgetsLabeled()))
} function x(a, b) { h.contains(a) || D({ n: a.getAttribute(A), t: b, k: "ewd" }, { clog: 1 }) } function l(a) { K.length && ue_cel.timeout(function () { if (s) { for (var b = R(), c = !1; R() - b < g && !c;) { for (c = S; 0 < c-- && 0 < K.length;) { var d = K.shift(); T[d.type](d.elem, d.time) } c = 0 === K.length } U++; l(a) } }, 0) } function k(a, b, c) { K.push({ type: a, elem: b, time: c }) } function d(a, c) {
for (var d = 0; d < b.length; d++)for (var e =
b[d].w || [], h = 0; h < e.length; h++)k(a, e[h], c)
} function e() { M || (M = a.ue_cel.timeout(function () { M = null; var c = v(); d(W, c); for (var e = 0; e < b.length; e++)k(X, b[e], c); 0 === b.length && !1 === C && (C = !0, a.ue_utils.notifyWidgetsLabeled()); l(c) }, q)) } function w() { M || N || (N = a.ue_cel.timeout(function () { N = null; var a = v(); d(Q, a); l(a) }, q)) } function t() { return y && E && h && h.contains && h.getBoundingClientRect && v } var q = 50, g = 4.5, s = !1, v, A = "data-cel-widget", b = [], F = 0, C = !1, u = function () { }, D = a.ue_cel.log, h, p, y, E, G = n.MutationObserver || n.WebKitMutationObserver ||
n.MozMutationObserver, r = !!G, H, I, O = "DOMAttrModified", L = "DOMNodeInserted", J = "DOMNodeRemoved", N, M, K = [], U = 0, S = null, W = "removedWidget", X = "updateWidgets", Q = "processWidget", T, V = n.performance || {}, R = V.now && function () { return V.now() } || function () { return Date.now() }; "function" == typeof uet && uet("bb", "csmCELLSfem", { wb: 1 }); return {
on: function (d) {
function k() {
if (t()) {
T = { removedWidget: x, updateWidgets: z, processWidget: B }; if (r) {
var a = { attributes: !0, subtree:!0 }; H = new G(w); I = new G(e); H.observe(h, a); I.observe(h, {
childList: !0,
subtree: !0
}); I.observe(p, a)
} else y.call(h, O, w), y.call(h, L, e), y.call(h, J, e), y.call(p, L, w), y.call(p, J, w); e()
}
} h = c.body; p = c.head; y = h.addEventListener; E = h.removeEventListener; v = d.ts; b = a.cel_widgets || []; S = d.bs || 5; m.deffered ? k() : m.attach && m.attach("load", k); "function" == typeof uex && uex("ld", "csmCELLSfem", { wb: 1 }); s = !0
}, off: function () {
t() && (I && (I.disconnect(), I = null), H && (H.disconnect(), H = null), E.call(h, O, w), E.call(h, L, e), E.call(h, J, e), E.call(p, L, w), E.call(p, J, w)); m.count && m.count("cel.widgets.batchesProcessed",
U); s = !1
}, ready: function () { return a.ue_cel && a.ue_cel.log }, reset: function () { b = a.cel_widgets || [] }
}
}(), a.ue_cel && a.ue_fem && a.ue_cel.registerModule("features module", a.ue_fem))
}
})(ue_csm);
(function (a) {
!a.ue_mcm && a.ue_cel && a.ue_utils && !a.ue.isBF && (a.ue_mcm = function () {
function m(a, d) {
var e = a.srcElement || a.target || {}, f = { k: n, w: (d || {}).ow || (B.body || {}).scrollWidth, h: (d || {}).oh || (B.body || {}).scrollHeight, t: (d || {}).ots || c(), x: a.pageX, y: a.pageY, p: l.getXPath(e), n: e.nodeName }; z && "function" === typeof z.now && a.timeStamp && (f.dt = (d || {}).odt || z.now() - a.timeStamp, f.dt = parseFloat(f.dt.toFixed(2))); a.button && (f.b = a.button); e.href && (f.r = l.extractStringValue(e.href)); e.id && (f.i = e.id); e.className && e.className.split &&
(f.c = e.className.split(/\s+/)); x(f, { c: 1 })
} var n = "mcm", c, f = a.window, B = f.document, z = f.performance, x = a.ue_cel.log, l = a.ue_utils; return { on: function (k) { c = k.ts; a.ue_cel_stub && a.ue_cel_stub.replayModule(n, m); f.addEventListener && f.addEventListener("mousedown", m, !0) }, off: function (a) { f.addEventListener && f.removeEventListener("mousedown", m, !0) }, ready: function () { return a.ue_cel && a.ue_cel.log }, reset: function () { } }
}(), a.ue_cel && a.ue_cel.registerModule("mouse click module", a.ue_mcm))
})(ue_csm);
(function (a) {
a.ue_mmm || !a.ue_cel || a.ue.isBF || (a.ue_mmm = function (m) {
function n(a, b) { var c = { x: a.pageX || a.x || 0, y: a.pageY || a.y || 0, t: l() }; !b && p && (c.t - p.t < B || c.x == p.x && c.y == p.y) || (p = c, u.push(c)) } function c() {
if (u.length) {
F = H.now(); for (var a = 0; a < u.length; a++) {
var c = u[a], d = a; y = u[h]; E = c; var e = void 0; if (!(e = 2 > d)) { e = void 0; a: if (u[d].t - u[d - 1].t > f) e = 0; else { for (e = h + 1; e < d; e++) { var g = y, k = E, l = u[e]; G = (k.x - g.x) * (g.y - l.y) - (g.x - l.x) * (k.y - g.y); if (G * G / ((k.x - g.x) * (k.x - g.x) + (k.y - g.y) * (k.y - g.y)) > z) { e = 0; break a } } e = 1 } e = !e } (r =
e) ? h = d - 1 : D.pop(); D.push(c)
} C = H.now() - F; s = Math.min(s, C); v = Math.max(v, C); A = (A * b + C) / (b + 1); b += 1; q({ k: x, e: D, min: Math.floor(1E3 * s), max: Math.floor(1E3 * v), avg: Math.floor(1E3 * A) }, { c: 1 }); u = []; D = []; h = 0
}
} var f = 100, B = 20, z = 25, x = "mmm1", l, k, d = a.window, e = d.document, w = d.setInterval, t = a.ue, q = a.ue_cel.log, g, s = 1E3, v = 0, A = 0, b = 0, F, C, u = [], D = [], h = 0, p, y, E, G, r, H = m && m.now && m || Date.now && Date || { now: function () { return (new Date).getTime() } }; return {
on: function (a) { l = a.ts; k = a.ns; t.attach && t.attach("mousemove", n, e); g = w(c, 3E3) }, off: function (a) {
k &&
(p && n(p, !0), c()); clearInterval(g); t.detach && t.detach("mousemove", n, e)
}, ready: function () { return a.ue_cel && a.ue_cel.log }, reset: function () { u = []; D = []; h = 0; p = null }
}
}(window.performance), a.ue_cel && a.ue_cel.registerModule("mouse move module", a.ue_mmm))
})(ue_csm);



ue_csm.ue.exec(function (b, c) {
var e = function () { }, f = function () { return { send: function (b, d) { if (d && b) { var a; if (c.XDomainRequest) a = new XDomainRequest, a.onerror = e, a.ontimeout = e, a.onprogress = e, a.onload = e, a.timeout = 0; else if (c.XMLHttpRequest) { if (a = new XMLHttpRequest, !("withCredentials" in a)) throw ""; } else a = void 0; if (!a) throw ""; a.open("POST", b, !0); a.setRequestHeader && a.setRequestHeader("Content-type", "text/plain"); a.send(d) } }, isSupported: !0 } }(), g = function () {
return {
send: function (c, d) {
if (c && d) if (navigator.sendBeacon(c,
d)) b.ue_sbuimp && b.ue && b.ue.ssw && b.ue.ssw("eelsts", "scs"); else throw "";
}, isSupported: !!navigator.sendBeacon && !(c.cordova && c.cordova.platformId && "ios" == c.cordova.platformId)
}
}(); b.ue._ajx = f; b.ue._sBcn = g
}, "Transportation-clients")(ue_csm, window);
ue_csm.ue.exec(function (b, k) {
function B() { for (var a = 0; a < arguments.length; a++) { var c = arguments[a]; try { var g; if (c.isSupported) { var f = u.buildPayload(l, e); g = c.send(K, f) } else throw dummyException; return g } catch (d) { } } a = { m: "All supported clients failed", attribution: "CSMSushiClient_TRANSPORTATION_FAIL", f: "sushi-client.js", logLevel: "ERROR" }; C(a, k.ue_err_chan || "jserr"); b.ue_err.buffer && b.ue_err.buffer.push(a) } function m() {
if (e.length) {
for (var a = 0; a < n.length; a++)n[a](); B(d._sBcn || {}, d._ajx || {}); e = []; h = {}; l =
{}; v = w = r = x = 0
}
} function L() { var a = new Date, c = function (a) { return 10 > a ? "0" + a : a }; return Date.prototype.toISOString ? a.toISOString() : a.getUTCFullYear() + "-" + c(a.getUTCMonth() + 1) + "-" + c(a.getUTCDate()) + "T" + c(a.getUTCHours()) + ":" + c(a.getUTCMinutes()) + ":" + c(a.getUTCSeconds()) + "." + String((a.getUTCMilliseconds() / 1E3).toFixed(3)).slice(2, 5) + "Z" } function y(a) { try { return JSON.stringify(a) } catch (c) { } return null } function D(a, c, g, f) {
var q = !1; f = f || {}; s++; if (s == E) {
var p = {
m: "Max number of Sushi Logs exceeded", f: "sushi-client.js",
logLevel: "ERROR", attribution: "CSMSushiClient_MAX_CALLS"
}; C(p, k.ue_err_chan || "jserr"); b.ue_err.buffer && b.ue_err.buffer.push(p)
} if (p = !(s >= E)) (p = a && -1 < a.constructor.toString().indexOf("Object") && c && -1 < c.constructor.toString().indexOf("String") && g && -1 < g.constructor.toString().indexOf("String")) || M++; p && (d.count && d.count("Event:" + g, 1), a.producerId = a.producerId || c, a.schemaId = a.schemaId || g, a.timestamp = L(), c = Date.now ? Date.now() : +new Date, g = Math.random().toString().substring(2, 12), a.messageId = b.ue_id + "-" +
c + "-" + g, f && !f.ssd && (a.sessionId = a.sessionId || b.ue_sid, a.requestId = a.requestId || b.ue_id, a.obfuscatedMarketplaceId = a.obfuscatedMarketplaceId || b.ue_mid), (c = y(a)) ? (c = c.length, (e.length == N || r + c > O) && m(), r += c, a = { data: u.compressEvent(a) }, e.push(a), (f || {}).n ? 0 === F ? m() : v || (v = k.setTimeout(m, F)) : w || (w = k.setTimeout(m, P)), q = !0) : q = !1); !q && b.ue_int && console.error("Invalid JS Nexus API call"); return q
} function G() {
if (!H) {
for (var a = 0; a < z.length; a++)z[a](); for (a = 0; a < n.length; a++)n[a](); e.length && (b.ue_sbuimp && b.ue &&
b.ue.ssw && (a = y({ dct: l, evt: e }), b.ue.ssw("eeldata", a), b.ue.ssw("eelsts", "unk")), B(d._sBcn || {})); H = !0
}
} function I(a) { z.push(a) } function J(a) { n.push(a) } var E = 1E3, N = 499, O = 524288, t = function () { }, d = b.ue || {}, C = d.log || t, Q = b.uex || t; (b.uet || t)("bb", "ue_sushi_v1", { wb: 1 }); var K = b.ue_surl || "https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.gamma", R = ["messageId", "timestamp"], A = "#", e = [], h = {}, l = {}, r = 0, x = 0, M = 0, s = 0, z = [], n = [], H = !1, v, w, F = void 0 === b.ue_hpsi ? 1E3 : b.ue_hpsi, P = void 0 === b.ue_lpsi ? 1E4 : b.ue_lpsi,
u = function () { function a(a) { h[a] = A + x++; l[h[a]] = a; return h[a] } function c(b) { if (!(b instanceof Function)) { if (b instanceof Array) { for (var f = [], d = b.length, e = 0; e < d; e++)f[e] = c(b[e]); return f } if (b instanceof Object) { f = {}; for (d in b) b.hasOwnProperty(d) && (f[h[d] ? h[d] : a(d)] = -1 === R.indexOf(d) ? c(b[d]) : b[d]); return f } return "string" === typeof b && (b.length > (A + x).length || b.charAt(0) === A) ? h[b] ? h[b] : a(b) : b } } return { compressEvent: c, buildPayload: function () { return y({ cs: { dct: l }, events: e }) } } }(); (function () {
if (d.event && d.event.isStub) {
if (b.ue_sbuimp &&
b.ue && b.ue.ssw) { var a = b.ue.ssw("eelsts").val; if (a && "unk" === a && (a = b.ue.ssw("eeldata").val)) { var c; a: { try { c = JSON.parse(a); break a } catch (g) { } c = null } c && c.evt instanceof Array && c.dct instanceof Object && (e = c.evt, l = c.dct, e && l && (m(), b.ue.ssw("eeldata", "{}"), b.ue.ssw("eelsts", "scs"))) } } d.event.replay(function (a) { a[3] = a[3] || {}; a[3].n = 1; D.apply(this, a) }); d.onSushiUnload.replay(function (a) { I(a[0]) }); d.onSushiFlush.replay(function (a) { J(a[0]) })
}
})(); d.attach("beforeunload", G); d.attach("pagehide", G); d._cmps = u; d.event =
D; d.event.reset = function () { s = 0 }; d.onSushiUnload = I; d.onSushiFlush = J; try { k.P && k.P.register && k.P.register("sushi-client", t) } catch (S) { b.ueLogError(S, { logLevel: "WARN" }) } Q("ld", "ue_sushi_v1", { wb: 1 })
}, "Nxs-JS-Client")(ue_csm, window);


ue_csm.ue_unrt = 1500;
(function (d, b, t) {
function u(a, g) { var c = a.srcElement || a.target || {}, b = { k: v, t: g.t, dt: g.dt, x: a.pageX, y: a.pageY, p: e.getXPath(c), n: c.nodeName }; a.button && (b.b = a.button); c.type && (b.ty = c.type); c.href && (b.r = e.extractStringValue(c.href)); c.id && (b.i = c.id); c.className && c.className.split && (b.c = c.className.split(/\s+/)); h += 1; e.getFirstAscendingWidget(c, function (a) { b.wd = a; d.ue.log(b, r) }) } function w(a) {
if (!x(a.srcElement || a.target)) {
m += 1; n = !0; var g = f = d.ue.d(), c; p && "function" === typeof p.now && a.timeStamp && (c = p.now() -
a.timeStamp, c = parseFloat(c.toFixed(2))); s = b.setTimeout(function () { u(a, { t: g, dt: c }) }, y)
}
} function z(a) { if (a) { var b = a.filter(A); a.length !== b.length && (q = !0, k = d.ue.d(), n && q && (k && f && d.ue.log({ k: B, t: f, m: Math.abs(k - f) }, r), l(), q = !1, k = 0)) } } function A(a) {
if (!a) return !1; var b = "characterData" === a.type ? a.target.parentElement : a.target; if (!b || !b.hasAttributes || !b.attributes) return !1; var c = {
"class": "gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "), id: ["dealClock",
"deal_expiry_timer", "timer"], role: ["timer"]
}, d = !1; Object.keys(c).forEach(function (a) { var e = b.attributes[a] ? b.attributes[a].value : ""; (c[a] || "").forEach(function (a) { -1 !== e.indexOf(a) && (d = !0) }) }); return d
} function x(a) {
if (!a) return !1; var b = (e.extractStringValue(a.nodeName) || "").toLowerCase(), c = (e.extractStringValue(a.type) || "").toLowerCase(), d = (e.extractStringValue(a.href) || "").toLowerCase(); a = (e.extractStringValue(a.id) || "").toLowerCase(); var f = "checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
if (-1 !== ["select", "textarea", "html"].indexOf(b) || "input" === b && -1 !== f.indexOf(c) || "a" === b && -1 !== d.indexOf("http") || -1 !== ["sitbreaderrightpageturner", "sitbreaderleftpageturner", "sitbreaderpagecontainer"].indexOf(a)) return !0
} function l() { n = !1; f = 0; b.clearTimeout(s) } function C() { b.ue.onunload(function () { ue.count("armored-cxguardrails.unresponsive-clicks.violations", h); ue.count("armored-cxguardrails.unresponsive-clicks.violationRate", h / m * 100 || 0) }) } if (b.MutationObserver && b.addEventListener && Object.keys &&
d && d.ue && d.ue.log && d.ue_unrt && d.ue_utils) { var y = d.ue_unrt, r = "cel", v = "unr_mcm", B = "res_mcm", p = b.performance, e = d.ue_utils, n = !1, f = 0, s = 0, q = !1, k = 0, h = 0, m = 0; b.addEventListener && (b.addEventListener("mousedown", w, !0), b.addEventListener("beforeunload", l, !0), b.addEventListener("visibilitychange", l, !0), b.addEventListener("pagehide", l, !0)); b.ue && b.ue.event && b.ue.onSushiUnload && b.ue.onunload && C(); (new MutationObserver(z)).observe(t, { childList: !0, attributes: !0, characterData: !0, subtree: !0 }) }
})(ue_csm, window, document);


ue_csm.ue.exec(function (g, e) {
if (e.ue_err) {
var f = ""; e.ue_err.errorHandlers || (e.ue_err.errorHandlers = []); e.ue_err.errorHandlers.push({
name: "fctx", handler: function (a) {
if (!a.logLevel || "FATAL" === a.logLevel) if (f = g.getElementsByTagName("html")[0].innerHTML) {
var b = f.indexOf("var ue_t0=ue_t0||+new Date();"); if (-1 !== b) {
var b = f.substr(0, b).split(String.fromCharCode(10)), d = Math.max(b.length - 10 - 1, 0), b = b.slice(d, b.length - 1); a.fcsmln = d + b.length + 1; a.cinfo = a.cinfo || {}; for (var c = 0; c < b.length; c++)a.cinfo[d + c + 1 + ""] =
b[c]
} b = f.split(String.fromCharCode(10)); a.cinfo = a.cinfo || {}; if (!(a.f || void 0 === a.l || a.l in a.cinfo)) for (c = +a.l - 1, d = Math.max(c - 5, 0), c = Math.min(c + 5, b.length - 1); d <= c; d++)a.cinfo[d + 1 + ""] = b[d]
}
}
})
}
}, "fatals-context")(document, window);


(function (m, b) {
function c(k) {
function f(a) { a && "string" === typeof a && (a = (a = a.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i)) && 1 < a.length ? a[1] : null, a && a && ("number" === typeof e[a] ? e[a]++ : e[a] = 1)) } function d(a) { var e = 10, d = +new Date; a && a.timeRemaining ? e = a.timeRemaining() : a = { timeRemaining: function () { return Math.max(0, e - (+new Date - d)) } }; for (var c = b.performance.getEntries(), k = e; g < c.length && k > n;)c[g].name && f(c[g].name), g++, k = a.timeRemaining(); g >= c.length ? h(!0) : l() } function h(a) {
if (!a) {
a = m.scripts; var c; if (a) for (var d =
0; d < a.length; d++)(c = a[d].getAttribute("src")) && "undefined" !== c && f(c)
} 0 < Object.keys(e).length && (p && ue_csm.ue && ue_csm.ue.event && (a = { domains: e, pageType: b.ue_pty || null, subPageType: b.ue_spty || null, pageTypeId: b.ue_pti || null }, ue_csm.ue_sjslob && (a.lob = ue_csm.ue_lob || "0"), ue_csm.ue.event(a, "csm", "csm.CrossOriginDomains.2")), b.ue_ext = e)
} function l() { !0 === k ? d() : b.requestIdleCallback ? b.requestIdleCallback(d) : b.requestAnimationFrame ? b.requestAnimationFrame(d) : b.setTimeout(d, 100) } function c() {
if (b.performance &&
b.performance.getEntries) { var a = b.performance.getEntries(); !a || 0 >= a.length ? h(!1) : l() } else h(!1)
} var e = b.ue_ext || {}; b.ue_ext || c(); return e
} function q() { setTimeout(c, r) } var s = b.ue_dserr || !1, p = !0, n = 1, r = 2E3, g = 0; b.ue_err && s && (b.ue_err.errorHandlers || (b.ue_err.errorHandlers = []), b.ue_err.errorHandlers.push({
name: "ext", handler: function (b) {
if (!b.logLevel || "FATAL" === b.logLevel) {
var f = c(!0), d = [], h; for (h in f) {
var f = h, g = f.match(/amazon(\.com?)?\.\w{2,3}$/i); g && 1 < g.length || -1 !== f.indexOf("amazon-adsystem.com") ||
-1 !== f.indexOf("amazonpay.com") || -1 !== f.indexOf("cloudfront-labs.amazonaws.com") || d.push(h)
} b.ext = d
}
}
})); b.ue && b.ue.isl ? c() : b.ue && ue.attach && ue.attach("load", q)
})(document, window);





var ue_wtc_c = 3;
ue_csm.ue.exec(function (b, e) {
function l() { for (var a = 0; a < f.length; a++)a: for (var d = s.replace(A, f[a]) + g[f[a]] + t, c = arguments, b = 0; b < c.length; b++)try { c[b].send(d); break a } catch (e) { } g = {}; f = []; n = 0; k = p } function u() { B ? l(q) : l(C, q) } function v(a, m, c) {
r++; if (r > w) d.count && 1 == r - w && (d.count("WeblabTriggerThresholdReached", 1), b.ue_int && console.error("Number of max call reached. Data will no longer be send")); else {
var h = c || {}; h && -1 < h.constructor.toString().indexOf(D) && a && -1 < a.constructor.toString().indexOf(x) && m && -1 <
m.constructor.toString().indexOf(x) ? (h = b.ue_id, c && c.rid && (h = c.rid), c = h, a = encodeURIComponent(",wl=" + a + "/" + m), 2E3 > a.length + p ? (2E3 < k + a.length && u(), void 0 === g[c] && (g[c] = "", f.push(c)), g[c] += a, k += a.length, n || (n = e.setTimeout(u, E))) : b.ue_int && console.error("Invalid API call. The input provided is over 2000 chars.")) : d.count && (d.count("WeblabTriggerImproperAPICall", 1), b.ue_int && console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))
}
} function F() {
d.trigger &&d.trigger.isStub && d.trigger.replay(function (a) { v.apply(this, a) })
} function y() { z || (f.length && l(q), z = !0) } var t = ":1234", s = "//" + b.ue_furl + "/1/remote-weblab-triggers/1/OE/" + b.ue_mid + ":" + b.ue_sid + ":PLCHLDR_RID$s:wl-client-id%3DCSMTriger", A = "PLCHLDR_RID", E = b.wtt || 1E4, p = s.length + t.length, w = b.mwtc || 2E3, G = 1 === e.ue_wtc_c, B = 3 === e.ue_wtc_c, H = e.XMLHttpRequest && "withCredentials" in new e.XMLHttpRequest, x = "String", D = "Object", d = b.ue, g = {}, f = [], k = p, n, z = !1, r = 0, C = function () {
return {
send: function (a) {
if (H) {
var b = new e.XMLHttpRequest;
b.open("GET", a, !0); G && (b.withCredentials = !0); b.send()
} else throw "";
}
}
}(), q = function () { return { send: function (a) { (new Image).src = a } } }(); e.encodeURIComponent && (d.attach && (d.attach("beforeunload", y), d.attach("pagehide", y)), F(), d.trigger = v)
}, "client-wbl-trg")(ue_csm, window);


(function (k, d, h) {
function f(a, c, b) { a && a.indexOf && 0 === a.indexOf("http") && 0 !== a.indexOf("https") && l(s, c, a, b) } function g(a, c, b) { a && a.indexOf && (location.href.split("#")[0] != a && null !== a && "undefined" !== typeof a || l(t, c, a, b)) } function l(a, c, b, e) { m[b] || (e = u && e ? n(e) : "N/A", d.ueLogError && d.ueLogError({ message: a + c + " : " + b, logLevel: v, stack: "N/A" }, { attribution: e }), m[b] = 1, p++) } function e(a, c) { if (a && c) for (var b = 0; b < a.length; b++)try { c(a[b]) } catch (d) { } } function q() {
return d.performance && d.performance.getEntriesByType ?
d.performance.getEntriesByType("resource") : []
} function n(a) { if (a.id) return "//*[@id='" + a.id + "']"; var c; c = 1; var b; for (b = a.previousSibling; b; b = b.previousSibling)b.nodeName == a.nodeName && (c += 1); b = a.nodeName; 1 != c && (b += "[" + c + "]"); a.parentNode && (b = n(a.parentNode) + "/" + b); return b } function w() { var a = h.images; a && a.length && e(a, function (a) { var b = a.getAttribute("src"); f(b, "img", a); g(b, "img", a) }) } function x() { var a = h.scripts; a && a.length && e(a, function (a) { var b = a.getAttribute("src"); f(b, "script", a); g(b, "script", a) }) }
function y() { var a = h.styleSheets; a && a.length && e(a, function (a) { if (a = a.ownerNode) { var b = a.getAttribute("href"); f(b, "style", a); g(b, "style", a) } }) } function z() { if (A) { var a = q(); e(a, function (a) { f(a.name, a.initiatorType) }) } } function B() { e(q(), function (a) { g(a.name, a.initiatorType) }) } function r() { var a; a = d.location && d.location.protocol ? d.location.protocol : void 0; "https:" == a && (z(), w(), x(), y(), B(), p < C && setTimeout(r, D)) } var s = "[CSM] Insecure content detected ", t = "[CSM] Ajax request to same page detected ", v = "WARN",
m = {}, p = 0, D = k.ue_nsip || 1E3, C = 5, A = 1 == k.ue_urt, u = !0; ue_csm.ue_disableNonSecure || (d.performance && d.performance.setResourceTimingBufferSize && d.performance.setResourceTimingBufferSize(300), r())
})(ue_csm, window, document);


var ue_aa_a = "";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function (f, b) {
function g() { try { b.PerformanceObserver && "function" === typeof b.PerformanceObserver && (a = new b.PerformanceObserver(function (b) { c(b.getEntries()) }), a.observe(d)) } catch (h) { k() } } function m() { for (var h = d.entryTypes, a = 0; a < h.length; a++)c(b.performance.getEntriesByType(h[a])) } function c(a) {
if (a && Array.isArray(a)) {
for (var c = 0, e = 0; e < a.length; e++) { var d = l.indexOf(a[e].name); if (-1 !== d) { var g = Math.round(b.performance.timing.navigationStart + a[e].startTime); f.uet(n[d], void 0, void 0, g); c++ } } l.length ===
c && k()
}
} function k() { a && a.disconnect && "function" === typeof a.disconnect && a.disconnect() } if ("function" === typeof f.uet && b.performance && "object" === typeof b.performance && b.performance.getEntriesByType && "function" === typeof b.performance.getEntriesByType && b.performance.timing && "object" === typeof b.performance.timing && "number" === typeof b.performance.timing.navigationStart) {
var d = { entryTypes: ["paint"] }, l = ["first-paint", "first-contentful-paint"], n = ["fp", "fcp"], a; try { m(), g() } catch (p) {
f.ueLogError(p, {
logLevel: "ERROR",
attribution: "performanceMetrics"
})
}
}
})(ue_csm, window);


if (window.csa) {
csa("Events")("setEntity", {
page: { pageType: "Detail", subPageType: "Kindle_HW", pageTypeId: "B0BF75VM4T" }
});
}
csa.plugin(function (c) { var m = "transitionStart", n = "pageVisible", e = "PageTiming", t = "visibilitychange", s = "$latency.visible", i = c.global, r = (i.performance || {}).timing, a = ["navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd"], u = c.config, o = i.Math, l = o.max, g = o.floor, d = i.document || {}, f = (r || {}).navigationStart, v = f, p = 0, S = null; if (i.Object.keys && [].forEach && !u["KillSwitch." + e]) { if (!r || null === f || f <= 0 || void 0 === f) return c.error("Invalid navigation timing data: " + f); S = new E({ schemaId: "<ns>.PageLatency.6", producerId: "csa" }), "boolean" != typeof d.hidden && "string" != typeof d.visibilityState || !d.removeEventListener ? c.emit(s) : b() ? (c.emit(s), I(n, f)) : c.on(d, t, function e() { b() && (v = c.time(), d.removeEventListener(t, e), I(m, v), I(n, v), c.emit(s)) }), c.once("$unload", h), c.once("$load", h), c.on("$pageTransition", function () { v = c.time() }), c.register(e, { mark: I, instance: function (e) { return new E(e) } }) } function E(e) { var i, r = null, a = e.ent || { page: ["pageType", "subPageType", "requestId"] }, o = e.logger || c("Events", { producerId: e.producerId, lob: u.lob || "0" }); if (!e || !e.producerId || !e.schemaId) return c.error("The producer id and schema Id must be defined for PageLatencyInstance."); function d() { return i || v } function n() { r = c.UUID() } this.mark = function (n, t) { if (null != n) return t = t || c.time(), n === m && (i = t), c.once(s, function () { o("log", { messageId: r, __merge: function (e) { e.markers[n] = function (e, n) { return l(0, n - (e || v)) }(d(), t), e.markerTimestamps[n] = g(t) }, markers: {}, markerTimestamps: {}, navigationStartTimestamp: d() ? new Date(d()).toISOString() : null, schemaId: e.schemaId }, { ent: a }) }), t }, n(), c.on("$beforePageTransition", n) } function I(e, n) { e === m && (v = n); var t = S.mark(e, n); c.emit("$timing:" + e, t) } function h() { if (!p) { for (var e = 0; e < a.length; e++)r[a[e]] && I(a[e], r[a[e]]); p = 1 } } function b() { return !d.hidden || "visible" === d.visibilityState } }); csa.plugin(function (u) { var f, c, l = "length", a = "parentElement", t = "target", i = "getEntriesByName", e = "perf", n = null, r = "_csa_flt", o = "_csa_llt", s = "previousSibling", d = "visuallyLoaded", g = "client", h = "offset", m = "scroll", p = "Width", v = "Height", y = g + p, E = g + v, S = h + p, b = h + v, x = m + p, O = m + v, _ = "_osrc", w = "_elt", L = "_eid", T = 10, I = 5, N = 15, k = 100, B = u.global, H = u.timeout, W = B.Math, Y = W.max, C = W.floor, F = W.ceil, M = B.document || {}, R = M.body || {}, V = M.documentElement || {}, $ = B.performance || {}, P = ($.timing || {}).navigationStart, X = Date.now, D = Object.values || (u.types || {}).ovl, J = u("PageTiming"), j = u("SpeedIndexBuffers"), q = [], Q = [], U = [], z = [], A = [], G = [], K = .1, Z = .1, ee = 0, ne = 0, te = !0, ie = 0, re = 0, oe = 1 == u.config["SpeedIndex.ForceReplay"], ae = 0, fe = 1, ue = 0, ce = {}, le = [], se = 0, de = { buffered: 1 }; function ge(e) { u.global.ue_csa_ss_tag || u.emit("$csmTag:" + e, 0, de) } function he() { for (var e = X(), n = 0; f;) { if (0 !== f[l]) { if (!1 !== f.h(f[0]) && f.shift(), n++, !oe && n % T == 0 && X() - e > I) break } else f = f.n } ee = 0, f && (ee || (!0 === M.hidden ? (oe = 1, he()) : u.timeout(he, 0))) } function me(e, n, t, i, r) { ue = C(e), q = n, Q = t, U = i, G = r; var o = M.createTreeWalker(M.body, NodeFilter.SHOW_TEXT, null, null), a = { w: B.innerWidth, h: B.innerHeight, x: B.pageXOffset, y: B.pageYOffset }; M.body[w] = e, z.push({ w: o, vp: a }), A.push({ img: M.images, iter: 0 }), q.h = pe, (q.n = Q).h = ve, (Q.n = U).h = ye, (U.n = z).h = Ee, (z.n = A).h = Se, (A.n = G).h = be, f = q, he() } function pe(e) { e.m.forEach(function (e) { for (var n = e; n && (e === n || !n[r] || !n[o]);)n[r] || (n[r] = e[r]), n[o] || (n[o] = e[o]), n[w] = n[r] - P, n = n[s] }) } function ve(e) { e.m.forEach(function (e) { var n = e[t]; _ in n || (n[_] = e.oldValue) }) } function ye(n) { n.m.forEach(function (e) { e[t][w] = n.t - P }) } function Ee(e) { for (var n, t = e.vp, i = e.w, r = T; (n = i.nextNode()) && 0 < r;) { r -= 1; var o = (n[a] || {}).nodeName; "SCRIPT" !== o && "STYLE" !== o && "NOSCRIPT" !== o && "BODY" !== o && 0 !== (n.nodeValue || "").trim()[l] && Le(n[a], xe(n), t) } return !n } function Se(e) { for (var n = { w: B.innerWidth, h: B.innerHeight, x: B.pageXOffset, y: B.pageYOffset }, t = T; e.iter < e.img[l] && 0 < t;) { var i, r = e.img[e.iter], o = we(r), a = o && xe(o) || xe(r); o ? (o[w] = a, i = _e(o.querySelector('[aria-posinset="1"] img') || r) || a, r = o) : i = _e(r) || a, re && c < i && (i = a), Le(r, i, n), e.iter += 1, t -= 1 } return e.img[l] <= e.iter } function be(e) { var n = [], i = 0, r = 0, o = ne, t = B.innerHeight || Y(R[O] || 0, R[b] || 0, V[E] || 0, V[O] || 0, V[b] || 0), a = C(e.y / k), f = F((e.y + t) / k); le.slice(a, f).forEach(function (e) { (e.elems || []).forEach(function (e) { e.lt in n || (n[e.lt] = {}), e.id in n[e.lt] || (i += (n[e.lt][e.id] = e).a) }) }), ge("startVL"), D(n).forEach(function (e) { D(e).forEach(function (e) { var n = 1 - r / i, t = Y(e.lt, o); se += n * (t - o), o = t, function (e, n) { var t; for (; K <= 1 && K - .01 <= e;)Te(d + (t = (100 * K).toFixed(0)), n.lt), "50" !== t && "90" !== t || u("Content", { target: n.e })("mark", d + t, P + F(n.lt || 0)), K += Z }((r += e.a) / i, e) }) }), ge("endVL"), ne = e.t - P, G[l] <= 1 && (Te("speedIndex", se), Te(d + "0", ue)), te && (te = !1, Te("atfSpeedIndex", se)) } function xe(e) { for (var n = e[a], t = N; n && 0 < t;) { if (n[w] || 0 === n[w]) return Y(n[w], ue); n = n.parentElement, t -= 1 } } function Oe(e, n) { if (e) { if (!e.indexOf("data:")) return xe(n); var t = $[i](e) || []; if (0 < t[l]) return Y(F(t[0].responseEnd || 0), ue) } } function _e(e) { return Oe(e[_], e) || Oe(e.currentSrc, e) || Oe(e.src, e) } function we(e) { for (var n = 10, t = e.parentElement; t && 0 < n;) { if (t.classList && t.classList.contains("a-carousel-viewport")) return t; t = t.parentElement, n -= 1 } return null } function Le(e, n, t) { if ((n || 0 === n) && !e[L]) { var i = e.getBoundingClientRect(), r = i.width * i.height, o = t.w || Y(R[x] || 0, R[S] || 0, V[y] || 0, V[x] || 0, V[S] || 0) || i.right, a = i.width / 2, f = fe++; if (0 != r && !(a < i.right - o || i.right < a)) { for (var u = { e: e, lt: n, a: r, id: f }, c = C((i.top + t.y) / k), l = F((i.top + t.y + i.height) / k), s = c; s <= l; s++)s in le || (le[s] = { elems: [], lt: 0 }), le[s].elems.push(u); e[L] = f } } } function Te(e, n) { J("mark", e, P + F((ce[e] = n) || 0)) } function Ie(e) { ae || (ge("browserQuite" + e), j("getBuffers", me), ae = 1) } P && D && $[i] ? (ge(e + "Yes"), j("registerListener", function () { re && (clearTimeout(ie), ie = H(Ie.bind(n, "Mut"), 2500)) }), u.once("$unload", function () { oe = 1, Ie("Ud") }), u.once("$load", function () { re = 1, c = X() - P, ie = H(Ie.bind(n, "Ld"), 2500) }), u.once("$timing:functional", Ie.bind(n, "Fn")), j("replayModuleIsLive"), u.register("SpeedIndex", { getMarkers: function (e) { e && e(JSON.parse(JSON.stringify(ce))) } })) : ge(e + "No") }); csa.plugin(function (e) { var m = !!e.config["LCP.elementDedup"], t = !1, n = e("PageTiming"), r = e.global.PerformanceObserver, a = e.global.performance; function i() { return a.timing.navigationStart } function o() { t || function (o) { var l = new r(function (e) { var t = e.getEntries(); if (0 !== t.length) { var n = t[t.length - 1]; if (m && "" !== n.id && n.element && "IMG" === n.element.tagName) { for (var r = {}, a = t[0], i = 0; i < t.length; i++)t[i].id in r || ("" !== t[i].id && (r[t[i].id] = !0), a.startTime < t[i].startTime && (a = t[i])); n = a } l.disconnect(), o({ startTime: n.startTime, renderTime: n.renderTime, loadTime: n.loadTime }) } }); try { l.observe({ type: "largest-contentful-paint", buffered: !0 }) } catch (e) { } }(function (e) { e && (t = !0, n("mark", "largestContentfulPaint", Math.floor(e.startTime + i())), e.renderTime && n("mark", "largestContentfulPaint.render", Math.floor(e.renderTime + i())), e.loadTime && n("mark", "largestContentfulPaint.load", Math.floor(e.loadTime + i()))) }) } r && a && a.timing && (e.once("$unload", o), e.once("$load", o), e.register("LargestContentfulPaint", {})) }); csa.plugin(function (r) { var e = r("Metrics", { producerId: "csa" }), n = r.global.PerformanceObserver; n && (n = new n(function (r) { var t = r.getEntries(); if (0 === t.length || !t[0].processingStart || !t[0].startTime) return; !function (r) { r = r || 0, n.disconnect(), 0 <= r ? e("recordMetric", "firstInputDelay", r) : e("recordMetric", "firstInputDelay.invalid", 1) }(t[0].processingStart - t[0].startTime) }), function () { try { n.observe({ type: "first-input", buffered: !0 }) } catch (r) { } }()) }); csa.plugin(function (d) { var e = "Metrics", g = d.config, f = 0; function r(i) { var c, t, e = i.producerId, r = i.logger, o = r || d("Events", { producerId: e, lob: g.lob || "0" }), s = (i || {}).dimensions || {}, u = {}, n = -1; if (!e && !r) return d.error("Either a producer id or custom logger must be defined"); function a() { n !== f && (c = d.UUID(), t = d.UUID(), u = {}, n = f) } this.recordMetric = function (r, n) { var e = i.logOptions || { ent: { page: ["pageType", "subPageType", "requestId"] } }; e.debugMetric = i.debugMetric, a(), o("log", { messageId: c, schemaId: i.schemaId || "<ns>.Metric.4", metrics: {}, dimensions: s, __merge: function (e) { e.metrics[r] = n } }, e) }, this.recordCounter = function (r, e) { var n = i.logOptions || { ent: { page: ["pageType", "subPageType", "requestId"] } }; if ("string" != typeof r || "number" != typeof e || !isFinite(e)) return d.error("Invalid type given for counter name or counter value: " + r + "/" + e); a(), r in u || (u[r] = {}); var c = u[r]; "f" in c || (c.f = e), c.c = (c.c || 0) + 1, c.s = (c.s || 0) + e, c.l = e, o("log", { messageId: t, schemaId: i.schemaId || "<ns>.InternalCounters.3", c: {}, __merge: function (e) { r in e.c || (e.c[r] = {}), c.fs || (c.fs = 1, e.c[r].f = c.f), 1 < c.c && (e.c[r].s = c.s, e.c[r].l = c.l, e.c[r].c = c.c) } }, n) } } g["KillSwitch." + e] || (new r({ producerId: "csa" }).recordMetric("baselineMetricEvent", 1), d.on("$beforePageTransition", function () { f++ }), d.register(e, { instance: function (e) { return new r(e || {}) } })) }); csa.plugin(function (s) { var n = s.config, r = (s.global.performance || {}).timing, c = (r || {}).navigationStart || s.time(), g = 0; function e() { g += 1 } function i(i) { i = i || {}; var o = s.UUID(), t = g, r = i.producerId, e = i.logger, a = e || s("Events", { producerId: r, lob: n.lob || "0" }); if (!r && !e) return s.error("Either a producer id or custom logger must be defined"); this.mark = function (e, r) { var n = (void 0 === r ? s.time() : r) - c; t !== g && (t = g, o = s.UUID()), a("log", { messageId: o, schemaId: i.schemaId || "<ns>.Timer.1", markers: {}, __merge: function (r) { r.markers[e] = n } }, i.logOptions) } } r && (e(), s.on("$beforePageTransition", e), s.register("Timers", { instance: function (r) { return new i(r || {}) } })) }); csa.plugin(function (t) { var e = "takeRecords", i = "disconnect", n = "function", o = t("Metrics", { producerId: "csa" }), c = t("PageTiming"), a = t.global, u = t.timeout, r = t.on, f = a.PerformanceObserver, m = 0, l = !1, s = 0, d = a.performance, h = a.document, v = null, y = !1, g = t.blank; function p() { l || (l = !0, clearTimeout(v), typeof f[e] === n && f[e](), typeof f[i] === n && f[i](), o("recordMetric", "documentCumulativeLayoutShift", m), c("mark", "cumulativeLayoutShiftLastTimestamp", Math.floor(s + d.timing.navigationStart))) } f && d && d.timing && h && (f = new f(function (t) { v && clearTimeout(v); t.getEntries().forEach(function (t) { t.hadRecentInput || (m += t.value, s < t.startTime && (s = t.startTime)) }), v = u(p, 5e3) }), function () { try { f.observe({ type: "layout-shift", buffered: !0 }), v = u(p, 5e3) } catch (t) { } }(), g = r(h, "click", function (t) { y || (y = !0, o("recordMetric", "documentCumulativeLayoutShiftToFirstInput", m), g()) }), r(h, "visibilitychange", function () { "hidden" === h.visibilityState && p() }), t.once("$unload", p)) }); csa.plugin(function (e) { var t, n = e.global, r = n.PerformanceObserver, c = e("Metrics", { producerId: "csa" }), o = 0, i = 0, a = -1, l = n.Math, f = l.max, u = l.ceil; if (r) { t = new r(function (e) { e.getEntries().forEach(function (e) { var t = e.duration; o += t, i += t, a = f(t, a) }) }); try { t.observe({ type: "longtask", buffered: !0 }) } catch (e) { } t = new r(function (e) { 0 < e.getEntries().length && (i = 0, a = -1) }); try { t.observe({ type: "largest-contentful-paint", buffered: !0 }) } catch (e) { } e.on("$unload", g), e.on("$beforePageTransition", g) } function g() { c("recordMetric", "totalBlockingTime", u(i || 0)), c("recordMetric", "totalBlockingTimeInclLCP", u(o || 0)), c("recordMetric", "maxBlockingTime", u(a || 0)), i = o = 0, a = -1 } }); csa.plugin(function (o) { var e = "CacheDetection", r = "csa-ctoken-", c = o.store, t = o.deleteStored, n = o.config, i = n[e + ".RequestID"], a = n[e + ".Callback"], s = o.global, u = s.document || {}, d = s.Date, l = o("Events"), f = o("Events", { producerId: "csa", lob: n.lob || "0" }); function p(e) { try { var c = u.cookie.match(RegExp("(^| )" + e + "=([^;]+)")); return c && c[2].trim() } catch (e) { } } n["KillSwitch." + e] || (function () { var e = function () { var e = p("cdn-rid"); if (e) return { r: e, s: "cdn" } }() || function () { if (o.store(r + i)) return { r: o.UUID().toUpperCase().replace(/-/g, "").slice(0, 20), s: "device" } }() || {}, c = e.r, n = e.s; if (!!c) { var t = p("session-id"); !function (e, c, n, t) { l("setEntity", { page: { pageSource: "cache", requestId: e, cacheRequestId: i, cacheSource: t }, session: { id: n } }) }(c, 0, t, n), "device" === n && f("log", { schemaId: "<ns>.CacheImpression.2" }, { ent: "all" }), a && a(c, t, n) } }(), c(r + i, d.now() + 36e5), o.once("$load", function () { var n = d.now(); t(function (e, c) { return 0 == e.indexOf(r) && parseInt(c) < n }) })) }); csa.plugin(function (u) { var i, t = "Content", e = "MutationObserver", n = "addedNodes", a = "querySelectorAll", f = "matches", r = "getAttributeNames", o = "getAttribute", s = "dataset", c = "widget", l = "producerId", d = "slotId", h = "iSlotId", g = { ent: { element: 1, page: ["pageType", "subPageType", "requestId"] } }, p = 5, m = u.config[t + ".BubbleUp.SearchDepth"] || 35, y = u.config[t + ".SearchPage"] || 0, v = "csaC", b = v + "Id", E = "logRender", w = {}, I = u.config, O = I[t + ".Selectors"] || [], C = I[t + ".WhitelistedAttributes"] || { href: 1, class: 1 }, N = I[t + ".EnableContentEntities"], S = I["KillSwitch.ContentRendered"], k = u.global, A = k.document || {}, U = A.documentElement, L = k.HTMLElement, R = {}, _ = [], j = function (t, e, n, i) { var o = this, r = u("Events", { producerId: t || "csa", lob: I.lob || "0" }); e.type = e.type || c, o.id = e.id, o.l = r, o.e = e, o.el = n, o.rt = i, o.dlo = g, o.op = W(n, "csaOp"), o.log = function (t, e) { r("log", t, e || g) }, o.entities = function (t) { t(e) }, e.id && r("setEntity", { element: e }) }, x = j.prototype; function D(t) { var e = (t = t || {}).element, n = t.target; return e ? function (t, e) { var n; n = t instanceof L ? K(t) || Y(e[l], t, z, u.time()) : R[t.id] || H(e[l], 0, t, u.time()); return n }(e, t) : n ? M(n) : u.error("No element or target argument provided.") } function M(t) { var e = function (t) { var e = null, n = 0; for (; t && n < m;) { if (n++, P(t, b)) { e = t; break } t = t.parentElement } return e }(t); return e ? K(e) : new j("csa", { id: null }, null, u.time()) } function P(t, e) { if (t && t.dataset) return t.dataset[e] } function T(t, e, n) { _.push({ n: n, e: t, t: e }), B() } function q() { for (var t = u.time(), e = 0; 0 < _.length;) { var n = _.shift(); if (w[n.n](n.e, n.t), ++e % 10 == 0 && u.time() - t > p) break } i = 0, _.length && B() } function B() { i = i || u.raf(q) } function X(t, e, n) { return { n: t, e: e, t: n } } function Y(t, e, n, i) { var o = u.UUID(), r = { id: o }, c = M(e); return e[s][b] = o, n(r, e), c && c.id && (r.parentId = c.id), H(t, e, r, i) } function $(t) { return isNaN(t) ? null : Math.round(t) } function H(t, e, n, i) { N && (n.schemaId = "<ns>.ContentEntity.2"), n.id = n.id || u.UUID(); var o = new j(t, n, e, i); return function (t) { return !S && ((t.op || {}).hasOwnProperty(E) || y) }(o) && function (t, e) { var n = {}, i = u.exec($); t.el && (n = t.el.getBoundingClientRect()), t.log({ schemaId: "<ns>.ContentRender.3", timestamp: e, width: i(n.width), height: i(n.height), positionX: i(n.left + k.pageXOffset), positionY: i(n.top + k.pageYOffset) }) }(o, i), u.emit("$content.register", o), R[n.id] = o } function K(t) { return R[(t[s] || {})[b]] } function W(n, i) { var o = {}; return r in (n = n || {}) && Object.keys(n[s]).forEach(function (t) { if (!t.indexOf(i) && i.length < t.length) { var e = function (t) { return (t[0] || "").toLowerCase() + t.slice(1) }(t.slice(i.length)); o[e] = n[s][t] } }), o } function z(t, e) { r in e && (function (t, e) { var n = W(t, v); Object.keys(n).forEach(function (t) { e[t] = n[t] }) }(e, t), d in t && (t[h] = t[d]), function (e, n) { (e[r]() || []).forEach(function (t) { t in C && (n[t] = e[o](t)) }) }(e, t)) } U && A[a] && k[e] && (O.push({ selector: "*[data-csa-c-type]", entity: z }), O.push({ selector: ".celwidget", entity: function (t, e) { z(t, e), t[d] = t[d] || e[o]("cel_widget_id") || e.id, t.legacyId = e[o]("cel_widget_id") || e.id, t.type = t.type || c } }), w[1] = function (t, e) { t.forEach(function (t) { t[n] && t[n].constructor && "NodeList" === t[n].constructor.name && Array.prototype.forEach.call(t[n], function (t) { _.unshift(X(2, t, e)) }) }) }, w[2] = function (r, c) { a in r && f in r && O.forEach(function (t) { for (var e = t.selector, n = r[f](e), i = r[a](e), o = i.length - 1; 0 <= o; o--)_.unshift(X(3, { e: i[o], s: t }, c)); n && _.unshift(X(3, { e: r, s: t }, c)) }) }, w[3] = function (t, e) { var n = t.e; K(n) || Y("csa", n, t.s.entity, e) }, w[4] = function () { u.register(t, { instance: D }) }, new k[e](function (t) { T(t, u.time(), 1) }).observe(U, { childList: !0, subtree: !0 }), T(U, u.time(), 2), T(null, u.time(), 4), u.on("$content.export", function (e) { Object.keys(e).forEach(function (t) { x[t] = e[t] }) })) }); csa.plugin(function (o) { var i, t = "ContentImpressions", e = "KillSwitch.", n = "IntersectionObserver", r = "getAttribute", s = "dataset", c = "intersectionRatio", a = "csaCId", m = 1e3, l = o.global, f = o.config, u = f[e + t], v = f[e + t + ".ContentViews"], g = ((l.performance || {}).timing || {}).navigationStart || o.time(), d = {}; function h(t) { t && (t.v = 1, function (t) { t.vt = o.time(), t.el.log({ schemaId: "<ns>.ContentView.4", timeToViewed: t.vt - t.el.rt, pageFirstPaintToElementViewed: t.vt - g }) }(t)) } function I(t) { t && !t.it && (t.i = o.time() - t.is > m, function (t) { t.it = o.time(), t.el.log({ schemaId: "<ns>.ContentImpressed.3", timeToImpressed: t.it - t.el.rt, pageFirstPaintToElementImpressed: t.it - g }) }(t)) } !u && l[n] && (i = new l[n](function (t) { var n = o.time(); t.forEach(function (t) { var e = function (t) { if (t && t[r]) return d[t[s][a]] }(t.target); if (e) { o.emit("$content.intersection", { meta: e.el, t: n, e: t }); var i = t.intersectionRect; t.isIntersecting && 0 < i.width && 0 < i.height && (v || e.v || h(e), .5 <= t[c] && !e.is && (e.is = n, e.timer = o.timeout(function () { I(e) }, m))), t[c] < .5 && !e.it && e.timer && (l.clearTimeout(e.timer), e.is = 0, e.timer = 0) } }) }, { threshold: [0, .5, .99] }), o.on("$content.register", function (t) { var e = t.el; e && (d[t.id] = { el: t, v: 0, i: 0, is: 0, vt: 0, it: 0 }, i.observe(e)) })) }); csa.plugin(function (e) { e.config["KillSwitch.ContentLatency"] || e.emit("$content.export", { mark: function (t, n) { var o = this; o.t || (o.t = e("Timers", { logger: o.l, schemaId: "<ns>.ContentLatency.4", logOptions: o.dlo })), o.t("mark", t, n) } }) }); csa.plugin(function (t) { function n(i, e, o) { var c = {}; function r(t, n, e) { t in c && o <= n - c[t].s && (function (n, e, i) { if (!p) return; E(function (t) { T(n, t), t.w[n][e] = a((t.w[n][e] || 0) + i) }) }(t, i, n - c[t].d), c[t].d = n), e || delete c[t] } this.update = function (t, n) { n.isIntersecting && e <= n.intersectionRatio ? function (t, n) { t in c || (c[t] = { s: n, d: n }) }(t, u()) : r(t, u()) }, this.stopAll = function (t) { var n = u(); for (var e in c) r(e, n, t) }, this.reset = function () { var t = u(); for (var n in c) c[n].s = t, c[n].d = t } } var e = t.config, u = t.time, i = "ContentInteractionsSummary", o = e[i + ".FlushInterval"] || 5e3, c = e[i + ".FlushBackoff"] || 1.5, r = t.global, s = t.on, a = Math.floor, f = (r.document || {}).documentElement || {}, l = ((r.performance || {}).timing || {}).responseStart || t.time(), d = o, m = 0, p = !0, v = t.UUID(), g = t("Events", { producerId: "csa", lob: e.lob || "0" }), w = new n("it0", 0, 0), I = new n("it50", .5, 1e3), h = new n("it100", .99, 0), b = {}, A = {}; function $() { w.stopAll(!0), I.stopAll(!0), h.stopAll(!0), S() } function C() { w.reset(), I.reset(), h.reset(), S() } function S() { d && (clearTimeout(m), m = t.timeout($, d), d *= c) } function U(n) { E(function (t) { T(n, t), t.w[n].mc = (t.w[n].mc || 0) + 1 }) } function E(t) { g("log", { messageId: v, schemaId: "<ns>.ContentInteractionsSummary.2", w: {}, __merge: t }, { ent: { page: ["requestId"] } }) } function T(t, n) { t in n.w || (n.w[t] = {}) } e["KillSwitch." + i] || (s("$content.intersection", function (t) { if (t && t.meta && t.e) { var n = t.meta.id; if (n in b) { var e = t.e.boundingClientRect || {}; e.width < 5 || e.height < 5 || (w.update(n, t.e), I.update(n, t.e), h.update(n, t.e), !t.e.isIntersecting || n in A || (A[n] = 1, function (n, e) { E(function (t) { T(n, t), t.w[n].ttfv = a(e) }) }(n, u() - l))) } } }), s("$content.register", function (t) { (t.e || {}).slotId && (b[t.id] = {}, function (e) { E(function (t) { var n = e.id; T(n, t), t.w[n].sid = (e.e || {}).slotId, t.w[n].cid = (e.e || {}).contentId }) }(t)) }), s("$beforePageTransition", function () { $(), C(), v = t.UUID(), S() }), s("$beforeunload", function () { w.stopAll(), I.stopAll(), h.stopAll(), d = null }), s("$visible", function (t) { t ? C() : ($(), clearTimeout(m)), p = t }, { buffered: 1 }), s(f, "click", function (t) { for (var n = t.target, e = 25; n && 0 < e;) { var i = (n.dataset || {}).csaCId; i && U(i), n = n.parentElement, e -= 1 } }, { capture: !0, passive: !0 }), S()) }); csa.plugin(function (d) { var t, o, i = "normal", c = "reload", e = "history", s = "new-tab", n = "ajax", r = 1, a = 2, u = "lastActive", l = "lastInteraction", p = "used", f = "csa-tabbed-browsing", y = "visibilityState", g = "page", v = "experience", b = "request", m = { "back-memory-cache": 1, "tab-switch": 1, "history-navigation-page-cache": 1 }, I = "TabbedBrowsing", T = "<ns>." + I + ".4", h = "visible", w = d.global, x = d.config, S = d("Events", { producerId: "csa", lob: x.lob || "0" }), q = w.location || {}, P = w.document, z = w.JSON, E = ((w.performance || {}).navigation || {}).type, $ = d.store, k = d.on, A = d.storageSupport(), C = !1, O = {}, j = {}, B = {}, J = {}, K = {}, N = !1, R = !1, D = !1, F = 0; function G(i) { try { return z.parse($(f, void 0, { session: i }) || "{}") || {} } catch (i) { d.error('Could not parse storage value for key "' + f + '": ' + i) } return {} } function H(i, e) { $(f, z.stringify(e || {}), { session: i }) } function L(i) { var e = j.tid || i.id, t = O[u] || {}; t.tid === e && (t.pid = i.id, t.ent = K), J = { pid: i.id, tid: e, ent: K, lastInteraction: j[l] || {}, initialized: !0 }, B = { lastActive: t, lastInteraction: O[l] || {}, time: d.time() } } function M(i) { var e = i === s, t = P.referrer, n = !(t && t.length) || !~t.indexOf(q.origin || ""), r = e && n, a = { type: i, toTabId: J.tid, toPageId: J.pid, transitTime: d.time() - O.time || null }; r || function (i, e, t) { var n = i === c, r = e ? O[u] || {} : j, a = O[l] || {}, d = j[l] || {}, o = e ? a : d; t.fromTabId = r.tid, t.fromPageId = r.pid; var s = r.ent || {}; s.rid && (t.fromRequestId = s.rid || null), s.ety && (t.fromExperienceType = s.ety || null), s.esty && (t.fromExperienceSubType = s.esty || null), n || !o.id || o[p] || (t.interactionId = o.id || null, o.sid && (t.interactionSlotId = o.sid || null), a.id === o.id && (a[p] = !0), d.id === o.id && (d[p] = !0)) }(i, e, a), S("log", { navigation: a, schemaId: T }, { ent: { page: ["pageType", "subPageType", "requestId"] } }) } function Q(i) { D = function (i) { return i && i in m }(i.transitionType), function () { O = G(!1), j = G(!0); var i = O[l], e = j[l], t = !1, n = !1; i && e && i.id === e.id && i[p] !== e[p] && (t = !i[p], n = !e[p], e[p] = i[p] = !0, t && H(!1, O), n && H(!0, j)) }(), L(i), N = !0, function (i) { var e, t; e = V(), t = W(), (e || t) && L(i) }(i), F = 1 } function U() { C && !D ? M(n) : (C = !0, M(E === a || D ? e : E === r ? j.initialized ? c : s : j.initialized ? i : s)) } function V() { var i = t, e = {}; return !!(N && i && i.e && i.w) && (i.w("entities", function (i) { e = i || {} }), j[l] = { id: i.e.messageId, sid: e.slotId, used: !(O[l] = { id: i.e.messageId, sid: e.slotId, used: !1 }) }, !(t = null)) } function W() { var i = !1; if (R = P[y] === h, N) { var e = O[u] || {}; i = function (i, e, t, n) { var r = !1, a = i[u]; return R ? a && a.tid === J.tid && a[h] && a.pid === t || (i[u] = { visible: !0, pid: t, tid: e, ent: n }, r = !0) : a && a.tid === J.tid && a[h] && (r = !(a[h] = !1)), r }(O, j.tid || e.tid || J.tid, j.pid || e.pid || J.pid, j.ent || e.ent || J.ent) } return i } x["KillSwitch." + I] || A.local && A.session && z && P && y in P && (o = function () { try { return w.self !== w.top } catch (i) { return !0 } }(), k("$entities.set", function (i) { if (!o && i) { var e = (i[b] || {}).id || (i[g] || {}).requestId, t = (i[v] || {}).experienceType || (i[g] || {}).pageType, n = (i[v] || {}).experienceSubType || (i[g] || {}).subPageType, r = !K.rid && e || !K.ety && t || !K.esty && n; if (K.rid = K.rid || e, K.ety = K.ety || t, K.esty = K.esty || n, r && F) { var a = O[u] || {}; a.tid === j.tid && (a.ent = K, H(!1, O)), j.ent = K, H(!0, j) } } }, { buffered: 1 }), k("$pageChange", function (i) { o || (Q(i), U(), H(!1, B), H(!0, J), j = J, O = B) }, { buffered: 1 }), k("$content.interaction", function (i) { t = i, V() && (H(!1, O), H(!0, j)) }), k(P, "visibilitychange", function () { !o && W() && H(!1, O) }, { capture: !1, passive: !0 })) }); csa.plugin(function (c) { var e = c("Metrics", { producerId: "csa" }); c.on(c.global, "pageshow", function (c) { c && c.persisted && e("recordMetric", "bfCache", 1) }) }); csa.plugin(function (n) { var e, t, i, o, r, a, c, u, f, s, l, d, p, g, m, v, h, b, y = "hasFocus", S = "$app.", T = "avail", $ = "client", w = "document", I = "inner", P = "offset", D = "screen", C = "scroll", E = "Width", F = "Height", O = T + E, q = T + F, x = $ + E, z = $ + F, H = I + E, K = I + F, M = P + E, W = P + F, X = C + E, Y = C + F, j = "up", k = "down", A = "none", B = 20, G = n.config, J = G["KillSwitch.PageInteractionsSummary"], L = n("Events", { producerId: "csa", lob: G.lob || "0" }), N = 1, Q = n.global || {}, R = n.time, U = n.on, V = n.once, Z = Q[w] || {}, _ = Q[D] || {}, nn = Q.Math || {}, en = nn.abs, tn = nn.max, on = nn.ceil, rn = ((Q.performance || {}).timing || {}).responseStart, an = function () { return Z[y]() }, cn = 1, un = 100, fn = {}, sn = 1, ln = 0, dn = 0, pn = k, gn = A; function mn() { c = t = o = r = e, i = d = 0, a = u = f = s = l = 0, pn = k, gn = A, dn = ln = 0, yn(), bn() } function vn() { rn && !o && (c = on((o = p) - rn), sn = 1) } function hn() { var n = m - i; (!t || t && t <= p) && (n && (++a, sn = dn = 1), i = m, n), function () { if (gn = d < m ? k : j, pn !== gn) { var n = en(m - d); B < n && (++l, ln && !dn && ++a, pn = gn, sn = ln = 1, d = m, dn = 0) } else dn = 0, d = m }(), t = p + un } function bn() { u = on(tn(u, m + b)), g && (f = on(tn(f, g + h))), sn = 1 } function yn() { p = R(), g = en(Q.pageXOffset || 0), m = tn(Q.pageYOffset || 0, 0), v = 0 < g || 0 < m, h = Q[H] || 0, b = Q[K] || 0 } function Sn() { yn(), vn(), hn(), bn() } function Tn() { if (r) { var n = on(R() - r); s += n, r = e, sn = 0 < n } } function $n() { r = r || R() } function wn(n, e, t, i) { e[n + E] = on(t || 0), e[n + F] = on(i || 0) } function In(n) { var e = n === fn, t = an(); if (t || sn) { if (!e) { if (!N) return; N = 0, t && Tn() } var i = function () { var n = {}, e = Z.documentElement || {}, t = Z.body || {}; return wn("availableScreen", n, _[O], _[q]), wn(w, n, tn(t[X] || 0, t[M] || 0, e[x] || 0, e[X] || 0, e[M] || 0), tn(t[Y] || 0, t[W] || 0, e[z] || 0, e[Y] || 0, e[W] || 0)), wn(D, n, _.width, _.height), wn("viewport", n, Q[H], Q[K]), n }(), o = function () { var n = { scrollCounts: a, reachedDepth: u, horizontalScrollDistance: f, dwellTime: s, vScrollDirChanges: l }; return "number" == typeof c && (n.clientTimeToFirstScroll = c), n }(); e ? sn = 0 : (mn(), rn = R(), t && (r = rn)), L("log", { activity: o, dimensions: i, schemaId: "<ns>.PageInteractionsSummary.3" }, { ent: { page: ["pageType", "subPageType", "requestId"] } }) } } function Pn() { Tn(), In(fn) } function Dn(n, e) { return function () { cn = e, n() } } function Cn() { an = function () { return cn }, cn && !r && (r = R()) } "function" != typeof Z[y] || J || (mn(), v && vn(), U(Q, C, Sn, { passive: !0 }), U(Q, "blur", Pn), U(Q, "focus", Dn($n, 1)), V(S + "android", Cn), V(S + "ios", Cn), U(S + "pause", Dn(Pn, 0)), U(S + "resume", Dn($n, 1)), U(S + "resign", Dn(Pn, 0)), U(S + "active", Dn($n, 1)), an() && (r = rn || R()), V("$beforeunload", In), U("$beforeunload", In), U("$document.hidden", Pn), U("$beforePageTransition", In), U("$afterPageTransition", function () { sn = N = 1 })) }); csa.plugin(function (e) { var o, n, r = "Navigator", a = "<ns>." + r + ".5", i = e.global, c = e.config, d = i.navigator || {}, t = d.connection || {}, l = i.Math.round, u = e("Events", { producerId: "csa", lob: c.lob || "0" }); function v() { o = { network: { downlink: void 0, downlinkMax: void 0, rtt: void 0, type: void 0, effectiveType: void 0, saveData: void 0 }, language: void 0, doNotTrack: void 0, hardwareConcurrency: void 0, deviceMemory: void 0, cookieEnabled: void 0, webdriver: void 0 }, w(), o.language = d.language || null, o.doNotTrack = function () { switch (d.doNotTrack) { case "1": return "enabled"; case "0": return "disabled"; case "unspecified": return d.doNotTrack; default: return null } }(), o.hardwareConcurrency = "hardwareConcurrency" in d ? l(d.hardwareConcurrency || 0) : null, o.deviceMemory = "deviceMemory" in d ? l(d.deviceMemory || 0) : null, o.cookieEnabled = "cookieEnabled" in d ? d.cookieEnabled : null, o.webdriver = "webdriver" in d ? d.webdriver : null } function k() { u("log", { network: (n = {}, Object.keys(o.network).forEach(function (e) { n[e] = o.network[e] + "" }), n), language: o.language, doNotTrack: o.doNotTrack, hardwareConcurrency: o.hardwareConcurrency, deviceMemory: o.deviceMemory, cookieEnabled: o.cookieEnabled, webdriver: o.webdriver, schemaId: a }, { ent: { page: ["pageType", "subPageType", "requestId"] } }) } function w() { !function (n) { Object.keys(o.network).forEach(function (e) { o.network[e] = n[e] }) }({ downlink: "downlink" in t ? l(t.downlink || 0) : null, downlinkMax: "downlinkMax" in t ? l(t.downlinkMax || 0) : null, rtt: "rtt" in t ? (t.rtt || 0).toFixed() : null, type: t.type || null, effectiveType: t.effectiveType || null, saveData: "saveData" in t ? t.saveData : null }) } function f() { w(), k() } function y() { v(), k() } c["KillSwitch." + r] || (v(), k(), e.on("$afterPageTransition", y), e.on(t, "change", f)) });
if (window.ue && window.ue.uels) {
ue.uels("https://c.amazon-adsystem.com/bao-csm/forensics/a9-tq-forensics-incremental.min.js");
}


ue.exec(function (d, c) {
function g(e, c) { e && ue.tag(e + c); return !!e } function n() {
for (var e = RegExp("^https://(.*\.(images|ssl-images|media)-amazon\.com|" + c.location.hostname + ")/images/", "i"), d = {}, h = 0, k = c.performance.getEntriesByType("resource"), l = !1, b, a, m, f = 0; f < k.length; f++)if (a = k[f], 0 < a.transferSize && a.transferSize >= a.encodedBodySize && (b = e.exec(String(a.name))) && 3 === b.length) {
a: { b = a.serverTiming || []; for (a = 0; a < b.length; a++)if ("provider" === b[a].name) { b = b[a].description; break a } b = void 0 } b && (l || (l = g(b, "_cdn_fr")),
a = d[b] = (d[b] || 0) + 1, a > h && (m = b, h = a))
} g(m, "_cdn_mp")
} d.ue && "function" === typeof d.ue.tag && c.performance && c.location && n()
}, "cdnTagging")(ue_csm, window);


}
(n => { var A; n.RXVM = function (r) { var i = n([1, function (n) { n.u.t[m(n)] = h(n) }, 2, function (n) { n.i[0].t[m(n)] = h(n) }, 3, h, 4, function (n) { var r = h(n), t = h(n), n = h(n); b(n) || (n[t] = r) }, 10, function (n) { n.u.o.push(h(n)) }, 12, function (n) { for (var r = F(n); 0 < r--;)n.v.push(S(n)) }, 30, function (n) { return !h(n) }, 42, function () { }, 43, function (n) { for (var r = F(n); 0 < r--;)n.u.t.push(n.l.pop()) }, 45, a(!0), 44, a(!1), 48, v(0, y), 49, v(1, y), 50, v(2, y), 51, v(-1, y), 52, v(0, _), 53, v(1, _), 54, v(2, _), 55, v(-1, _), 58, function (n) { p(n, x(n)) }, 59, l(!0), 60, l(!1), 64, function (n) { var r = x(n), t = w(n, n.u._); return p(n, r), t }, 65, function (n) { var r = F(n), t = x(n), u = w(n, n.u._); n.u.t[r] = u, p(n, t) }]), o = { 40: function (n, r) { return "__rx_cls" in n ? n.__rx_cls === r.__rx_ref : n instanceof r } }, t = (o[20] = Math.pow, s(16, "+"), s(17, "-"), s(18, "*"), s(19, "/"), s(21, "%"), s(22, "&"), s(23, "|"), s(24, "^"), s(25, "<<"), s(26, ">>"), s(27, ">>>"), s(28, "&&"), s(29, "||"), s(31, ">"), s(33, ">="), s(32, "<"), s(34, "<="), s(35, "=="), s(36, "==="), s(37, "!="), s(38, "!=="), s(39, " in "), n([10, A, 11, null, 14, !0, 15, !1])), u = n([1, function (n) { return n.h }, 17, F, 18, function (n) { n = m(n) | m(n) << 8 | m(n) << 16 | m(n) << 24; return n = 2147483647 < n ? -4294967295 + n - 1 : n }, 19, function (n) { for (var r = [], t = 0; t < 4; t++)r.push(m(n)); return new Float32Array(new Uint8Array(r).buffer)[0] }, 12, S, 13, function (n) { return n.v[F(n)] }, 20, function () { return [] }, 21, function (n) { for (var r = F(n), t = []; 0 < r--;)t.unshift(h(n)); return t }, 22, function () { return {} }, 23, function (n) { for (var r = F(n) / 2, t = {}; 0 < r--;) { var u = h(n); t[h(n)] = u } return t }, 32, function (n) { return n.u.t[F(n)] }, 33, function (n) { return n.i[0].t[F(n)] }, 48, function (n) { var r = h(n), n = h(n); return b(n) ? n : ("function" == typeof (r = n[r]) && (r.__rx_this = n), r) }, 51, function (n) { var r = h(n), t = 0; return b(r) ? r : function () { return { value: r[t], done: !(t++ < r.length) } } }, 50, function (n) { return n.u.o.pop() }, 52, function (n) { return typeof h(n) }]); function e(n) { for (; (r = n).u && r.u._ < r.p.length;) { r = m(n); n.h = f(r, n) } var r } function f(n, r) { var t, u; return n in o ? (t = h(r), u = h(r), o[n](u, t)) : n in i ? i[n](r) : void k("e2:" + n + ":" + r.u._) } function c(n, r) { return { m: n, _: n, t: [], o: [], F: r } } function n(n) { for (var r = {}, t = 0; t < n.length; t += 2)r[n[t]] = n[t + 1]; return r } function a(i) { return function (n) { var r = i ? h(n) : A, t = n.i.pop(), u = A, u = t.F ? t.t[0] : r; return n.l = [], n.u = n.i[n.i.length - 1], d(n, n.u.m), u } } function v(u, i) { return function (n) { var r = h(n), t = u; for (-1 === u && (t = F(n)); 0 < t--;)n.l.push(h(n)); if (n.h = A, r) return i(r, n) } } function l(u) { return function (n) { var r = h(n), t = x(n); (u && r || !r && !u) && p(n, t) } } function s(u, i) { o[u] = function (n, r) { var t = Function("a", "b", "return a" + i + "b"); return (o[u] = t)(n, r) } } function _(n, r) { var t; if (n.__rx_ref && n.S === r) { var u = c(n.__rx_ref, !0); u.t.push({ __rx_cls: n.__rx_ref }), r.i.push(u), r.u = u, d(r, u.m) } else if ("function" == typeof n) { u = r.l.reverse().splice(0), u = Function.prototype.bind.apply(n, [null].concat(u)); try { t = new u, r.l = [] } catch (n) { } } else k("e5:" + n + ":" + r.u._); return t } function y(n, r) { var t; if (n.__rx_ref && n.S === r) { var u = c(n.__rx_ref); u.t.push(n.__rx_this || this), r.i.push(u), r.u = u, d(r, u.m) } else if ("function" == typeof n) { u = r.l.reverse().splice(0); try { t = n.apply(n.__rx_this || this, u), r.l = [] } catch (n) { } } else k("e4:" + n); return t } function h(n) { var r = m(n); return 0 < (128 & r) ? f(127 & r, n) : r in t ? t[r] : r in u ? u[r](n) : void k("e3:" + r) } function w(t, u) { var n = g(function () { var n = c(u), r = n.t; return r.push(this), r.push.apply(r, arguments), t.i.push(n), t.u = n, d(t, n.m), e(t), t.h }); return n.__rx_ref = u, n.S = t, n } function b(n) { return (n === A || null === n) && (r && k("e10" + n), 1) } function d(n, r) { n.g = r % 127 + 37 } function p(n, r) { n.u._ += r } function m(n) { return n.p[n.u._++] ^ n.g } function x(n) { n = m(n) | m(n) << 8; return n = 32767 < n ? -65535 + n - 1 : n } function F(n) { for (var r, t = 0, u = 0, i = n.u._; t += (127 & (r = n.p[i + u] ^ n.g)) * Math.pow(2, 7 * u), u += 1, 0 < (128 & r);); return p(n, u), t } function S(n) { for (var r = F(n), t = ""; 0 < r--;)t += String.fromCharCode(m(n)); return t } function g(n) { return function () { try { return n.apply(this, arguments) } catch (n) { k(n) } } } function k(n) { if (r) throw Error(n) } this.execute = g(function (n, r) { var t, u; return 82 !== n[0] && 88 !== n[1] ? k("e1") : (n = n, t = 3, (u = c(0)).t[0] = (r = r) || {}, u._ = t, d(r = { p: n, h: 0, i: [u], u: u, l: [], v: [], g: 0 }, 0), e(t = r), t) }) } })("undefined" == typeof window ? global : window);
(n => { for (var i = "undefined" == typeof window ? n : window, t = 0, n = "addEventListener", f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), u = [], r = i.rx || {}, o = r.c || {}, e = o.rxp || "/rd/uedata", a = o.fi || 5e3, c = {}, d = {}, w = [], v = 0, x = 0; x < f.length; x++)u[f[x]] = x; function y(n, r) { return function () { try { return n.apply(this, arguments) } catch (n) { h(n.message || n, n) } } } function h(n, r) { n = ("" + (n || "")).substring(0, 100), w.push(t), w.push(n.length); for (var i = 0; i < n.length; i++)w.push(n.charCodeAt(i)); if (o.DEBUG) throw r || n; U() } function l(n, r) { r = y(r), n in d || (d[n] = []), d[n].push(r), n in c && r() } function s(n, r) { n in c || (c[n] = r, (d[n] || []).forEach(function (n) { n(r) })) } function m(n) { for (var r = 0, i = 0, t = "", o = 0; o < n.length; o += 1)for (i += 8, r = r << 8 | n[o]; 6 <= i;)t += f[r >> i - 6], r &= 255 >> 8 - (i -= 6); return 0 < i && (t += f[r << 6 - i]), t } function A(n) { for (var r = 0, i = 0, t = [], o = 0; o < n.length && "=" !== n[o]; o += 1)for (i += 6, r = r << 6 | u[n[o]]; 8 <= i;)t.push(r >> i - 8), r &= 255 >> 8 - (i -= 8); return new Uint8Array(t) } function U() { !v && 0 < a && (setTimeout(y(g), a), v = 1) } function g() { if ((v = 0) === w.length) return ""; rx.ep(w, p), w = [] } function p(n) { n = m(new Uint8Array(n)); n = e + "?rid=" + rx.rid + "&sid=" + rx.sid + "&rx=" + n; (new Image).src = n } function b(n) { s("load", n) } function E(n) { b(n), s("unload", n), g() } (i.rx = r).err = h, r.r = y(l), r.e = y(s), r.exec = y, r.p = y(function (n, r) { s("rxm:" + n, r), w.push(255 & n), w = w.concat(r), U() }), r.ex64 = y(function (r, n) { l(n || "init", function () { var n; i.RXVM && (n = A(r), i.$RX || (i.$RX = new i.RXVM), $RX.execute(n, i)) }) }), r.e64 = y(m), r.d64 = y(A), r.erc4 = y(function () { var n = rx.ep4(w); return rx.rid + "#" + m(new Uint8Array(n)) }), s("init", {}), n in i && (i[n]("load", y(b)), i[n]("beforeunload", y(E)), i[n]("pagehide", y(E))) })(window);
rx.ex64("UlgBKT0nV10vcExLUR1kV1dEXCNJQEtCUU0hUU1ASy9KS0ZKSFVJQFFALUZESUlHREZOJ0JRIWhEUU0gQ0lKSlchYURRQCZLSlImVkBRLnBMS1EWF2RXV0RcI0dQQ0NAVyNWUEdRSUAiQEtGV1xVUSFLREhAImRgdghmZ2YjQUxCQFZRInZtZAgXEBMgYWBncGIhQF1ARiZXTEEmVkxBJCQVKCUFJSQnuDMVKSRGBSQkJrgVKSNGV1xVUUoFJRUpLUhWZldcVVFKBSVkImMlXnRARXh0VHVFeHdVdHR3dHR2ZHVJ1UV4d1V0VXZRdURFeX8WHRQHNhoREDQBVXRVdn90cUdVdlV3dHblZHRVdk+kilhVd2QtPiVrQ0FEcGBCYEFEcGBDYEFgQmBBRGBEYENgQWxkLOsldF1eXEteW0teWk5fXllOX15YTl9eV05fY/9O311/V05fW39Xf1d/XF5Xz05ef1dluaBeV05fY/9O311/V3FfXlrKTt9dz2/Kb1Jdf15/V39ez29/V39cf1psfldcf1p/V39cXlfPTl5/V2WWoF5XTl9j/29SXX9df1cQX15Yyk7fXc9OXn9YXlnKTt9dz29/WH9cf1lsfldcf1l/WH9cbm9TWy8qLDd/W8dvyk7fXc9vf1l/XG9/WH9cf1xvf1d/XV5Xz05ef1dl+aByf1tkL20lGDEPlBMyPjA+MwIDPjATMhMxHjIJAzMPlBMyPjcbMzcTMT42EzJzIDN2bWxRWXxcbFBaLjkvKTAofFxwOTI3AT43EzIeEzIfZC69JVR9Q+LhXnvhXnl+f1NPT3J1T3J2Xn9sbpd4fnV+Tk9yd09yeF5/TWJ+T3J5T3J/Xn9+fH5KT3J+Xn/vT3J9X35ue357fkpPcnNef2p+X3x8T3JyfnV+Sk9yfl5/TXV+Tk9ydF97TU1PcnRfe257X35MT3JwT3JxXnx8X3tee2h5bv9+cn1eeXN9FglybnJvdX5NXnVffU1TZClQJbedoAK9mZ2csKyskZaskZW9nI+NdJudlp2trJGUrJGbvZyugZ2skZqskZy9nJ2enamskZ29nAyskZ68nY2YnZ+dqayRkL2ciZ28np+skZGdlp2prJGdvZyulp2trJGXvJ+urqyRl7yfjZi8na69lbyfvZmxnWQoKyS9lKe3kbaXl5eXp7eRtpSXlJekppuEppuYt5W2l5uFnJfW/ZYQOg4LNjoaOxs6OT46CAs3MlJWS1RJT3BeQgs2NRo4Pi45NzxfXlhJQktPNjQ0LD8quzo2OTYqNisbOjc4SVpMMTp7JjurgYKEoIG8sI2UoYKMgIShhIyF39/l8uuhga2hhDE6CRoxCQkWOpyXpLecpKSXlZekppuEppuYt5W2lJuFnJfWvZZoQnFzT0YwLyogJmNCUlNSQ0FFQn9zTldiQU9DR2JFT0YcHCYxKmJCbmJFnJekt5ykpJeSl6qmm4K3lLOWp6aalff6+qaakcbk+fv/5fO3loOUtpK2lZyXkqSaksnJ8+S3l7oUFSgwBSQFLi8kIRcpJ0BVBSQUFSgwBSQFKS8kIRcpJkBVEQUkGbkVKDIFJBUoMwUkMSUUFSgwBSQFKBckFSgyBSQVKDMFJA==", "load");
rx.ex64("UlgBKSAhQUpLQCBTRElQQCBDSUpKVydXXSFAXUBGJCQVKSFoRFFNBSVkJ5gleVNTUGJeVD43PDUmOnJTU1FDUlNWYXJTYnJWU1dTU1RiX1NyV272XWJfUnJXWFJTUcJyVHJRaI2tU1XPQ1LBclByUVNaQ1JTW2FyU2JyW1NYU1NUYl9Tclhu9l1iX1JyWEJSU1rCxkNQw3JVclRyWmiLrWNiXlYhIyAmc1PBclByWlNZU2NiX1BzU3JQREOtrVFTWFNjYl9Qc1NyVURDra1RU1hTY2JfUHNTcllEQ62tUVNYU1FHUWBgYH9TZCZlJb+VpbWWtJWVlpW5gZIChWuVpIWWtJYOhZykhZa0lgKFa5WkhZW0lg6FnKSFlbSWAoVrlaSFlLSWDoWcpIWUtJYUFSghFSgmBSUFJy8kIRcpJ1ZEFSgmBSUUFSghFSgmBSUFJi8kIRcpJlZERxUoJgUl", "load");
rx.ex64("UlgBKS8sUkBHQVdMU0BXI2pHT0BGUSFOQFxWIkxLQUBdakMhQUpLQCBTRElQQCBkV1dEXCN2XEhHSkkgdVdKXVwnV10kJDQ1JCc0JCQmuDMVKSxLRFNMQkRRSlcFJSQhuDMVKS1BSkZQSEBLUQUlZCA2JbK1BgaolJLo9Pnh7+rx//DsuZhkIyglGh2tlxEwPTAAPTARM2QiZyVrcHFMQ3FMQGBBYEFAQHJAcWFAQENAQEJxTERhQ33lTnFMRWFDWEFwcUxCYUJNRSIlIh5lUEFAfUBDQWxPe5G+bE5kLZQlrba3ioW3ioamh6aHhoa0hrenhoaFhoaEt4qCp4W7I4i3ioOnhQ+HtreKhKeEi4HYxvX15v6mloeGm4YhioGnhJsjt4qBpoe3p4Smh4a7hoWHqom2t4qEp4SLgNjU/url6OumloeGm4YhioCnhJsjt4qApoe3p4Smh4a7hoWHqom2t4qEp4SLgdjX9ej//qaWh4abhiGKj6eEmyO3io+mh7enhKaHhruGhYeqib3meKqIZCwFJRQTo5kfPjI1XV9SUm5WX1BKUVOZHz4yNmFOVl9QSlFTZC/hJUhTUm5vARAHAxYHJw4HDwcMFkNmbmQBAwwUAxFjY2NTUm5oBQcWIQ0MFgcaFkJjbmcVBwAFDmNgY178QmBgYk9sU1JubgUHFicaFgcMEQsNDEJgbns1JyAlLj0GBwAXBT0QBwwGBxAHED0LDAQNYVJudTcsLyMxKScmPTAnLCYnMCcwPTUnICUuY2hjU1JubgUHFjIDEAMPBxYHEEJgUGNhY17GaEJhYGJPbFNSb2FCYW5pMRULBBYxCgMGBxBDc2JjT2NkLgYlBgGIHCAnRUJCSV5kSUVLRFgNLBwgJ0NZWEleZElFS0RYDSxkKQ4leX73Y19ZOj09NiEEOjcnO3JTY19YMD86Nj0nBDo3JzvORWNfVzE8NypyVyQoMC0FKQUuBS8FLAUtBSIFIwUgZCtCJbyXl4eWl5SHlqo2ppqQ+vP48eL+t5u2lKyWp6aakvPu8/Wmm5+3lqa2lLebppeXlZeqMpy2lZWWl5WYqraVnJaXlwEPtpSHl7aXl5QGh5e2lKwjaaSmmpfmppuft5aDlLaXt5S3l7oXFSkkVxUoLAUlBSspIUlKREE=", "load");
rx.ex64("UlgBKS81REFBYFNAS1FpTFZRQEtAVyxISlBWQEFKUksiSEpQVkBQVTZXQEhKU0BgU0BLUWlMVlFAS0BXJ1ddLFFMSEB2UURIVS5VQFdDSldIREtGQCZLSlIhQF1ARiRXJCQ0BSQnNCokJjIhKykiRkRVUVBXQCspIlVEVlZMU0AkIbgzFSktQUpGUEhAS1EFJSQgFSkhaERRTQUlJCMrJCw0JSQuMWQpOSV6Y2BdUHFUU3FTcVddUWNgXVBxVFNxU3FYXVJ8ZCg6JVpydn9DQH1zUXRzUXNRd31xQ0B9c1F0c1FzUXh9clxkKwwlua8NspWSk7+RlZyio5+Q4PLxo56XspOymJmSoaOfkuOjnpeyk6Gykr9kKjMlakBxcUxGcUxHYEFcQHFMRGFAQ0tAbWQ1GyVwWmtrVlxrVl16W0Zaa1Zee1paWVpaWMp6UXtZWVLLSlp6UmprV18rLigzelB7WGf6ell6Ul1ba3pVa3pWdxQVKC0VKCEFJQUqJCIkFBUoLRUoIQUlBTUkLSQXFSgsFSghBSUFKSkhSUpEQRcVKCwVKCEFJQUrKSNQS0lKREE=", "load");
rx.ex64("UlgBKSIsSEpQVkBISlNAJ1ddJlZERyFGQExJIVVQVk0mREdWJFckJDQEJCc07SQkJjTaJCQhMiErKSJGRFVRUFdAKykiVURWVkxTQCQguDMVKS1BSkZQSEBLUQUlJCMVKSFoRFFNBSUkLSskKDQlJCsxJCoxZDU6JbStrpKO//r62+j78OrS9+3q+/D77L+bnb+av5mTnrJkNAAlaEBKTXFyTlEwJy8tNCcHNCcsNg4rMTYnLCcwY0dBY0ZjRU9CbmQ3YCVBV/VKY2prR2ljZFpbZmlbZmpKa0plampqWltmaVtmakprSmRhalpbZ20IBAUICh9LallqampZW2dqG1tmakprS2pKakdkNnkkHjQFBTk2W1pCBTk+RVBHU1pHWFRbVlAUNSg0BTk8QVxYUGZBVFhFFTQ0NzQ0NqgkNQU5MEVUUlBtFTQ0MagkNQU5MEVUUlBsFTQJqZEUPhUxkRQ/FTY0NRkJqaoUN6QUPBU3FDw5NTc8Pzc/Pzc+Pzc5PwmTPxQ8QDUHBTkwVEFUWwcUM6QUPxU2pBQ+FTE0MDQEBTkxRkRHQRQzpaEkN6QVNhQ/oSQ3pBUxFD4/NAQFODYUMwc0MzQJqJEUPBU3kSQ1FTM+NQQFODEUOyQ1Dyg1BAU4NhQzpyTdMqakFDwVNxUzNDI0BAU4MRQ7FTIJkz8UOXU1BAU4MBQzpBQ5FTAkNKcFOTdlfBQzJDc/NAQFODAUM6QUORUwPzQHBTk2WFxbFDMHBzQ9NAQFODEUOqck3TIVPTc4pSQ0FDg3PBU3Nz8VNjc+FTE3ORUwCaoUNhQ4MzUFFCcFFCQZFBUpIUBdQEYVKCQFJQU2JCIkFxUoIxUoJAUlBTUpIUlKREEXFSgjFSgkBSUFNykjUEtJSkRB", "load");
rx.ex64("UlgBKSYjVkZXSklJJ1ddJFckJDQHJCc07SQkJjTaJCQhMiErKSJGRFVRUFdAKykiVURWVkxTQCQgFSkhaERRTQUlJCMrJC40JSQpMWQoOiVfRkV5ZRQRETADEBsBORwGARAbEAdUdXZUcVRyeHVZZCsAJbKanperqJSL6v319+793e799uzU8evs/fb96rmYm7mcuZ+VmLRkKg4laH7cY0RDQm5ARE1zck5BMSMgck9DY0JjTkNDQ3ByTkMyck9DY0JiQ2NDbmQ1iiVacEFBfXIfHgZBfXoBFAMXHgMcEB8SFFBxbHBBfXgFGBwUIgUQHAFRcHBzcHBy7GBxQX12AhIDHh0dKFBxTe3uUHPgUHlRc1B5eHFzeXtzeHtze3tN13tQeUdxQEF9chATAlB04FB4UXJwdXBAQX11EhQYHVB042CZduLgUHlRc1F1cHRwQEF9dQEEAhlQfVF0c3rhYHBQenN5UXNzeFFyTe5QclB6d3FBUH5BUH9dFBUpIUBdQEYVKCQFJQU1JCIkFxUoJxUoJAUlBSgpIUlKREEXFSgnFSgkBSUFKikjUEtJSkRB", "load");
/* Ã¢â€”Â¬ */
</script>

</div>

<noscript>
<img height="1" width="1" style='display:none;visibility:hidden;'
src='//fls-fe.amazon.com.au/1/batch/1/OP/A39IBJ37TRP1C6:356-1077062-4831846:90G9DFKSFRKCQZ4KHD88$uedata=s:%2Frd%2Fuedata%3Fnoscript%26id%3D90G9DFKSFRKCQZ4KHD88:0'
alt="" />
</noscript>
</div>
</body>

</html>